// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package android.support.v4.view.accessibility;


// Referenced classes of package android.support.v4.view.accessibility:
//            AccessibilityManagerCompat

public abstract class 
{

    final Object mListener = AccessibilityManagerCompat.access$000().ssiblityStateChangeListener(this);

    public abstract void onAccessibilityStateChanged(boolean flag);

    public ()
    {
    }
}
