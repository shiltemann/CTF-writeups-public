// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.hackyeaster.android;

import android.app.DownloadManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.Base64;
import android.util.Log;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

// Referenced classes of package ps.hacking.hackyeaster.android:
//            d, b, h, c, 
//            e, i, a

public class Activity extends android.app.Activity
    implements SensorEventListener
{

    private static final Uri b = Uri.parse("twitter://user?screen_name=hackyeaster");
    private static final Uri c = Uri.parse("https://mobile.twitter.com/hackyeaster");
    private static final Pattern d = Pattern.compile("[0-9a-zA-Z]{20}");
    private static final SecureRandom e = new SecureRandom();
    protected WebView a;
    private boolean f;
    private SensorManager g;
    private Sensor h;
    private Sensor i;
    private String j;
    private String k;
    private float l[];
    private float m[];

    public Activity()
    {
        f = false;
    }

    private int a(String s, Context context)
    {
        try
        {
            SecretKeySpec secretkeyspec = new SecretKeySpec(a(s, "ovaederecumsale", 10000), "AES");
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(2, secretkeyspec);
            String s1 = new String(cipher.doFinal(Base64.decode("8QeNdEdkspV6+1I77SEEEF4aWs5dl/auahJ46MMufkg=", 0)));
            DownloadManager downloadmanager = (DownloadManager)getSystemService("download");
            android.app.DownloadManager.Request request = new android.app.DownloadManager.Request(Uri.parse((new StringBuilder("http://hackyeaster.hacking-lab.com/hackyeaster/pin?p=")).append(s1).toString()));
            request.setTitle("Hacky Easter");
            request.setDescription("Egg Download");
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "egg_26.png");
            registerReceiver(new d(this), new IntentFilter("android.intent.action.DOWNLOAD_COMPLETE"));
            downloadmanager.enqueue(request);
            Toast.makeText(context, "Download started", 0).show();
        }
        catch (Exception exception)
        {
            return 1;
        }
        return 0;
    }

    static int a(Activity activity, String s, Context context)
    {
        return activity.a(s, context);
    }

    private void a(Intent intent)
    {
        String s = intent.getStringExtra("SCAN_RESULT");
        if ("QR_CODE".equals(intent.getStringExtra("SCAN_RESULT_FORMAT")) && d.matcher(s).matches())
        {
            a(0, s);
            return;
        }
        if (s != null && !"".equals(s))
        {
            a(1, "");
            return;
        } else
        {
            a(2, "");
            return;
        }
    }

    private void a(String s, String s1, Context context)
    {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(context);
        builder.setCancelable(false);
        if (s != null && !"".equals(s))
        {
            builder.setTitle(s);
        }
        builder.setMessage(s1);
        builder.setPositiveButton("OK", null);
        builder.show();
    }

    static void a(Activity activity, String s, String s1, Context context)
    {
        activity.a(s, s1, context);
    }

    static boolean a(Activity activity)
    {
        return activity.f;
    }

    public static byte[] a(String s, String s1, int i1)
    {
        MessageDigest messagedigest = MessageDigest.getInstance("SHA1");
        byte abyte0[] = (new StringBuilder(String.valueOf(s1))).append(s).toString().getBytes();
        int j1 = 0;
        do
        {
            if (j1 >= i1)
            {
                byte abyte1[] = new byte[16];
                System.arraycopy(abyte0, 0, abyte1, 0, 15);
                return abyte1;
            }
            abyte0 = messagedigest.digest(abyte0);
            j1++;
        } while (true);
    }

    static void b(Activity activity)
    {
        activity.g();
    }

    static void c(Activity activity)
    {
        activity.h();
    }

    private void d()
    {
        h = g.getDefaultSensor(1);
        i = g.getDefaultSensor(2);
        g.registerListener(this, h, 0);
        g.registerListener(this, i, 0);
        l = null;
        m = null;
    }

    static void d(Activity activity)
    {
        activity.i();
    }

    private void e()
    {
        if (h != null)
        {
            g.unregisterListener(this, h);
        }
        if (i != null)
        {
            g.unregisterListener(this, i);
        }
    }

    static void e(Activity activity)
    {
        activity.d();
    }

    private void f()
    {
        try
        {
            Intent intent = new Intent("android.intent.action.VIEW", b);
            intent.setFlags(0x10000000);
            startActivity(intent);
            return;
        }
        catch (ActivityNotFoundException activitynotfoundexception) { }
        try
        {
            Intent intent1 = new Intent("android.intent.action.VIEW", c);
            intent1.setFlags(0x10000000);
            startActivity(intent1);
            return;
        }
        catch (Exception exception)
        {
            return;
        }
    }

    static void f(Activity activity)
    {
        activity.f();
    }

    private void g()
    {
        Intent intent = new Intent("ps.hacking.zxing.client.android.SCAN");
        try
        {
            intent.setClass(this, Class.forName("ps.hacking.zxing.client.android.CaptureActivity"));
            intent.putExtra("SCAN_MODE", "QR_CODE_MODE");
            f = true;
            startActivityForResult(intent, 1336);
            return;
        }
        catch (ClassNotFoundException classnotfoundexception)
        {
            Log.e("HackyEaster App", "Could not load QR code scanner class");
        }
    }

    private void h()
    {
        Intent intent = new Intent("ps.hacking.zxing.client.android.PANORAMA");
        try
        {
            intent.setClass(this, Class.forName("ps.hacking.hackyeaster.android.PanoramaActivity"));
            startActivity(intent);
            return;
        }
        catch (ClassNotFoundException classnotfoundexception)
        {
            Log.e("HackyEaster App", "Could not load panorama class");
        }
    }

    private void i()
    {
        try
        {
            startActivityForResult(new Intent("android.media.action.IMAGE_CAPTURE"), 1337);
            return;
        }
        catch (Exception exception)
        {
            Toast.makeText(this, "Couldn't create file.", 0).show();
        }
    }

    private void j()
    {
        int i1 = 100;
        if (l == null || m == null) goto _L2; else goto _L1
_L1:
        float af[] = new float[9];
        if (!SensorManager.getRotationMatrix(af, new float[9], l, m)) goto _L2; else goto _L3
_L3:
        float af1[] = new float[3];
        SensorManager.getOrientation(af, af1);
        int j1 = 5 * (int)Math.ceil((double)((int)(System.currentTimeMillis() / 1000L) % 100) / 5D);
        int k1 = Math.round(100F * (Math.abs(af1[1]) + Math.abs(af1[2])));
        int l1;
        int i2;
        int j2;
        int k2;
        String s;
        String s1;
        MessageDigest messagedigest;
        String s2;
        if (k1 <= 20)
        {
            l1 = i1;
        } else
        if (k1 > 300)
        {
            l1 = 0;
        } else
        {
            l1 = Math.round((100 * (300 - k1)) / 280);
        }
        i2 = Math.round(100F * Math.abs(af1[0]));
        if (i2 <= 20)
        {
            j2 = i1;
        } else
        {
            j2 = 0;
            if (i2 <= 300)
            {
                j2 = Math.round((100 * (300 - i2)) / 280);
            }
        }
        k2 = c();
        Exception exception;
        if (k2 < 95)
        {
            i1 = k2;
        }
        s = "";
        if (i1 + (j2 + (j1 + l1)) != 400)
        {
            break MISSING_BLOCK_LABEL_246;
        }
        s1 = (new StringBuilder(String.valueOf(j1))).append("f").append(l1).append("u").append(j2).append("n").append(i1).toString();
        messagedigest = MessageDigest.getInstance("SHA1");
        messagedigest.update(s1.getBytes());
        s2 = Base64.encodeToString(messagedigest.digest(), 2);
        s = s2;
_L5:
        a.loadUrl((new StringBuilder("javascript:sensorFeedback('{\"k\": \"")).append(s).append("\", \"l1\": ").append(j1).append(", \"l2\": ").append(l1).append(", \"l3\": ").append(j2).append(", \"l4\": ").append(i1).append("}')").toString());
        l = null;
        m = null;
_L2:
        return;
        exception;
        if (true) goto _L5; else goto _L4
_L4:
    }

    protected void a()
    {
        requestWindowFeature(1);
        setContentView(0x7f030001);
        a = (WebView)findViewById(0x7f07000c);
        a.getSettings().setGeolocationEnabled(true);
        a.getSettings().setJavaScriptEnabled(true);
        int _tmp = android.os.Build.VERSION.SDK_INT;
        a.setWebChromeClient(new b(this));
        a.loadUrl("file:///android_asset/www/index.html");
        a.setVisibility(0);
    }

    public void a(int i1, String s)
    {
        StringBuilder stringbuilder = new StringBuilder();
        stringbuilder.append("{\"rc\":").append(i1);
        stringbuilder.append(", \"egg\": \"").append(ps.hacking.hackyeaster.android.h.a(s, true));
        stringbuilder.append("\"}");
        a.loadUrl((new StringBuilder("javascript:scanResult('")).append(stringbuilder.toString()).append("')").toString());
    }

    public void b()
    {
        a.setWebViewClient(new c(this, this));
    }

    public int c()
    {
        Intent intent = registerReceiver(null, new IntentFilter("android.intent.action.BATTERY_CHANGED"));
        int i1 = intent.getIntExtra("level", -1);
        int j1 = intent.getIntExtra("scale", -1);
        if (i1 == -1 || j1 == -1)
        {
            return 50;
        } else
        {
            return Math.round((i1 * 100) / j1);
        }
    }

    public void onAccuracyChanged(Sensor sensor, int i1)
    {
    }

    protected void onActivityResult(int i1, int j1, Intent intent)
    {
        super.onActivityResult(i1, j1, intent);
        if (i1 != 1336) goto _L2; else goto _L1
_L1:
        f = false;
        if (j1 != -1 || intent == null || !"ps.hacking.zxing.client.android.SCAN".equals(intent.getAction())) goto _L4; else goto _L3
_L3:
        a(intent);
_L6:
        return;
_L4:
        a(2, "");
        return;
_L2:
        if (i1 != 1337) goto _L6; else goto _L5
_L5:
        File file;
        file = new File(Environment.getExternalStorageDirectory(), "HackyEaster");
        if (!file.exists() && !file.mkdirs())
        {
            Toast.makeText(this, "Couldn't create folder on sdcard.", 0).show();
        }
        if (!file.exists() || intent == null || intent.getExtras() == null) goto _L6; else goto _L7
_L7:
        File file1;
        Bitmap bitmap;
        Bitmap bitmap1;
        Canvas canvas;
        int k1;
        int l1;
        long l2;
        long l3;
        long l4;
        int i2;
        file1 = new File(file, (new StringBuilder("Snapshot_")).append(e.nextInt()).append(".png").toString());
        bitmap = (Bitmap)intent.getExtras().get("data");
        bitmap1 = bitmap.copy(android.graphics.Bitmap.Config.ARGB_8888, true);
        canvas = new Canvas(bitmap1);
        k1 = bitmap.getHeight();
        l1 = bitmap.getWidth();
        l2 = 0L;
        l3 = 0L;
        l4 = 0L;
        i2 = 0;
_L8:
        if (i2 >= l1)
        {
            int j2;
            int k2;
            String as[];
            if (k1 > l1 && (double)l2 > 0.90000000000000002D * (double)(l3 + l4))
            {
                byte abyte2[] = Base64.decode(Base64.decode(j, 0), 0);
                Bitmap bitmap4 = BitmapFactory.decodeByteArray(abyte2, 0, abyte2.length);
                int k3 = bitmap4.getHeight();
                canvas.drawBitmap(bitmap4, (l1 - bitmap4.getWidth()) / 2, k1 - k3 / 2, null);
            } else
            if (l1 > k1 && (double)l3 > 0.90000000000000002D * (double)(l4 + l2))
            {
                byte abyte1[] = Base64.decode(Base64.decode(j, 0), 0);
                Bitmap bitmap3 = BitmapFactory.decodeByteArray(abyte1, 0, abyte1.length);
                int j3 = bitmap3.getHeight();
                canvas.drawBitmap(bitmap3, (l1 - bitmap3.getWidth()) / 2, -j3 / 2, null);
            } else
            {
                byte abyte0[] = Base64.decode(k, 0);
                Bitmap bitmap2 = BitmapFactory.decodeByteArray(abyte0, 0, abyte0.length);
                int i3 = bitmap2.getHeight();
                canvas.drawBitmap(bitmap2, (l1 - bitmap2.getWidth()) / 2, (k1 - i3) / 2, null);
            }
            try
            {
                FileOutputStream fileoutputstream = new FileOutputStream(file1);
                bitmap1.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, fileoutputstream);
                fileoutputstream.flush();
                fileoutputstream.close();
            }
            catch (Exception exception) { }
            as = new String[1];
            as[0] = file1.toString();
            MediaScannerConnection.scanFile(this, as, null, new e(this));
            return;
        }
        j2 = 0;
label0:
        {
            if (j2 < k1)
            {
                break label0;
            }
            i2++;
        }
          goto _L8
        k2 = bitmap.getPixel(i2, j2);
        l2 += Color.red(k2);
        l3 += Color.green(k2);
        l4 += Color.blue(k2);
        j2++;
        break MISSING_BLOCK_LABEL_383;
    }

    public void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        j = getString(0x7f080007);
        k = getString(0x7f080008);
        if (!isTaskRoot())
        {
            Intent intent = getIntent();
            String s = intent.getAction();
            if (intent.hasCategory("android.intent.category.LAUNCHER") && s != null && s.equals("android.intent.action.MAIN"))
            {
                super.finish();
                return;
            }
        }
        ps.hacking.hackyeaster.android.i.a(this);
        a();
        g = (SensorManager)getSystemService("sensor");
        b();
        a.setOnKeyListener(new a(this, this));
    }

    public void onPause()
    {
        super.onPause();
        e();
    }

    public void onSensorChanged(SensorEvent sensorevent)
    {
        if (sensorevent.sensor.getType() == 1)
        {
            l = sensorevent.values;
            g.unregisterListener(this, h);
            h = null;
        }
        if (sensorevent.sensor.getType() == 2)
        {
            m = sensorevent.values;
            g.unregisterListener(this, i);
            i = null;
        }
        j();
    }

}
