// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.hackyeaster.android;

import android.os.Bundle;
import com.panoramagl.PLView;
import com.panoramagl.h.b;

public class PanoramaActivity extends PLView
{

    public PanoramaActivity()
    {
    }

    public void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        a(new b("res://raw/json_cubic"));
    }
}
