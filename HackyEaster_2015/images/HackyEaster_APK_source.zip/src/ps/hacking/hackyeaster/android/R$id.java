// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.hackyeaster.android;


public final class 
{

    public static final int appView = 0x7f07000c;
    public static final int decode = 0x7f070000;
    public static final int decode_failed = 0x7f070001;
    public static final int decode_succeeded = 0x7f070002;
    public static final int launch_product_query = 0x7f070003;
    public static final int preview_view = 0x7f070007;
    public static final int quit = 0x7f070004;
    public static final int relativeLayout = 0x7f07000b;
    public static final int restart_preview = 0x7f070005;
    public static final int result_view = 0x7f070009;
    public static final int return_scan_result = 0x7f070006;
    public static final int splashImage = 0x7f07000d;
    public static final int status_view = 0x7f07000a;
    public static final int viewfinder_view = 0x7f070008;

    public ()
    {
    }
}
