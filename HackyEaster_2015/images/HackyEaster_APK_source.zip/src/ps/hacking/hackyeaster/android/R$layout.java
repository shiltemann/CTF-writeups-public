// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.hackyeaster.android;


public final class 
{

    public static final int capture = 0x7f030000;
    public static final int main = 0x7f030001;
    public static final int splash = 0x7f030002;

    public ()
    {
    }
}
