// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.hackyeaster.android;


public final class 
{

    public static final int hotspot = 0x7f040000;
    public static final int json_cubic = 0x7f040001;
    public static final int json_cubic_quito2 = 0x7f040002;
    public static final int json_cubic_quito3 = 0x7f040003;
    public static final int quito1_b = 0x7f040004;
    public static final int quito1_d = 0x7f040005;
    public static final int quito1_f = 0x7f040006;
    public static final int quito1_l = 0x7f040007;
    public static final int quito1_r = 0x7f040008;
    public static final int quito1_u = 0x7f040009;
    public static final int quito2_b = 0x7f04000a;
    public static final int quito2_d = 0x7f04000b;
    public static final int quito2_f = 0x7f04000c;
    public static final int quito2_l = 0x7f04000d;
    public static final int quito2_r = 0x7f04000e;
    public static final int quito2_u = 0x7f04000f;
    public static final int quito3_b = 0x7f040010;
    public static final int quito3_d = 0x7f040011;
    public static final int quito3_f = 0x7f040012;
    public static final int quito3_l = 0x7f040013;
    public static final int quito3_r = 0x7f040014;
    public static final int quito3_u = 0x7f040015;

    public ()
    {
    }
}
