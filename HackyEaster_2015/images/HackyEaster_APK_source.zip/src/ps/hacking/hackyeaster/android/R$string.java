// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.hackyeaster.android;


public final class 
{

    public static final int action_settings = 0x7f080005;
    public static final int app_name = 0x7f080004;
    public static final int button_ok = 0x7f080003;
    public static final int ft = 0x7f080007;
    public static final int msg_camera_framework_bug = 0x7f080000;
    public static final int msg_default_status = 0x7f080001;
    public static final int result_text = 0x7f080002;
    public static final int rick = 0x7f080008;
    public static final int splash_text = 0x7f080006;

    public ()
    {
    }
}
