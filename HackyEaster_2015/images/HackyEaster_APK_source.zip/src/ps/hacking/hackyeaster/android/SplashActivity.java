// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.hackyeaster.android;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;

// Referenced classes of package ps.hacking.hackyeaster.android:
//            g

public class SplashActivity extends Activity
{

    public SplashActivity()
    {
    }

    protected void onCreate(Bundle bundle)
    {
        super.onCreate(bundle);
        setContentView(0x7f030002);
        (new Handler()).postDelayed(new g(this), 1000L);
    }
}
