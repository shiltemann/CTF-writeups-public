// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.hackyeaster.android;

import android.view.KeyEvent;
import android.view.View;
import android.webkit.WebView;

// Referenced classes of package ps.hacking.hackyeaster.android:
//            Activity

class a
    implements android.view.View.OnKeyListener
{

    final Activity a;
    private final Activity b;

    a(Activity activity, Activity activity1)
    {
        a = activity;
        b = activity1;
        super();
    }

    public boolean onKey(View view, int i, KeyEvent keyevent)
    {
        if (keyevent.getAction() == 1)
        {
            if (i == 4 && !Activity.a(a))
            {
                String s = a.a.getUrl();
                if (s != null && s.indexOf("/index.html") > 0)
                {
                    b.finish();
                    return true;
                }
                if (a.a.canGoBack())
                {
                    a.a.goBack();
                }
            }
            return a.onKeyUp(i, keyevent);
        } else
        {
            return a.onKeyDown(i, keyevent);
        }
    }
}
