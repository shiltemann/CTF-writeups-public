// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.hackyeaster.android;

import android.webkit.WebChromeClient;

// Referenced classes of package ps.hacking.hackyeaster.android:
//            Activity

class b extends WebChromeClient
{

    final Activity a;

    b(Activity activity)
    {
        a = activity;
        super();
    }

    public void onGeolocationPermissionsShowPrompt(String s, android.webkit.GeolocationPermissions.Callback callback)
    {
        callback.invoke(s, true, false);
    }
}
