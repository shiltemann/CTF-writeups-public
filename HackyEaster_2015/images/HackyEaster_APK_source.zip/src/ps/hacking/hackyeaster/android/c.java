// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.hackyeaster.android;

import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.webkit.WebView;
import android.webkit.WebViewClient;

// Referenced classes of package ps.hacking.hackyeaster.android:
//            i, Activity, f

class c extends WebViewClient
{

    final Activity a;
    private final Activity b;

    c(Activity activity, Activity activity1)
    {
        a = activity;
        b = activity1;
        super();
    }

    public void onPageFinished(WebView webview, String s)
    {
        webview.loadUrl((new StringBuilder("javascript:injectUserData('")).append(i.a()).append("');").toString());
    }

    public boolean shouldOverrideUrlLoading(WebView webview, String s)
    {
        if (!"ps://scan".equals(s)) goto _L2; else goto _L1
_L1:
        boolean flag1;
        Activity.b(a);
        flag1 = true;
_L4:
        return flag1;
_L2:
        if (s.startsWith("ps://alert?"))
        {
            Log.i("ps", (new StringBuilder("url:   ")).append(s).toString());
            Uri uri2 = Uri.parse(s);
            Activity.a(a, uri2.getQueryParameter("title"), uri2.getQueryParameter("text"), b);
            return true;
        }
        if ("ps://panorama".equals(s))
        {
            Activity.c(a);
            return true;
        }
        if ("ps://snapshot".equals(s))
        {
            Activity.d(a);
            return true;
        }
        if ("ps://sensors".equals(s))
        {
            Activity.e(a);
            return true;
        }
        if (s != null && s.startsWith("ps://store?"))
        {
            Uri uri1 = Uri.parse(s);
            String s4 = uri1.getQueryParameter("name");
            String s5 = uri1.getQueryParameter("ticket");
            boolean flag2 = i.a(b, s4, s5);
            int k = 0;
            boolean flag;
            String s1;
            int j;
            Uri uri;
            String s2;
            String s3;
            if (!flag2)
            {
                k = -1;
            }
            webview.loadUrl((new StringBuilder("javascript:storeFeedback('{\"status\": ")).append(k).append("}')").toString());
            return true;
        }
        if (s != null && s.startsWith("ps://auth?"))
        {
            uri = Uri.parse(s);
            s2 = uri.getQueryParameter("email");
            s3 = uri.getQueryParameter("pass");
            (new f()).execute(new Object[] {
                s2, s3, webview
            });
            return true;
        }
        if (s != null && s.startsWith("ps://pin?"))
        {
            s1 = Uri.parse(s).getQuery();
            j = Activity.a(a, s1, b);
            webview.loadUrl((new StringBuilder("javascript:pinFeedback('{\"status\": ")).append(j).append("}')").toString());
            return true;
        }
        if (s.startsWith("ps://twitter"))
        {
            Activity.f(a);
            return true;
        }
        if (s.startsWith("http"))
        {
            break; /* Loop/switch isn't completed */
        }
        flag = s.startsWith("mailto:");
        flag1 = false;
        if (!flag) goto _L4; else goto _L3
_L3:
        a.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(s)));
        return true;
    }
}
