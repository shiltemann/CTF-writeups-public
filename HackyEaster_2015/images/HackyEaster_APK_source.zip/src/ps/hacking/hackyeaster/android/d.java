// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.hackyeaster.android;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

// Referenced classes of package ps.hacking.hackyeaster.android:
//            Activity

class d extends BroadcastReceiver
{

    final Activity a;

    d(Activity activity)
    {
        a = activity;
        super();
    }

    public void onReceive(Context context, Intent intent)
    {
        Toast.makeText(context, "Download completed!", 0).show();
    }
}
