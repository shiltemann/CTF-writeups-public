// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.hackyeaster.android;

import android.os.AsyncTask;
import android.util.Log;
import android.webkit.WebView;
import java.net.URI;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.CookieStore;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.cookie.Cookie;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

public class f extends AsyncTask
{

    public f()
    {
    }

    protected transient String a(Object aobj[])
    {
        String s = (String)aobj[0];
        String s1 = (String)aobj[1];
        WebView webview = (WebView)aobj[2];
        String as[] = a(s, s1);
        String s2;
        String s3;
        int i;
        if (as != null && as.length == 2)
        {
            s3 = as[0];
            s2 = as[1];
            i = 0;
        } else
        {
            s2 = "";
            s3 = "";
            i = 1;
        }
        webview.loadUrl((new StringBuilder("javascript:authFeedback('{\"rc\": ")).append(i).append(", \"name\": \"").append(s3).append("\", \"nation\": \"").append(s2).append("\"}');").toString());
        return null;
    }

    public String[] a(String s, String s1)
    {
        DefaultHttpClient defaulthttpclient;
        defaulthttpclient = new DefaultHttpClient();
        HttpResponse httpresponse = defaulthttpclient.execute(new HttpGet(new URI("https://www.hacking-lab.com/user/login/")));
        if (httpresponse.getStatusLine().getStatusCode() == 200)
        {
            break MISSING_BLOCK_LABEL_83;
        }
        Log.i("he", (new StringBuilder("s ")).append(httpresponse.getStatusLine().getStatusCode()).toString());
        return null;
        String s2;
        String s4;
        String s5;
        List list;
        Iterator iterator;
        HttpPost httppost;
        HttpResponse httpresponse1;
        String s3;
        Matcher matcher;
        Matcher matcher1;
        String as[];
        boolean flag;
        Cookie cookie;
        try
        {
            list = defaulthttpclient.getCookieStore().getCookies();
        }
        catch (Exception exception)
        {
            return null;
        }
        if (list == null)
        {
            break MISSING_BLOCK_LABEL_504;
        }
        iterator = list.iterator();
_L4:
        if (!iterator.hasNext())
        {
            break MISSING_BLOCK_LABEL_504;
        }
          goto _L1
_L5:
        if (s2 == null)
        {
            break MISSING_BLOCK_LABEL_510;
        }
        if (s2.equals(""))
        {
            break MISSING_BLOCK_LABEL_510;
        }
          goto _L2
_L1:
        cookie = (Cookie)iterator.next();
        if (!"HLSSL".equals(cookie.getName())) goto _L4; else goto _L3
_L3:
        s2 = cookie.getValue();
          goto _L5
_L2:
        httppost = new HttpPost();
        httppost.setURI(new URI("https://www.hacking-lab.com/user/login/index.html"));
        httppost.setEntity(new StringEntity(String.format("return=&eventid=&uk=&userEmail=%s&userPassword=%s&login=Login", new Object[] {
            s, s1
        }), "UTF-8"));
        httppost.addHeader("Content-Type", "application/x-www-form-urlencoded");
        httppost.addHeader("Connection", "keep-alive");
        httppost.addHeader("Cookie", (new StringBuilder("HLSSL=")).append(s2).toString());
        EntityUtils.toString(defaulthttpclient.execute(httppost).getEntity());
        httpresponse1 = defaulthttpclient.execute(new HttpGet(new URI("https://www.hacking-lab.com/user/myprofile/editprofile.html")));
        if (httpresponse1.getStatusLine().getStatusCode() != 200)
        {
            return null;
        }
        s3 = EntityUtils.toString(httpresponse1.getEntity());
        matcher = Pattern.compile("<td>\\s*Nickname:\\s*</td>\\s*<td>\\s*<strong>\\s*([\\w.+\\-]+)\\s*</strong>\\s*</td>").matcher(s3);
        if (!matcher.find() || matcher.groupCount() != 1)
        {
            break MISSING_BLOCK_LABEL_497;
        }
        s4 = matcher.group(1);
_L11:
        matcher1 = Pattern.compile("/([a-zA-z]{2,3}).png\" id=\"imgNationality\"").matcher(s3);
        if (!matcher1.find() || matcher1.groupCount() != 1) goto _L7; else goto _L6
_L6:
        s5 = matcher1.group(1);
_L10:
        if ("".equals(s4)) goto _L9; else goto _L8
_L8:
        flag = "".equals(s5);
        if (!flag)
        {
            try
            {
                defaulthttpclient.execute(new HttpGet(new URI("https://www.hacking-lab.com/events/registerform.html?eventid=669")));
            }
            catch (Exception exception1) { }
        }
_L9:
        as = (new String[] {
            s4, s5
        });
        return as;
_L7:
        s5 = "";
          goto _L10
        s4 = "";
          goto _L11
        s2 = null;
          goto _L5
        return null;
    }

    protected transient Object doInBackground(Object aobj[])
    {
        return a((Object[])aobj);
    }
}
