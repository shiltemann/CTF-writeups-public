// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.hackyeaster.android;

import android.content.Intent;

// Referenced classes of package ps.hacking.hackyeaster.android:
//            Activity, SplashActivity

class g
    implements Runnable
{

    final SplashActivity a;

    g(SplashActivity splashactivity)
    {
        a = splashactivity;
        super();
    }

    public void run()
    {
        a.startActivity(new Intent(a, ps/hacking/hackyeaster/android/Activity));
        a.finish();
    }
}
