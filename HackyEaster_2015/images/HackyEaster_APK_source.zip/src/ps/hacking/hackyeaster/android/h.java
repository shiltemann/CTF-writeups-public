// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.hackyeaster.android;


public class h
{

    public static String a(String s, boolean flag)
    {
label0:
        {
label1:
            {
label2:
                {
label3:
                    {
label4:
                        {
                            if (s == null || s.length() == 0)
                            {
                                return "";
                            }
                            int i = s.length();
                            StringBuilder stringbuilder = new StringBuilder(i + 4);
                            int j = 0;
label5:
                            do
                            {
                                {
                                    if (j >= i)
                                    {
                                        return stringbuilder.toString();
                                    }
                                    char c = s.charAt(j);
                                    switch (c)
                                    {
                                    default:
                                        if (c < ' ')
                                        {
                                            String s1 = (new StringBuilder("000")).append(Integer.toHexString(c)).toString();
                                            stringbuilder.append((new StringBuilder("\\u")).append(s1.substring(-4 + s1.length())).toString());
                                        } else
                                        if (c != '\'' || !flag)
                                        {
                                            stringbuilder.append(c);
                                        }
                                        break;

                                    case 8: // '\b'
                                        break label4;

                                    case 9: // '\t'
                                        break label3;

                                    case 10: // '\n'
                                        break label2;

                                    case 12: // '\f'
                                        break label1;

                                    case 13: // '\r'
                                        break label0;

                                    case 34: // '"'
                                    case 47: // '/'
                                    case 92: // '\\'
                                        break label5;
                                    }
                                }
                                j++;
                            } while (true);
                            stringbuilder.append('\\');
                            stringbuilder.append(c);
                            break MISSING_BLOCK_LABEL_190;
                        }
                        stringbuilder.append("\\b");
                        break MISSING_BLOCK_LABEL_190;
                    }
                    stringbuilder.append("\\t");
                    break MISSING_BLOCK_LABEL_190;
                }
                stringbuilder.append("\\n");
                break MISSING_BLOCK_LABEL_190;
            }
            stringbuilder.append("\\f");
            break MISSING_BLOCK_LABEL_190;
        }
        stringbuilder.append("\\r");
        break MISSING_BLOCK_LABEL_190;
    }
}
