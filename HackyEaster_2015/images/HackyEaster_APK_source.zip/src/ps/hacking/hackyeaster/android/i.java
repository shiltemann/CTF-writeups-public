// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.hackyeaster.android;

import android.content.Context;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class i
{

    private static String a;
    private static String b;

    public i()
    {
    }

    public static String a()
    {
        StringBuilder stringbuilder = new StringBuilder("{\"userName\": \"");
        String s;
        StringBuilder stringbuilder1;
        String s1;
        if (a == null)
        {
            s = "";
        } else
        {
            s = a;
        }
        stringbuilder1 = stringbuilder.append(s).append("\", \"ticket\": \"");
        if (b == null)
        {
            s1 = "";
        } else
        {
            s1 = b;
        }
        return stringbuilder1.append(s1).append("\"}").toString();
    }

    private static void a(Context context, String s)
    {
        FileOutputStream fileoutputstream = context.openFileOutput("bJ4UwUb5ASvFdBocVkqe", 0);
        fileoutputstream.write(s.getBytes());
        fileoutputstream.flush();
        fileoutputstream.close();
    }

    public static boolean a(Context context)
    {
        ps/hacking/hackyeaster/android/i;
        JVM INSTR monitorenter ;
        String as[];
        a = null;
        b = null;
        if (!context.getFileStreamPath("bJ4UwUb5ASvFdBocVkqe").exists())
        {
            break MISSING_BLOCK_LABEL_60;
        }
        as = b(context).split("\\|");
        if (as == null)
        {
            break MISSING_BLOCK_LABEL_55;
        }
        if (as.length == 2)
        {
            a = as[0];
            b = as[1];
        }
        ps/hacking/hackyeaster/android/i;
        JVM INSTR monitorexit ;
        return true;
        ps/hacking/hackyeaster/android/i;
        JVM INSTR monitorexit ;
        return false;
        IOException ioexception;
        ioexception;
        ps/hacking/hackyeaster/android/i;
        JVM INSTR monitorexit ;
        return false;
        Exception exception;
        exception;
        ps/hacking/hackyeaster/android/i;
        JVM INSTR monitorexit ;
        throw exception;
    }

    public static boolean a(Context context, String s, String s1)
    {
        ps/hacking/hackyeaster/android/i;
        JVM INSTR monitorenter ;
        a(context, (new StringBuilder(String.valueOf(s))).append("|").append(s1).toString());
        a = s;
        b = s1;
        ps/hacking/hackyeaster/android/i;
        JVM INSTR monitorexit ;
        return true;
        IOException ioexception;
        ioexception;
        ps/hacking/hackyeaster/android/i;
        JVM INSTR monitorexit ;
        return false;
        Exception exception;
        exception;
        ps/hacking/hackyeaster/android/i;
        JVM INSTR monitorexit ;
        throw exception;
    }

    private static String b(Context context)
    {
        return (new BufferedReader(new InputStreamReader(context.openFileInput("bJ4UwUb5ASvFdBocVkqe")))).readLine();
    }
}
