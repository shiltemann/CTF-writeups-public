// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing;


public final class a extends Enum
{

    public static final a a;
    public static final a b;
    public static final a c;
    public static final a d;
    public static final a e;
    public static final a f;
    public static final a g;
    public static final a h;
    public static final a i;
    public static final a j;
    public static final a k;
    public static final a l;
    public static final a m;
    public static final a n;
    public static final a o;
    public static final a p;
    public static final a q;
    private static final a r[];

    private a(String s, int i1)
    {
        super(s, i1);
    }

    public static a valueOf(String s)
    {
        return (a)Enum.valueOf(ps/hacking/zxing/a, s);
    }

    public static a[] values()
    {
        return (a[])r.clone();
    }

    static 
    {
        a = new a("AZTEC", 0);
        b = new a("CODABAR", 1);
        c = new a("CODE_39", 2);
        d = new a("CODE_93", 3);
        e = new a("CODE_128", 4);
        f = new a("DATA_MATRIX", 5);
        g = new a("EAN_8", 6);
        h = new a("EAN_13", 7);
        i = new a("ITF", 8);
        j = new a("MAXICODE", 9);
        k = new a("PDF_417", 10);
        l = new a("QR_CODE", 11);
        m = new a("RSS_14", 12);
        n = new a("RSS_EXPANDED", 13);
        o = new a("UPC_A", 14);
        p = new a("UPC_E", 15);
        q = new a("UPC_EAN_EXTENSION", 16);
        a aa[] = new a[17];
        aa[0] = a;
        aa[1] = b;
        aa[2] = c;
        aa[3] = d;
        aa[4] = e;
        aa[5] = f;
        aa[6] = g;
        aa[7] = h;
        aa[8] = i;
        aa[9] = j;
        aa[10] = k;
        aa[11] = l;
        aa[12] = m;
        aa[13] = n;
        aa[14] = o;
        aa[15] = p;
        aa[16] = q;
        r = aa;
    }
}
