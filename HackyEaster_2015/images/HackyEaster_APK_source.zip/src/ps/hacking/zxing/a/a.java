// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.a;

import ps.hacking.zxing.b.b;
import ps.hacking.zxing.b.g;
import ps.hacking.zxing.o;

public final class a extends g
{

    private final boolean a;
    private final int b;
    private final int c;

    public a(b b1, o ao[], boolean flag, int i, int j)
    {
        super(b1, ao);
        a = flag;
        b = i;
        c = j;
    }

    public int a()
    {
        return c;
    }

    public int b()
    {
        return b;
    }

    public boolean c()
    {
        return a;
    }
}
