// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.a.a;

import ps.hacking.zxing.b.b;
import ps.hacking.zxing.b.b.c;
import ps.hacking.zxing.b.b.d;
import ps.hacking.zxing.b.e;
import ps.hacking.zxing.f;

// Referenced classes of package ps.hacking.zxing.a.a:
//            b, c

public final class a
{

    private static final int a[] = {
        0, 104, 240, 408, 608
    };
    private static final int b[] = {
        0, 128, 288, 480, 704, 960, 1248, 1568, 1920, 2304, 
        2720, 3168, 3648, 4160, 4704, 5280, 5888, 6528, 7200, 7904, 
        8640, 9408, 10208, 11040, 11904, 12800, 13728, 14688, 15680, 16704, 
        17760, 18848, 19968
    };
    private static final int c[] = {
        0, 17, 40, 51, 76
    };
    private static final int d[] = {
        0, 21, 48, 60, 88, 120, 156, 196, 240, 230, 
        272, 316, 364, 416, 470, 528, 588, 652, 720, 790, 
        864, 940, 1020, 920, 992, 1066, 1144, 1224, 1306, 1392, 
        1480, 1570, 1664
    };
    private static final String e[] = {
        "CTRL_PS", " ", "A", "B", "C", "D", "E", "F", "G", "H", 
        "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", 
        "S", "T", "U", "V", "W", "X", "Y", "Z", "CTRL_LL", "CTRL_ML", 
        "CTRL_DL", "CTRL_BS"
    };
    private static final String f[] = {
        "CTRL_PS", " ", "a", "b", "c", "d", "e", "f", "g", "h", 
        "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", 
        "s", "t", "u", "v", "w", "x", "y", "z", "CTRL_US", "CTRL_ML", 
        "CTRL_DL", "CTRL_BS"
    };
    private static final String g[] = {
        "CTRL_PS", " ", "\001", "\002", "\003", "\004", "\005", "\006", "\007", "\b", 
        "\t", "\n", "\013", "\f", "\r", "\033", "\034", "\035", "\036", "\037", 
        "@", "\\", "^", "_", "`", "|", "~", "\177", "CTRL_LL", "CTRL_UL", 
        "CTRL_PL", "CTRL_BS"
    };
    private static final String h[] = {
        "", "\r", "\r\n", ". ", ", ", ": ", "!", "\"", "#", "$", 
        "%", "&", "'", "(", ")", "*", "+", ",", "-", ".", 
        "/", ":", ";", "<", "=", ">", "?", "[", "]", "{", 
        "}", "CTRL_UL"
    };
    private static final String i[] = {
        "CTRL_PS", " ", "0", "1", "2", "3", "4", "5", "6", "7", 
        "8", "9", ",", ".", "CTRL_UL", "CTRL_US"
    };
    private int j;
    private int k;
    private ps.hacking.zxing.a.a l;
    private int m;

    public a()
    {
    }

    private static int a(boolean aflag[], int i1, int j1)
    {
        int k1 = 0;
        for (int l1 = i1; l1 < i1 + j1; l1++)
        {
            k1 <<= 1;
            if (aflag[l1])
            {
                k1++;
            }
        }

        return k1;
    }

    private static String a(ps.hacking.zxing.a.a.c c1, int i1)
    {
        switch (b.a[c1.ordinal()])
        {
        default:
            return "";

        case 1: // '\001'
            return e[i1];

        case 2: // '\002'
            return f[i1];

        case 3: // '\003'
            return g[i1];

        case 4: // '\004'
            return h[i1];

        case 5: // '\005'
            return i[i1];
        }
    }

    private String a(boolean aflag[])
    {
        int i1;
        ps.hacking.zxing.a.a.c c2;
        StringBuilder stringbuilder;
        boolean flag;
        boolean flag1;
        boolean flag2;
        boolean flag3;
        int j1;
        ps.hacking.zxing.a.a.c c3;
        i1 = k * l.b() - m;
        if (i1 > aflag.length)
        {
            throw ps.hacking.zxing.f.a();
        }
        ps.hacking.zxing.a.a.c c1 = c.a;
        c2 = c.a;
        stringbuilder = new StringBuilder(20);
        flag = false;
        flag1 = false;
        flag2 = false;
        flag3 = false;
        j1 = 0;
        c3 = c1;
_L9:
        if (flag) goto _L2; else goto _L1
_L1:
        boolean flag4;
        ps.hacking.zxing.a.a.c c4;
        if (flag1)
        {
            flag4 = true;
            c4 = c3;
        } else
        {
            flag4 = flag2;
            c4 = c2;
        }
        if (!flag3) goto _L4; else goto _L3
_L3:
        if (i1 - j1 >= 5) goto _L5; else goto _L2
_L2:
        return stringbuilder.toString();
_L5:
        int l2;
        int i3;
        l2 = a(aflag, j1, 5);
        i3 = j1 + 5;
        if (l2 != 0)
        {
            break; /* Loop/switch isn't completed */
        }
        if (i1 - i3 < 11)
        {
            continue; /* Loop/switch isn't completed */
        }
        l2 = 31 + a(aflag, i3, 11);
        i3 += 11;
        break; /* Loop/switch isn't completed */
        if (true) goto _L2; else goto _L6
_L6:
        int j3;
        int k3;
        j3 = i3;
        k3 = 0;
_L10:
        if (k3 >= l2)
        {
            break MISSING_BLOCK_LABEL_479;
        }
        if (i1 - j3 >= 8) goto _L8; else goto _L7
_L7:
        boolean flag6 = true;
_L14:
        boolean flag5;
        int i2;
        ps.hacking.zxing.a.a.c c5;
        flag = flag6;
        flag3 = false;
        flag5 = flag1;
        i2 = j3;
        c5 = c2;
_L12:
        byte byte0;
        if (flag4)
        {
            j1 = i2;
            c2 = c4;
            c3 = c4;
            flag2 = false;
            flag1 = false;
        } else
        {
            j1 = i2;
            c2 = c5;
            flag1 = flag5;
            c3 = c4;
            flag2 = flag4;
        }
          goto _L9
_L8:
        stringbuilder.append((char)a(aflag, j3, 8));
        j3 += 8;
        k3++;
          goto _L10
_L4:
        if (c2 != ps.hacking.zxing.a.a.c.f)
        {
            break MISSING_BLOCK_LABEL_311;
        }
        if (i1 - j1 < 8) goto _L2; else goto _L11
_L11:
        int j2 = a(aflag, j1, 8);
        int k2 = j1 + 8;
        stringbuilder.append((char)j2);
        c5 = c2;
        flag5 = flag1;
        i2 = k2;
          goto _L12
        byte0 = 5;
        if (c2 == ps.hacking.zxing.a.a.c.d)
        {
            byte0 = 4;
        }
        if (i1 - j1 < byte0) goto _L2; else goto _L13
_L13:
label0:
        {
            int k1 = a(aflag, j1, byte0);
            int l1 = j1 + byte0;
            String s = a(c2, k1);
            if (!s.startsWith("CTRL_"))
            {
                break label0;
            }
            c2 = a(s.charAt(5));
            if (s.charAt(6) != 'S')
            {
                break MISSING_BLOCK_LABEL_430;
            }
            flag5 = true;
            if (s.charAt(5) == 'B')
            {
                flag3 = true;
                i2 = l1;
                c5 = c2;
            } else
            {
                i2 = l1;
                c5 = c2;
            }
        }
          goto _L12
        stringbuilder.append(s);
        flag5 = flag1;
        i2 = l1;
        c5 = c2;
          goto _L12
        flag6 = flag;
          goto _L14
    }

    private static ps.hacking.zxing.a.a.c a(char c1)
    {
        switch (c1)
        {
        default:
            return c.a;

        case 76: // 'L'
            return ps.hacking.zxing.a.a.c.b;

        case 80: // 'P'
            return ps.hacking.zxing.a.a.c.e;

        case 77: // 'M'
            return ps.hacking.zxing.a.a.c.c;

        case 68: // 'D'
            return ps.hacking.zxing.a.a.c.d;

        case 66: // 'B'
            return ps.hacking.zxing.a.a.c.f;
        }
    }

    private boolean[] a(b b1)
    {
        boolean aflag[];
        int i1;
        int j1;
        int k1;
        int l1;
        int i2;
        if (l.c())
        {
            if (l.a() > a.length)
            {
                throw ps.hacking.zxing.f.a();
            }
            aflag = new boolean[a[l.a()]];
            j = c[l.a()];
        } else
        {
            if (l.a() > b.length)
            {
                throw ps.hacking.zxing.f.a();
            }
            aflag = new boolean[b[l.a()]];
            j = d[l.a()];
        }
        i1 = l.a();
        j1 = b1.e();
        k1 = 0;
        l1 = 0;
        i2 = j1;
        for (int j2 = i1; j2 != 0;)
        {
            int k2 = 0;
            int l2 = 0;
            for (; k2 < -4 + i2 * 2; k2++)
            {
                aflag[l1 + k2] = b1.a(k1 + l2, k1 + k2 / 2);
                aflag[k2 + (-4 + (l1 + i2 * 2))] = b1.a(k1 + k2 / 2, (-1 + (k1 + i2)) - l2);
                l2 = (l2 + 1) % 2;
            }

            int i3 = 1 + i2 * 2;
            int j3 = 0;
            for (; i3 > 5; i3--)
            {
                aflag[1 + (-8 + (l1 + i2 * 4) + (i2 * 2 - i3))] = b1.a((-1 + (k1 + i2)) - j3, -1 + (k1 + i3 / 2));
                aflag[1 + (-12 + (l1 + i2 * 6) + (i2 * 2 - i3))] = b1.a(-1 + (k1 + i3 / 2), k1 + j3);
                j3 = (j3 + 1) % 2;
            }

            int k3 = k1 + 2;
            int l3 = l1 + (-16 + i2 * 8);
            int i4 = j2 - 1;
            i2 -= 4;
            j2 = i4;
            k1 = k3;
            l1 = l3;
        }

        return aflag;
    }

    private static b b(b b1)
    {
        int i1 = 1 + 2 * ((-1 + b1.d()) / 2 / 16);
        b b2 = new b(b1.d() - i1, b1.e() - i1);
        int j1 = 0;
        int k1 = 0;
        while (j1 < b1.d()) 
        {
            if ((b1.d() / 2 - j1) % 16 != 0)
            {
                int l1 = 0;
                int i2 = 0;
                while (l1 < b1.e()) 
                {
                    if ((b1.d() / 2 - l1) % 16 != 0)
                    {
                        if (b1.a(j1, l1))
                        {
                            b2.b(k1, i2);
                        }
                        i2++;
                    }
                    l1++;
                }
                k1++;
            }
            j1++;
        }
        return b2;
    }

    private boolean[] b(boolean aflag[])
    {
        ps.hacking.zxing.b.b.a a1;
        int i1;
        int j1;
        int k1;
        int ai[];
        if (l.a() <= 2)
        {
            k = 6;
            a1 = ps.hacking.zxing.b.b.a.c;
        } else
        if (l.a() <= 8)
        {
            k = 8;
            a1 = ps.hacking.zxing.b.b.a.g;
        } else
        if (l.a() <= 22)
        {
            k = 10;
            a1 = ps.hacking.zxing.b.b.a.b;
        } else
        {
            k = 12;
            a1 = ps.hacking.zxing.b.b.a.a;
        }
        i1 = l.b();
        if (l.c())
        {
            j1 = a[l.a()] - j * k;
            k1 = c[l.a()] - i1;
        } else
        {
            j1 = b[l.a()] - j * k;
            k1 = d[l.a()] - i1;
        }
        ai = new int[j];
        for (int l1 = 0; l1 < j; l1++)
        {
            int l3 = 1;
            int i4 = 1;
            for (; l3 <= k; l3++)
            {
                if (aflag[j1 + ((l1 * k + k) - l3)])
                {
                    ai[l1] = i4 + ai[l1];
                }
                i4 <<= 1;
            }

        }

        boolean aflag1[];
        int i2;
        try
        {
            (new c(a1)).a(ai, k1);
        }
        catch (d d1)
        {
            throw ps.hacking.zxing.f.a();
        }
        m = 0;
        aflag1 = new boolean[i1 * k];
        i2 = 0;
        int i3;
        for (int j2 = 0; i2 < i1; j2 = i3)
        {
            int k2 = 1 << -1 + k;
            int l2 = 0;
            boolean flag = false;
            i3 = j2;
            int j3 = k2;
            int k3 = 0;
            while (k3 < k) 
            {
                boolean flag1;
                if ((j3 & ai[i2]) == j3)
                {
                    flag1 = true;
                } else
                {
                    flag1 = false;
                }
                if (l2 == -1 + k)
                {
                    if (flag1 == flag)
                    {
                        throw ps.hacking.zxing.f.a();
                    }
                    i3++;
                    m = 1 + m;
                    l2 = 0;
                    flag = false;
                } else
                {
                    if (flag == flag1)
                    {
                        l2++;
                    } else
                    {
                        l2 = 1;
                        flag = flag1;
                    }
                    aflag1[(k3 + i2 * k) - i3] = flag1;
                }
                j3 >>>= 1;
                k3++;
            }
            i2++;
        }

        return aflag1;
    }

    public e a(ps.hacking.zxing.a.a a1)
    {
        l = a1;
        b b1 = a1.d();
        if (!l.c())
        {
            b1 = b(l.d());
        }
        return new e(null, a(b(a(b1))), null, null);
    }

}
