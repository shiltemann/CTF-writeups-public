// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.a;

import java.util.Map;
import ps.hacking.zxing.a.b.a;
import ps.hacking.zxing.c;
import ps.hacking.zxing.e;
import ps.hacking.zxing.k;
import ps.hacking.zxing.m;
import ps.hacking.zxing.n;
import ps.hacking.zxing.p;

// Referenced classes of package ps.hacking.zxing.a:
//            a

public final class b
    implements k
{

    public b()
    {
    }

    public m a(c c1, Map map)
    {
        ps.hacking.zxing.a.a a1 = (new a(c1.c())).a();
        ps.hacking.zxing.o ao[] = a1.e();
        if (map != null)
        {
            p p1 = (p)map.get(e.h);
            if (p1 != null)
            {
                int i = ao.length;
                for (int j = 0; j < i; j++)
                {
                    p1.a(ao[j]);
                }

            }
        }
        ps.hacking.zxing.b.e e1 = (new ps.hacking.zxing.a.a.a()).a(a1);
        m m1 = new m(e1.b(), e1.a(), ao, ps.hacking.zxing.a.a);
        java.util.List list = e1.c();
        if (list != null)
        {
            m1.a(n.c, list);
        }
        String s = e1.d();
        if (s != null)
        {
            m1.a(n.d, s);
        }
        return m1;
    }

    public void a()
    {
    }
}
