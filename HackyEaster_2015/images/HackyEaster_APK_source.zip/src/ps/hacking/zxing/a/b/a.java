// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.a.b;

import ps.hacking.zxing.b.b;
import ps.hacking.zxing.b.b.c;
import ps.hacking.zxing.b.b.d;
import ps.hacking.zxing.b.i;
import ps.hacking.zxing.o;

// Referenced classes of package ps.hacking.zxing.a.b:
//            c

public final class a
{

    private final b a;
    private boolean b;
    private int c;
    private int d;
    private int e;
    private int f;

    public a(b b1)
    {
        a = b1;
    }

    private int a(ps.hacking.zxing.a.b.c c1, ps.hacking.zxing.a.b.c c2)
    {
        float f1 = b(c1, c2);
        float f2 = (float)(c2.a - c1.a) / f1;
        float f3 = (float)(c2.b - c1.b) / f1;
        float f4 = c1.a;
        float f5 = c1.b;
        boolean flag = a.a(c1.a, c1.b);
        int j = 0;
        float f6 = f4;
        float f7 = f5;
        for (int k = 0; (float)k < f1; k++)
        {
            f6 += f2;
            f7 += f3;
            if (a.a(ps.hacking.zxing.b.a.a.a(f6), ps.hacking.zxing.b.a.a.a(f7)) != flag)
            {
                j++;
            }
        }

        float f8 = (float)j / f1;
        if ((double)f8 > 0.10000000000000001D && (double)f8 < 0.90000000000000002D)
        {
            return 0;
        }
        if ((double)f8 <= 0.10000000000000001D)
        {
            return !flag ? -1 : 1;
        }
        return !flag ? 1 : -1;
    }

    private ps.hacking.zxing.a.b.c a(ps.hacking.zxing.a.b.c c1, boolean flag, int j, int k)
    {
        int l = j + c1.a;
        int i1;
        for (i1 = k + c1.b; a(l, i1) && a.a(l, i1) == flag; i1 += k)
        {
            l += j;
        }

        int j1 = l - j;
        int k1 = i1 - k;
        int l1;
        for (l1 = j1; a(l1, k1) && a.a(l1, k1) == flag; l1 += j) { }
        int i2 = l1 - j;
        int j2;
        for (j2 = k1; a(i2, j2) && a.a(i2, j2) == flag; j2 += k) { }
        return new ps.hacking.zxing.a.b.c(i2, j2 - k, null);
    }

    private b a(b b1, o o1, o o2, o o3, o o4)
    {
        int j;
        i k;
        float f1;
        float f2;
        float f3;
        float f4;
        float f5;
        float f6;
        float f7;
        float f8;
        float f9;
        float f10;
        float f11;
        float f12;
        if (b)
        {
            j = 11 + 4 * c;
        } else
        if (c <= 4)
        {
            j = 15 + 4 * c;
        } else
        {
            j = 15 + (4 * c + 2 * (1 + (-4 + c) / 8));
        }
        k = i.a();
        f1 = (float)j - 0.5F;
        f2 = (float)j - 0.5F;
        f3 = (float)j - 0.5F;
        f4 = (float)j - 0.5F;
        f5 = o1.a();
        f6 = o1.b();
        f7 = o4.a();
        f8 = o4.b();
        f9 = o3.a();
        f10 = o3.b();
        f11 = o2.a();
        f12 = o2.b();
        return k.a(b1, j, j, 0.5F, 0.5F, f1, 0.5F, f2, f3, 0.5F, f4, f5, f6, f7, f8, f9, f10, f11, f12);
    }

    private void a(ps.hacking.zxing.a.b.c ac[])
    {
        int j = 0;
        boolean aflag[] = a(ac[0], ac[1], 1 + 2 * e);
        boolean aflag1[] = a(ac[1], ac[2], 1 + 2 * e);
        boolean aflag2[] = a(ac[2], ac[3], 1 + 2 * e);
        boolean aflag3[] = a(ac[3], ac[0], 1 + 2 * e);
        if (aflag[0] && aflag[2 * e])
        {
            f = 0;
        } else
        if (aflag1[0] && aflag1[2 * e])
        {
            f = 1;
        } else
        if (aflag2[0] && aflag2[2 * e])
        {
            f = 2;
        } else
        if (aflag3[0] && aflag3[2 * e])
        {
            f = 3;
        } else
        {
            throw ps.hacking.zxing.i.a();
        }
        boolean aflag5[];
        if (b)
        {
            boolean aflag6[] = new boolean[28];
            for (int l = 0; l < 7; l++)
            {
                aflag6[l] = aflag[l + 2];
                aflag6[l + 7] = aflag1[l + 2];
                aflag6[l + 14] = aflag2[l + 2];
                aflag6[l + 21] = aflag3[l + 2];
            }

            aflag5 = new boolean[28];
            for (; j < 28; j++)
            {
                aflag5[j] = aflag6[(j + 7 * f) % 28];
            }

        } else
        {
            boolean aflag4[] = new boolean[40];
            for (int k = 0; k < 11; k++)
            {
                if (k < 5)
                {
                    aflag4[k] = aflag[k + 2];
                    aflag4[k + 10] = aflag1[k + 2];
                    aflag4[k + 20] = aflag2[k + 2];
                    aflag4[k + 30] = aflag3[k + 2];
                }
                if (k > 5)
                {
                    aflag4[k - 1] = aflag[k + 2];
                    aflag4[-1 + (k + 10)] = aflag1[k + 2];
                    aflag4[-1 + (k + 20)] = aflag2[k + 2];
                    aflag4[-1 + (k + 30)] = aflag3[k + 2];
                }
            }

            aflag5 = new boolean[40];
            for (; j < 40; j++)
            {
                aflag5[j] = aflag4[(j + 10 * f) % 40];
            }

        }
        a(aflag5, b);
        a(aflag5);
    }

    private void a(boolean aflag[])
    {
        byte byte0;
        byte byte1;
        int j;
        if (b)
        {
            byte0 = 2;
            byte1 = 6;
        } else
        {
            byte0 = 5;
            byte1 = 11;
        }
        for (j = 0; j < byte0; j++)
        {
            c = c << 1;
            if (aflag[j])
            {
                c = 1 + c;
            }
        }

        for (int k = byte0; k < byte0 + byte1; k++)
        {
            d = d << 1;
            if (aflag[k])
            {
                d = 1 + d;
            }
        }

        c = 1 + c;
        d = 1 + d;
    }

    private static void a(boolean aflag[], boolean flag)
    {
        byte byte0;
        byte byte1;
        int j;
        int ai[];
        if (flag)
        {
            byte0 = 7;
            byte1 = 2;
        } else
        {
            byte0 = 10;
            byte1 = 4;
        }
        j = byte0 - byte1;
        ai = new int[byte0];
        for (int k = 0; k < byte0; k++)
        {
            int l1 = 1;
            int i2 = 1;
            for (; l1 <= 4; l1++)
            {
                if (aflag[(4 + 4 * k) - l1])
                {
                    ai[k] = i2 + ai[k];
                }
                i2 <<= 1;
            }

        }

        int l;
        try
        {
            (new c(ps.hacking.zxing.b.b.a.d)).a(ai, j);
        }
        catch (d d1)
        {
            throw ps.hacking.zxing.i.a();
        }
        for (l = 0; l < byte1; l++)
        {
            int i1 = 1;
            int j1 = 1;
            while (i1 <= 4) 
            {
                int k1 = (4 + l * 4) - i1;
                boolean flag1;
                if ((j1 & ai[l]) == j1)
                {
                    flag1 = true;
                } else
                {
                    flag1 = false;
                }
                aflag[k1] = flag1;
                j1 <<= 1;
                i1++;
            }
        }

    }

    private boolean a(int j, int k)
    {
        return j >= 0 && j < a.d() && k > 0 && k < a.e();
    }

    private boolean a(ps.hacking.zxing.a.b.c c1, ps.hacking.zxing.a.b.c c2, ps.hacking.zxing.a.b.c c3, ps.hacking.zxing.a.b.c c4)
    {
        ps.hacking.zxing.a.b.c c5 = new ps.hacking.zxing.a.b.c(c1.a - 3, 3 + c1.b, null);
        ps.hacking.zxing.a.b.c c6 = new ps.hacking.zxing.a.b.c(c2.a - 3, c2.b - 3, null);
        ps.hacking.zxing.a.b.c c7 = new ps.hacking.zxing.a.b.c(3 + c3.a, c3.b - 3, null);
        ps.hacking.zxing.a.b.c c8 = new ps.hacking.zxing.a.b.c(3 + c4.a, 3 + c4.b, null);
        for (int j = a(c8, c5); j == 0 || a(c5, c6) != j || a(c6, c7) != j || a(c7, c8) != j;)
        {
            return false;
        }

        return true;
    }

    private ps.hacking.zxing.a.b.c[] a(ps.hacking.zxing.a.b.c c1)
    {
        boolean flag = true;
        e = 1;
        ps.hacking.zxing.a.b.c c2 = c1;
        ps.hacking.zxing.a.b.c c3 = c1;
        ps.hacking.zxing.a.b.c c4 = c1;
label0:
        do
        {
            ps.hacking.zxing.a.b.c c5;
            ps.hacking.zxing.a.b.c c6;
            ps.hacking.zxing.a.b.c c7;
            ps.hacking.zxing.a.b.c c8;
label1:
            {
                if (e < 9)
                {
                    c5 = a(c4, flag, 1, -1);
                    c6 = a(c3, flag, 1, 1);
                    c7 = a(c2, flag, -1, 1);
                    c8 = a(c1, flag, -1, -1);
                    if (e <= 2)
                    {
                        break label1;
                    }
                    float f2 = (b(c8, c5) * (float)e) / (b(c1, c4) * (float)(2 + e));
                    if ((double)f2 >= 0.75D && (double)f2 <= 1.25D && a(c5, c6, c7, c8))
                    {
                        break label1;
                    }
                }
                if (e != 5 && e != 7)
                {
                    throw ps.hacking.zxing.i.a();
                }
                break label0;
            }
            if (!flag)
            {
                flag = true;
            } else
            {
                flag = false;
            }
            e = 1 + e;
            c1 = c8;
            c2 = c7;
            c3 = c6;
            c4 = c5;
        } while (true);
        boolean flag1;
        float f1;
        int j;
        int k;
        int l;
        int i1;
        int j1;
        int k1;
        int l1;
        int i2;
        int j2;
        int k2;
        int l2;
        int i3;
        if (e == 5)
        {
            flag1 = true;
        } else
        {
            flag1 = false;
        }
        b = flag1;
        f1 = 1.5F / (float)(-3 + 2 * e);
        j = c4.a - c2.a;
        k = c4.b - c2.b;
        l = ps.hacking.zxing.b.a.a.a((float)c2.a - f1 * (float)j);
        i1 = ps.hacking.zxing.b.a.a.a((float)c2.b - f1 * (float)k);
        j1 = ps.hacking.zxing.b.a.a.a((float)c4.a + f1 * (float)j);
        k1 = ps.hacking.zxing.b.a.a.a((float)c4.b + f1 * (float)k);
        l1 = c3.a - c1.a;
        i2 = c3.b - c1.b;
        j2 = ps.hacking.zxing.b.a.a.a((float)c1.a - f1 * (float)l1);
        k2 = ps.hacking.zxing.b.a.a.a((float)c1.b - f1 * (float)i2);
        l2 = ps.hacking.zxing.b.a.a.a((float)c3.a + f1 * (float)l1);
        i3 = ps.hacking.zxing.b.a.a.a((float)c3.b + f1 * (float)i2);
        if (!a(j1, k1) || !a(l2, i3) || !a(l, i1) || !a(j2, k2))
        {
            throw ps.hacking.zxing.i.a();
        } else
        {
            return (new ps.hacking.zxing.a.b.c[] {
                new ps.hacking.zxing.a.b.c(j1, k1, null), new ps.hacking.zxing.a.b.c(l2, i3, null), new ps.hacking.zxing.a.b.c(l, i1, null), new ps.hacking.zxing.a.b.c(j2, k2, null)
            });
        }
    }

    private boolean[] a(ps.hacking.zxing.a.b.c c1, ps.hacking.zxing.a.b.c c2, int j)
    {
        boolean aflag[] = new boolean[j];
        float f1 = b(c1, c2);
        float f2 = f1 / (float)(j - 1);
        float f3 = (f2 * (float)(c2.a - c1.a)) / f1;
        float f4 = (f2 * (float)(c2.b - c1.b)) / f1;
        float f5 = c1.a;
        float f6 = c1.b;
        for (int k = 0; k < j; k++)
        {
            aflag[k] = a.a(ps.hacking.zxing.b.a.a.a(f5), ps.hacking.zxing.b.a.a.a(f6));
            f5 += f3;
            f6 += f4;
        }

        return aflag;
    }

    private static float b(ps.hacking.zxing.a.b.c c1, ps.hacking.zxing.a.b.c c2)
    {
        return ps.hacking.zxing.b.a.a.a(c1.a, c1.b, c2.a, c2.b);
    }

    private ps.hacking.zxing.a.b.c b()
    {
        o o1;
        o o2;
        o o3;
        o o4;
        int i1;
        int j1;
        o o5;
        o o6;
        o o7;
        o o8;
        try
        {
            o ao1[] = (new ps.hacking.zxing.b.a.b(a)).a();
            o1 = ao1[0];
            o2 = ao1[1];
            o3 = ao1[2];
            o4 = ao1[3];
        }
        catch (ps.hacking.zxing.i j)
        {
            int k = a.d() / 2;
            int l = a.e() / 2;
            o1 = a(new ps.hacking.zxing.a.b.c(k + 7, l - 7, null), false, 1, -1).a();
            o2 = a(new ps.hacking.zxing.a.b.c(k + 7, l + 7, null), false, 1, 1).a();
            o3 = a(new ps.hacking.zxing.a.b.c(k - 7, l + 7, null), false, -1, 1).a();
            o4 = a(new ps.hacking.zxing.a.b.c(k - 7, l - 7, null), false, -1, -1).a();
        }
        i1 = ps.hacking.zxing.b.a.a.a((o1.a() + o4.a() + o2.a() + o3.a()) / 4F);
        j1 = ps.hacking.zxing.b.a.a.a((o1.b() + o4.b() + o2.b() + o3.b()) / 4F);
        try
        {
            o ao[] = (new ps.hacking.zxing.b.a.b(a, 15, i1, j1)).a();
            o5 = ao[0];
            o6 = ao[1];
            o7 = ao[2];
            o8 = ao[3];
        }
        catch (ps.hacking.zxing.i k1)
        {
            o5 = a(new ps.hacking.zxing.a.b.c(i1 + 7, j1 - 7, null), false, 1, -1).a();
            o6 = a(new ps.hacking.zxing.a.b.c(i1 + 7, j1 + 7, null), false, 1, 1).a();
            o7 = a(new ps.hacking.zxing.a.b.c(i1 - 7, j1 + 7, null), false, -1, 1).a();
            o8 = a(new ps.hacking.zxing.a.b.c(i1 - 7, j1 - 7, null), false, -1, -1).a();
        }
        return new ps.hacking.zxing.a.b.c(ps.hacking.zxing.b.a.a.a((o5.a() + o8.a() + o6.a() + o7.a()) / 4F), ps.hacking.zxing.b.a.a.a((o5.b() + o8.b() + o6.b() + o7.b()) / 4F), null);
    }

    private o[] b(ps.hacking.zxing.a.b.c ac[])
    {
        byte byte0 = -1;
        int j = 2 * c;
        int k;
        float f1;
        int l;
        int i1;
        int j1;
        int k1;
        int l1;
        int i2;
        int j2;
        int k2;
        int l2;
        int i3;
        int j3;
        int k3;
        int l3;
        int i4;
        int j4;
        int k4;
        int l4;
        int i5;
        int j5;
        if (c > 4)
        {
            k = 1;
        } else
        {
            k = 0;
        }
        f1 = (float)(k + j + (-4 + c) / 8) / (2.0F * (float)e);
        l = ac[0].a - ac[2].a;
        if (l > 0)
        {
            i1 = 1;
        } else
        {
            i1 = byte0;
        }
        j1 = l + i1;
        k1 = ac[0].b - ac[2].b;
        if (k1 > 0)
        {
            l1 = 1;
        } else
        {
            l1 = byte0;
        }
        i2 = l1 + k1;
        j2 = ps.hacking.zxing.b.a.a.a((float)ac[2].a - f1 * (float)j1);
        k2 = ps.hacking.zxing.b.a.a.a((float)ac[2].b - f1 * (float)i2);
        l2 = ps.hacking.zxing.b.a.a.a((float)ac[0].a + f1 * (float)j1);
        i3 = ps.hacking.zxing.b.a.a.a((float)ac[0].b + f1 * (float)i2);
        j3 = ac[1].a - ac[3].a;
        if (j3 > 0)
        {
            k3 = 1;
        } else
        {
            k3 = byte0;
        }
        l3 = k3 + j3;
        i4 = ac[1].b - ac[3].b;
        if (i4 > 0)
        {
            byte0 = 1;
        }
        j4 = byte0 + i4;
        k4 = ps.hacking.zxing.b.a.a.a((float)ac[3].a - f1 * (float)l3);
        l4 = ps.hacking.zxing.b.a.a.a((float)ac[3].b - f1 * (float)j4);
        i5 = ps.hacking.zxing.b.a.a.a((float)ac[1].a + f1 * (float)l3);
        j5 = ps.hacking.zxing.b.a.a.a((float)ac[1].b + f1 * (float)j4);
        if (!a(l2, i3) || !a(i5, j5) || !a(j2, k2) || !a(k4, l4))
        {
            throw ps.hacking.zxing.i.a();
        } else
        {
            o ao[] = new o[4];
            ao[0] = new o(l2, i3);
            ao[1] = new o(i5, j5);
            ao[2] = new o(j2, k2);
            ao[3] = new o(k4, l4);
            return ao;
        }
    }

    public ps.hacking.zxing.a.a a()
    {
        ps.hacking.zxing.a.b.c ac[] = a(b());
        a(ac);
        o ao[] = b(ac);
        return new ps.hacking.zxing.a.a(a(a, ao[f % 4], ao[(3 + f) % 4], ao[(2 + f) % 4], ao[(1 + f) % 4]), ao, b, d, c);
    }
}
