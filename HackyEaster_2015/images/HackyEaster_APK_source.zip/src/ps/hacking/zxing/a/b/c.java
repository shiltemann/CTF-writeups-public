// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.a.b;

import ps.hacking.zxing.o;

// Referenced classes of package ps.hacking.zxing.a.b:
//            b

final class c
{

    public final int a;
    public final int b;

    private c(int i, int j)
    {
        a = i;
        b = j;
    }

    c(int i, int j, b b1)
    {
        this(i, j);
    }

    public o a()
    {
        return new o(a, b);
    }
}
