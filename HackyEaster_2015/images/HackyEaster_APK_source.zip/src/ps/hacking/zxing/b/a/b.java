// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.b.a;

import ps.hacking.zxing.i;
import ps.hacking.zxing.o;

// Referenced classes of package ps.hacking.zxing.b.a:
//            a

public final class b
{

    private final ps.hacking.zxing.b.b a;
    private final int b;
    private final int c;
    private final int d;
    private final int e;
    private final int f;
    private final int g;

    public b(ps.hacking.zxing.b.b b1)
    {
        a = b1;
        b = b1.e();
        c = b1.d();
        d = -30 + c >> 1;
        e = 30 + c >> 1;
        g = -30 + b >> 1;
        f = 30 + b >> 1;
        if (g < 0 || d < 0 || f >= b || e >= c)
        {
            throw i.a();
        } else
        {
            return;
        }
    }

    public b(ps.hacking.zxing.b.b b1, int j, int k, int l)
    {
        a = b1;
        b = b1.e();
        c = b1.d();
        int i1 = j >> 1;
        d = k - i1;
        e = k + i1;
        g = l - i1;
        f = i1 + l;
        if (g < 0 || d < 0 || f >= b || e >= c)
        {
            throw i.a();
        } else
        {
            return;
        }
    }

    private o a(float f1, float f2, float f3, float f4)
    {
        int j = ps.hacking.zxing.b.a.a.a(ps.hacking.zxing.b.a.a.a(f1, f2, f3, f4));
        float f5 = (f3 - f1) / (float)j;
        float f6 = (f4 - f2) / (float)j;
        for (int k = 0; k < j; k++)
        {
            int l = ps.hacking.zxing.b.a.a.a(f1 + f5 * (float)k);
            int i1 = ps.hacking.zxing.b.a.a.a(f2 + f6 * (float)k);
            if (a.a(l, i1))
            {
                return new o(l, i1);
            }
        }

        return null;
    }

    private boolean a(int j, int k, int l, boolean flag)
    {
        if (!flag) goto _L2; else goto _L1
_L1:
        for (; j <= k; j++)
        {
            if (a.a(j, l))
            {
                return true;
            }
        }

          goto _L3
_L4:
        j++;
_L2:
        if (j > k)
        {
            break; /* Loop/switch isn't completed */
        }
        if (a.a(l, j))
        {
            return true;
        }
        if (true) goto _L4; else goto _L3
_L3:
        return false;
    }

    private o[] a(o o1, o o2, o o3, o o4)
    {
        float f1 = o1.a();
        float f2 = o1.b();
        float f3 = o2.a();
        float f4 = o2.b();
        float f5 = o3.a();
        float f6 = o3.b();
        float f7 = o4.a();
        float f8 = o4.b();
        if (f1 < (float)(c / 2))
        {
            o ao1[] = new o[4];
            ao1[0] = new o(f7 - 1.0F, f8 + 1.0F);
            ao1[1] = new o(f3 + 1.0F, f4 + 1.0F);
            ao1[2] = new o(f5 - 1.0F, f6 - 1.0F);
            ao1[3] = new o(f1 + 1.0F, f2 - 1.0F);
            return ao1;
        } else
        {
            o ao[] = new o[4];
            ao[0] = new o(f7 + 1.0F, f8 + 1.0F);
            ao[1] = new o(f3 + 1.0F, f4 - 1.0F);
            ao[2] = new o(f5 - 1.0F, f6 + 1.0F);
            ao[3] = new o(f1 - 1.0F, f2 - 1.0F);
            return ao;
        }
    }

    public o[] a()
    {
        boolean flag;
        int j;
        int k;
        int l;
        int i1;
        boolean flag1;
        int j1;
        flag = true;
        j = d;
        k = e;
        l = g;
        i1 = f;
        flag1 = false;
        j1 = ((flag) ? 1 : 0);
_L1:
        int k1;
        int l1;
        int i2;
        int j2;
        int k2;
        int l2;
        int i3;
        o o1;
        o o2;
        if (j1 == 0)
        {
            break MISSING_BLOCK_LABEL_605;
        }
        int l3 = ((flag) ? 1 : 0);
        int i4 = 0;
        do
        {
            if (l3 == 0 || k >= c)
            {
                break;
            }
            l3 = a(l, i1, k, false);
            if (l3 != 0)
            {
                k++;
                i4 = ((flag) ? 1 : 0);
            }
        } while (true);
        if (k >= c)
        {
            k2 = ((flag) ? 1 : 0);
            k1 = k;
            l1 = i1;
            i2 = j;
            j2 = l;
        } else
        {
            int j4 = ((flag) ? 1 : 0);
            do
            {
                if (j4 == 0 || i1 >= b)
                {
                    break;
                }
                j4 = a(j, k, i1, flag);
                if (j4 != 0)
                {
                    i1++;
                    i4 = ((flag) ? 1 : 0);
                }
            } while (true);
            if (i1 >= b)
            {
                k2 = ((flag) ? 1 : 0);
                k1 = k;
                l1 = i1;
                i2 = j;
                j2 = l;
            } else
            {
                boolean flag2 = flag;
                do
                {
                    if (!flag2 || j < 0)
                    {
                        break;
                    }
                    flag2 = a(l, i1, j, false);
                    if (flag2)
                    {
                        j--;
                        i4 = ((flag) ? 1 : 0);
                    }
                } while (true);
                if (j < 0)
                {
                    k2 = ((flag) ? 1 : 0);
                    k1 = k;
                    l1 = i1;
                    i2 = j;
                    j2 = l;
                } else
                {
label0:
                    {
                        j1 = i4;
                        boolean flag3 = flag;
                        do
                        {
                            if (!flag3 || l < 0)
                            {
                                break;
                            }
                            flag3 = a(j, k, l, flag);
                            if (flag3)
                            {
                                l--;
                                j1 = ((flag) ? 1 : 0);
                            }
                        } while (true);
                        if (l >= 0)
                        {
                            break label0;
                        }
                        k2 = ((flag) ? 1 : 0);
                        k1 = k;
                        l1 = i1;
                        i2 = j;
                        j2 = l;
                    }
                }
            }
        }
_L5:
        if (k2 == 0 && flag1)
        {
            l2 = k1 - i2;
            i3 = ((flag) ? 1 : 0);
            o1 = null;
            break MISSING_BLOCK_LABEL_128;
        } else
        {
            throw i.a();
        }
        if (j1 != 0)
        {
            flag1 = flag;
        }
          goto _L1
        do
        {
            {
                if (i3 >= l2)
                {
                    break MISSING_BLOCK_LABEL_598;
                }
                o1 = a(i2, l1 - i3, i2 + i3, l1);
                if (o1 != null)
                {
                    o2 = o1;
                    break MISSING_BLOCK_LABEL_168;
                }
                i3++;
            }
        } while (true);
_L2:
        if (o6 == null)
        {
            throw i.a();
        }
        o o7 = null;
        do
        {
label1:
            {
                if (flag < l2)
                {
                    o7 = a(k1, l1 - flag, k1 - flag, l1);
                    if (o7 == null)
                    {
                        break label1;
                    }
                }
                if (o7 == null)
                {
                    throw i.a();
                } else
                {
                    return a(o7, o2, o6, o4);
                }
            }
            flag++;
        } while (true);
_L4:
        if (o2 == null)
        {
            throw i.a();
        }
        int j3 = ((flag) ? 1 : 0);
        o o3 = null;
        o o4;
        int k3;
        o o5;
        o o6;
        for (; j3 < l2; j3++)
        {
            o3 = a(i2, j2 + j3, i2 + j3, j2);
            if (o3 != null)
            {
                o4 = o3;
                break MISSING_BLOCK_LABEL_440;
            }
        }

        o4 = o3;
        if (o4 == null)
        {
            throw i.a();
        }
        k3 = ((flag) ? 1 : 0);
        o5 = null;
        for (; k3 < l2; k3++)
        {
            o5 = a(k1, j2 + k3, k1 - k3, j2);
            if (o5 != null)
            {
                o6 = o5;
                break MISSING_BLOCK_LABEL_501;
            }
        }

        o6 = o5;
          goto _L2
        o2 = o1;
        if (true) goto _L4; else goto _L3
_L3:
        k1 = k;
        l1 = i1;
        i2 = j;
        j2 = l;
        k2 = 0;
          goto _L5
    }
}
