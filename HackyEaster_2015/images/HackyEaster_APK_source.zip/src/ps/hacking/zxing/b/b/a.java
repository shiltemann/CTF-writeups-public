// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.b.b;


// Referenced classes of package ps.hacking.zxing.b.b:
//            b

public final class a
{

    public static final a a = new a(4201, 4096);
    public static final a b = new a(1033, 1024);
    public static final a c;
    public static final a d = new a(19, 16);
    public static final a e = new a(285, 256);
    public static final a f;
    public static final a g;
    public static final a h;
    private int i[];
    private int j[];
    private b k;
    private b l;
    private final int m;
    private final int n;
    private boolean o;

    public a(int i1, int j1)
    {
        o = false;
        n = i1;
        m = j1;
        if (j1 <= 0)
        {
            d();
        }
    }

    static int b(int i1, int j1)
    {
        return i1 ^ j1;
    }

    private void d()
    {
        i = new int[m];
        j = new int[m];
        int i1 = 0;
        int j1 = 1;
        for (; i1 < m; i1++)
        {
            i[i1] = j1;
            j1 <<= 1;
            if (j1 >= m)
            {
                j1 = (j1 ^ n) & -1 + m;
            }
        }

        for (int k1 = 0; k1 < -1 + m; k1++)
        {
            j[i[k1]] = k1;
        }

        k = new b(this, new int[] {
            0
        });
        l = new b(this, new int[] {
            1
        });
        o = true;
    }

    private void e()
    {
        if (!o)
        {
            d();
        }
    }

    int a(int i1)
    {
        e();
        return i[i1];
    }

    b a()
    {
        e();
        return k;
    }

    b a(int i1, int j1)
    {
        e();
        if (i1 < 0)
        {
            throw new IllegalArgumentException();
        }
        if (j1 == 0)
        {
            return k;
        } else
        {
            int ai[] = new int[i1 + 1];
            ai[0] = j1;
            return new b(this, ai);
        }
    }

    int b(int i1)
    {
        e();
        if (i1 == 0)
        {
            throw new IllegalArgumentException();
        } else
        {
            return j[i1];
        }
    }

    b b()
    {
        e();
        return l;
    }

    public int c()
    {
        return m;
    }

    int c(int i1)
    {
        e();
        if (i1 == 0)
        {
            throw new ArithmeticException();
        } else
        {
            return i[-1 + (m - j[i1])];
        }
    }

    int c(int i1, int j1)
    {
        e();
        if (i1 == 0 || j1 == 0)
        {
            return 0;
        } else
        {
            return i[(j[i1] + j[j1]) % (-1 + m)];
        }
    }

    static 
    {
        c = new a(67, 64);
        f = new a(301, 256);
        g = f;
        h = c;
    }
}
