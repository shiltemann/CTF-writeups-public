// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.b.b;


// Referenced classes of package ps.hacking.zxing.b.b:
//            b, a, d

public final class c
{

    private final a a;

    public c(a a1)
    {
        a = a1;
    }

    private int[] a(b b1)
    {
        int i = 0;
        int j = 1;
        int k = b1.a();
        if (k == j)
        {
            int ai1[] = new int[j];
            ai1[0] = b1.a(j);
            return ai1;
        }
        int ai[] = new int[k];
        for (; j < a.c() && i < k; j++)
        {
            if (b1.b(j) == 0)
            {
                ai[i] = a.c(j);
                i++;
            }
        }

        if (i != k)
        {
            throw new d("Error locator degree does not match number of roots");
        } else
        {
            return ai;
        }
    }

    private int[] a(b b1, int ai[], boolean flag)
    {
        int i = ai.length;
        int ai1[] = new int[i];
        int j = 0;
        while (j < i) 
        {
            int k = a.c(ai[j]);
            int l = 1;
            int i1 = 0;
            while (i1 < i) 
            {
                int j1;
                if (j != i1)
                {
                    int k1 = a.c(ai[i1], k);
                    int l1;
                    if ((k1 & 1) == 0)
                    {
                        l1 = k1 | 1;
                    } else
                    {
                        l1 = k1 & -2;
                    }
                    j1 = a.c(l, l1);
                } else
                {
                    j1 = l;
                }
                i1++;
                l = j1;
            }
            ai1[j] = a.c(b1.b(k), a.c(l));
            if (flag)
            {
                ai1[j] = a.c(ai1[j], k);
            }
            j++;
        }
        return ai1;
    }

    private b[] a(b b1, b b2, int i)
    {
        b b4;
        b b5;
        int j;
        if (b1.a() >= b2.a())
        {
            b b3 = b2;
            b2 = b1;
            b1 = b3;
        }
        b4 = a.a();
        b5 = a.b();
        while (b1.a() >= i / 2) 
        {
            if (b1.b())
            {
                throw new d("r_{i-1} was zero");
            }
            b b6 = a.a();
            int l = b1.a(b1.a());
            int i1 = a.c(l);
            b b7 = b6;
            b b8;
            int j1;
            int k1;
            for (b8 = b2; b8.a() >= b1.a() && !b8.b(); b8 = b8.a(b1.a(j1, k1)))
            {
                j1 = b8.a() - b1.a();
                k1 = a.c(b8.a(b8.a()), i1);
                b7 = b7.a(a.a(j1, k1));
            }

            b b9 = b7.b(b5).a(b4);
            b2 = b1;
            b1 = b8;
            b b10 = b5;
            b5 = b9;
            b4 = b10;
        }
        j = b5.a(0);
        if (j == 0)
        {
            throw new d("sigmaTilde(0) was zero");
        } else
        {
            int k = a.c(j);
            return (new b[] {
                b5.c(k), b1.c(k)
            });
        }
    }

    public void a(int ai[], int i)
    {
        int j = 0;
        b b1 = new b(a, ai);
        int ai1[] = new int[i];
        boolean flag = a.equals(a.f);
        int k = 0;
        boolean flag1 = true;
        while (k < i) 
        {
            a a1 = a;
            int i1;
            int j1;
            boolean flag2;
            if (flag)
            {
                i1 = k + 1;
            } else
            {
                i1 = k;
            }
            j1 = b1.b(a1.a(i1));
            ai1[(-1 + ai1.length) - k] = j1;
            b b2;
            b ab[];
            b b3;
            b b4;
            int ai2[];
            int ai3[];
            int l;
            if (j1 != 0)
            {
                flag2 = false;
            } else
            {
                flag2 = flag1;
            }
            k++;
            flag1 = flag2;
        }
        if (!flag1)
        {
            b2 = new b(a, ai1);
            ab = a(a.a(i, 1), b2, i);
            b3 = ab[0];
            b4 = ab[1];
            ai2 = a(b3);
            ai3 = a(b4, ai2, flag);
            while (j < ai2.length) 
            {
                l = (-1 + ai.length) - a.b(ai2[j]);
                if (l < 0)
                {
                    throw new d("Bad error location");
                }
                ai[l] = ps.hacking.zxing.b.b.a.b(ai[l], ai3[j]);
                j++;
            }
        }
    }
}
