// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.b;

import java.util.List;

public final class e
{

    private final byte a[];
    private final String b;
    private final List c;
    private final String d;

    public e(byte abyte0[], String s, List list, String s1)
    {
        a = abyte0;
        b = s;
        c = list;
        d = s1;
    }

    public byte[] a()
    {
        return a;
    }

    public String b()
    {
        return b;
    }

    public List c()
    {
        return c;
    }

    public String d()
    {
        return d;
    }
}
