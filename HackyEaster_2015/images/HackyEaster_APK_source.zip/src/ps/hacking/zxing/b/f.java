// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.b;

import ps.hacking.zxing.i;

// Referenced classes of package ps.hacking.zxing.b:
//            i, k, b

public final class f extends ps.hacking.zxing.b.i
{

    public f()
    {
    }

    public b a(b b1, int j, int l, float f1, float f2, float f3, float f4, 
            float f5, float f6, float f7, float f8, float f9, float f10, float f11, 
            float f12, float f13, float f14, float f15, float f16)
    {
        return a(b1, j, l, k.a(f1, f2, f3, f4, f5, f6, f7, f8, f9, f10, f11, f12, f13, f14, f15, f16));
    }

    public b a(b b1, int j, int l, k k1)
    {
        if (j <= 0 || l <= 0)
        {
            throw i.a();
        }
        b b2 = new b(j, l);
        float af[] = new float[j << 1];
        for (int i1 = 0; i1 < l; i1++)
        {
            int j1 = af.length;
            float f1 = 0.5F + (float)i1;
            for (int l1 = 0; l1 < j1; l1 += 2)
            {
                af[l1] = 0.5F + (float)(l1 >> 1);
                af[l1 + 1] = f1;
            }

            k1.a(af);
            a(b1, af);
            int i2 = 0;
            while (i2 < j1) 
            {
                try
                {
                    if (b1.a((int)af[i2], (int)af[i2 + 1]))
                    {
                        b2.b(i2 >> 1, i1);
                    }
                }
                catch (ArrayIndexOutOfBoundsException arrayindexoutofboundsexception)
                {
                    throw i.a();
                }
                i2 += 2;
            }
        }

        return b2;
    }
}
