// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.b;

import ps.hacking.zxing.o;

// Referenced classes of package ps.hacking.zxing.b:
//            b

public class g
{

    private final b a;
    private final o b[];

    public g(b b1, o ao[])
    {
        a = b1;
        b = ao;
    }

    public final b d()
    {
        return a;
    }

    public final o[] e()
    {
        return b;
    }
}
