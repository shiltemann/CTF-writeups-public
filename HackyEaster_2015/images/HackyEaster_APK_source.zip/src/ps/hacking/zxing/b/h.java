// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.b;

import ps.hacking.zxing.b;
import ps.hacking.zxing.g;
import ps.hacking.zxing.i;

// Referenced classes of package ps.hacking.zxing.b:
//            a, b

public class h extends b
{

    private static final byte a[] = new byte[0];
    private byte b[];
    private final int c[] = new int[32];

    public h(g g1)
    {
        super(g1);
        b = a;
    }

    private static int a(int ai[])
    {
        int j = 0;
        int k = ai.length;
        int l = 0;
        int i1 = 0;
        int j1 = 0;
        int k1 = 0;
        for (; l < k; l++)
        {
            if (ai[l] > i1)
            {
                i1 = ai[l];
                j1 = l;
            }
            if (ai[l] > k1)
            {
                k1 = ai[l];
            }
        }

        int l1 = 0;
        int i2 = 0;
        while (j < k) 
        {
            int i4 = j - j1;
            int j4 = i4 * (i4 * ai[j]);
            int j2;
            int k2;
            int l2;
            int i3;
            int j3;
            int k3;
            int l3;
            int k4;
            if (j4 > l1)
            {
                k4 = j;
            } else
            {
                j4 = l1;
                k4 = i2;
            }
            j++;
            i2 = k4;
            l1 = j4;
        }
        if (j1 > i2)
        {
            j2 = i2;
            i2 = j1;
        } else
        {
            j2 = j1;
        }
        if (i2 - j2 <= k >> 4)
        {
            throw i.a();
        }
        k2 = i2 - 1;
        l2 = -1;
        i3 = i2 - 1;
        while (i3 > j2) 
        {
            j3 = i3 - j2;
            k3 = j3 * j3 * (i2 - i3) * (k1 - ai[i3]);
            if (k3 > l2)
            {
                l3 = i3;
            } else
            {
                k3 = l2;
                l3 = k2;
            }
            i3--;
            k2 = l3;
            l2 = k3;
        }
        return k2 << 3;
    }

    private void a(int j)
    {
        if (b.length < j)
        {
            b = new byte[j];
        }
        for (int k = 0; k < 32; k++)
        {
            c[k] = 0;
        }

    }

    public a a(int j, a a1)
    {
        int k = 1;
        g g1 = a();
        int l = g1.b();
        byte abyte0[];
        int ai[];
        if (a1 == null || a1.a() < l)
        {
            a1 = new a(l);
        } else
        {
            a1.b();
        }
        a(l);
        abyte0 = g1.a(j, b);
        ai = c;
        for (int i1 = 0; i1 < l; i1++)
        {
            int k2 = (0xff & abyte0[i1]) >> 3;
            ai[k2] = 1 + ai[k2];
        }

        int j1 = a(ai);
        int k1 = 0xff & abyte0[0];
        int l1 = 0xff & abyte0[k];
        int i2 = k1;
        while (k < l - 1) 
        {
            int j2 = 0xff & abyte0[k + 1];
            if ((l1 << 2) - i2 - j2 >> 1 < j1)
            {
                a1.b(k);
            }
            k++;
            i2 = l1;
            l1 = j2;
        }
        return a1;
    }

    public b a(g g1)
    {
        return new h(g1);
    }

    public ps.hacking.zxing.b.b b()
    {
        g g1 = a();
        int j = g1.b();
        int k = g1.c();
        ps.hacking.zxing.b.b b1 = new ps.hacking.zxing.b.b(j, k);
        a(j);
        int ai[] = c;
        for (int l = 1; l < 5; l++)
        {
            byte abyte1[] = g1.a((k * l) / 5, b);
            int i2 = (j << 2) / 5;
            for (int j2 = j / 5; j2 < i2; j2++)
            {
                int k2 = (0xff & abyte1[j2]) >> 3;
                ai[k2] = 1 + ai[k2];
            }

        }

        int i1 = a(ai);
        byte abyte0[] = g1.a();
        for (int j1 = 0; j1 < k; j1++)
        {
            int k1 = j1 * j;
            for (int l1 = 0; l1 < j; l1++)
            {
                if ((0xff & abyte0[k1 + l1]) < i1)
                {
                    b1.b(l1, j1);
                }
            }

        }

        return b1;
    }

}
