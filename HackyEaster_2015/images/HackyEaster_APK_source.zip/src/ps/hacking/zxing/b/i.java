// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.b;


// Referenced classes of package ps.hacking.zxing.b:
//            f, b, k

public abstract class i
{

    private static i a = new f();

    public i()
    {
    }

    public static i a()
    {
        return a;
    }

    protected static void a(b b1, float af[])
    {
        int j = b1.d();
        int k = b1.e();
        int l = 0;
        boolean flag = true;
        while (l < af.length && flag) 
        {
            int l1 = (int)af[l];
            int i2 = (int)af[l + 1];
            if (l1 < -1 || l1 > j || i2 < -1 || i2 > k)
            {
                throw ps.hacking.zxing.i.a();
            }
            int i1;
            boolean flag1;
            int j1;
            int k1;
            if (l1 == -1)
            {
                af[l] = 0.0F;
                flag = true;
            } else
            if (l1 == j)
            {
                af[l] = j - 1;
                flag = true;
            } else
            {
                flag = false;
            }
            if (i2 == -1)
            {
                af[l + 1] = 0.0F;
                flag = true;
            } else
            if (i2 == k)
            {
                af[l + 1] = k - 1;
                flag = true;
            }
            l += 2;
        }
        i1 = -2 + af.length;
        flag1 = true;
        while (i1 >= 0 && flag1) 
        {
            j1 = (int)af[i1];
            k1 = (int)af[i1 + 1];
            if (j1 < -1 || j1 > j || k1 < -1 || k1 > k)
            {
                throw ps.hacking.zxing.i.a();
            }
            if (j1 == -1)
            {
                af[i1] = 0.0F;
                flag1 = true;
            } else
            if (j1 == j)
            {
                af[i1] = j - 1;
                flag1 = true;
            } else
            {
                flag1 = false;
            }
            if (k1 == -1)
            {
                af[i1 + 1] = 0.0F;
                flag1 = true;
            } else
            if (k1 == k)
            {
                af[i1 + 1] = k - 1;
                flag1 = true;
            }
            i1 -= 2;
        }
    }

    public abstract b a(b b1, int j, int k, float f1, float f2, float f3, float f4, 
            float f5, float f6, float f7, float f8, float f9, float f10, float f11, 
            float f12, float f13, float f14, float f15, float f16);

    public abstract b a(b b1, int j, int k, k k1);

}
