// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.b;

import java.lang.reflect.Array;
import ps.hacking.zxing.b;
import ps.hacking.zxing.g;

// Referenced classes of package ps.hacking.zxing.b:
//            h, b

public final class j extends h
{

    private ps.hacking.zxing.b.b a;

    public j(g g1)
    {
        super(g1);
    }

    private static int a(int i, int k, int l)
    {
        if (i < k)
        {
            return k;
        }
        if (i > l)
        {
            return l;
        } else
        {
            return i;
        }
    }

    private static void a(byte abyte0[], int i, int k, int l, int i1, ps.hacking.zxing.b.b b1)
    {
        int j1 = i + k * i1;
        for (int k1 = 0; k1 < 8;)
        {
            for (int l1 = 0; l1 < 8; l1++)
            {
                if ((0xff & abyte0[j1 + l1]) <= l)
                {
                    b1.b(i + l1, k + k1);
                }
            }

            k1++;
            j1 += i1;
        }

    }

    private static void a(byte abyte0[], int i, int k, int l, int i1, int ai[][], ps.hacking.zxing.b.b b1)
    {
        int j1 = 0;
        while (j1 < k) 
        {
            int k1 = j1 << 3;
            int l1 = i1 - 8;
            int i2;
            if (k1 <= l1)
            {
                l1 = k1;
            }
            i2 = 0;
            while (i2 < i) 
            {
                int j2 = i2 << 3;
                int k2 = l - 8;
                int l2;
                int i3;
                int j3;
                if (j2 <= k2)
                {
                    k2 = j2;
                }
                l2 = a(i2, 2, i - 3);
                i3 = a(j1, 2, k - 3);
                j3 = 0;
                for (int k3 = -2; k3 <= 2; k3++)
                {
                    int ai1[] = ai[i3 + k3];
                    j3 += ai1[l2 - 2] + ai1[l2 - 1] + ai1[l2] + ai1[l2 + 1] + ai1[l2 + 2];
                }

                a(abyte0, k2, l1, j3 / 25, l, b1);
                i2++;
            }
            j1++;
        }
    }

    private static int[][] a(byte abyte0[], int i, int k, int l, int i1)
    {
        int ai1[][];
        int j1;
        int ai[] = {
            k, i
        };
        ai1 = (int[][])Array.newInstance(Integer.TYPE, ai);
        j1 = 0;
_L3:
        if (j1 >= k) goto _L2; else goto _L1
_L1:
        int k1 = j1 << 3;
        int l1 = i1 - 8;
        int i2;
        int j2;
        int k2;
        int l2;
        int i3;
        int j3;
        int k3;
        int l3;
        int i4;
        int j4;
        int k4;
        int l4;
        int i5;
        int j5;
        int k5;
        int l5;
        int i6;
        int j6;
        int k6;
        int l6;
        int i7;
        if (k1 <= l1)
        {
            l1 = k1;
        }
        i2 = 0;
        if (i2 >= i)
        {
            continue; /* Loop/switch isn't completed */
        }
        j2 = i2 << 3;
        k2 = l - 8;
        if (j2 <= k2)
        {
            k2 = j2;
        }
        l2 = 0;
        i3 = 255;
        j3 = 0;
        k3 = 0;
        l3 = k2 + l1 * l;
        while (k3 < 8) 
        {
            k4 = 0;
            while (k4 < 8) 
            {
                k6 = 0xff & abyte0[l3 + k4];
                l6 = l2 + k6;
                if (k6 < i3)
                {
                    i7 = k6;
                } else
                {
                    i7 = i3;
                }
                if (k6 <= j3)
                {
                    k6 = j3;
                }
                k4++;
                i3 = i7;
                j3 = k6;
                l2 = l6;
            }
            if (j3 - i3 > 24)
            {
                l5 = k3 + 1;
                l4 = l3 + l;
                i5 = l5;
                for (j5 = l2; i5 < 8; j5 = i6)
                {
                    i6 = j5;
                    for (j6 = 0; j6 < 8; j6++)
                    {
                        i6 += 0xff & abyte0[l4 + j6];
                    }

                    i5++;
                    l4 += l;
                }

            } else
            {
                l4 = l3;
                i5 = k3;
                j5 = l2;
            }
            k5 = i5 + 1;
            l3 = l4 + l;
            l2 = j5;
            k3 = k5;
        }
        i4 = l2 >> 6;
        if (j3 - i3 <= 24)
        {
            j4 = i3 >> 1;
            if (j1 <= 0 || i2 <= 0)
            {
                break MISSING_BLOCK_LABEL_408;
            }
            i4 = ai1[j1 - 1][i2] + 2 * ai1[j1][i2 - 1] + ai1[j1 - 1][i2 - 1] >> 2;
            if (i3 >= i4)
            {
                break MISSING_BLOCK_LABEL_408;
            }
        }
        ai1[j1][i2] = i4;
        i2++;
        if (true)
        {
            break MISSING_BLOCK_LABEL_58;
        }
        j1++;
          goto _L3
_L2:
        return ai1;
        i4 = j4;
        break MISSING_BLOCK_LABEL_383;
    }

    public b a(g g1)
    {
        return new j(g1);
    }

    public ps.hacking.zxing.b.b b()
    {
        if (a != null)
        {
            return a;
        }
        g g1 = a();
        int i = g1.b();
        int k = g1.c();
        if (i >= 40 && k >= 40)
        {
            byte abyte0[] = g1.a();
            int l = i >> 3;
            if ((i & 7) != 0)
            {
                l++;
            }
            int i1 = k >> 3;
            if ((k & 7) != 0)
            {
                i1++;
            }
            int ai[][] = a(abyte0, l, i1, i, k);
            ps.hacking.zxing.b.b b1 = new ps.hacking.zxing.b.b(i, k);
            a(abyte0, l, i1, i, k, ai, b1);
            a = b1;
        } else
        {
            a = super.b();
        }
        return a;
    }
}
