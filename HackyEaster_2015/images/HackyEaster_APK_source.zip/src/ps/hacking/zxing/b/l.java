// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.b;

import java.util.Map;
import ps.hacking.zxing.e;

public final class l
{

    private static final String a = System.getProperty("file.encoding");
    private static final boolean b;

    public static String a(byte abyte0[], Map map)
    {
        int i;
        boolean flag;
        boolean flag1;
        int j;
        int k;
        int i1;
        int j1;
        int k1;
        int l1;
        int i2;
        int j2;
        int k2;
        boolean flag2;
        int i3;
        int j3;
        boolean flag3;
        int k3;
        boolean flag5;
        int l3;
        int i4;
        int j4;
        boolean flag6;
        int l4;
        int i5;
        if (map != null)
        {
            String s = (String)map.get(e.e);
            if (s != null)
            {
                return s;
            }
        }
        i = abyte0.length;
        flag = true;
        flag1 = true;
        j = 0;
        k = 0;
        i1 = 0;
        j1 = 0;
        k1 = 0;
        l1 = 0;
        i2 = 0;
        j2 = 0;
        k2 = 0;
        int l2;
        boolean flag7;
        int l6;
        int i7;
        if (abyte0.length > 3 && abyte0[0] == -17 && abyte0[1] == -69 && abyte0[2] == -65)
        {
            flag2 = true;
        } else
        {
            flag2 = false;
        }
        l2 = 0;
        i3 = 0;
        j3 = 0;
        flag3 = true;
_L3:
        if (l2 >= i || !flag && !flag1 && !flag3) goto _L2; else goto _L1
_L1:
        k3 = 0xff & abyte0[l2];
        if (!flag3)
        {
            break MISSING_BLOCK_LABEL_896;
        }
        if (j > 0)
        {
            if ((k3 & 0x80) == 0)
            {
                flag5 = false;
            } else
            {
                j--;
                flag5 = flag3;
            }
        } else
        {
            if ((k3 & 0x80) == 0)
            {
                break MISSING_BLOCK_LABEL_896;
            }
            if ((k3 & 0x40) == 0)
            {
                flag5 = false;
            } else
            {
                j++;
                if ((k3 & 0x20) == 0)
                {
                    k++;
                    flag5 = flag3;
                } else
                {
                    j++;
                    if ((k3 & 0x10) == 0)
                    {
                        i1++;
                        flag5 = flag3;
                    } else
                    {
                        j++;
                        if ((k3 & 8) == 0)
                        {
                            j1++;
                            flag5 = flag3;
                        } else
                        {
                            flag5 = false;
                        }
                    }
                }
            }
        }
_L4:
        if (flag)
        {
            if (k3 > 127 && k3 < 160)
            {
                flag = false;
            } else
            if (k3 > 159 && (k3 < 192 || k3 == 215 || k3 == 247))
            {
                k2++;
            }
        }
        if (flag1)
        {
            if (k1 > 0)
            {
                if (k3 < 64 || k3 == 127 || k3 > 252)
                {
                    l6 = j2;
                    l4 = j3;
                    i5 = l6;
                    i7 = i2;
                    i4 = l1;
                    j4 = k1;
                    flag6 = false;
                    l3 = i7;
                } else
                {
                    int j7 = k1 - 1;
                    flag6 = flag1;
                    int k7 = j3;
                    i5 = j2;
                    l4 = k7;
                    int l7 = l1;
                    j4 = j7;
                    l3 = i2;
                    i4 = l7;
                }
            } else
            if (k3 == 128 || k3 == 160 || k3 > 239)
            {
                int j5 = j2;
                l4 = j3;
                i5 = j5;
                int k5 = i2;
                i4 = l1;
                j4 = k1;
                l3 = k5;
                flag6 = false;
            } else
            if (k3 > 160 && k3 < 224)
            {
                int j6 = l1 + 1;
                i5 = i2 + 1;
                boolean flag4;
                int l5;
                int i6;
                if (i5 > j2)
                {
                    i4 = j6;
                    l3 = i5;
                    j4 = k1;
                    flag6 = flag1;
                    l4 = 0;
                } else
                {
                    i4 = j6;
                    j4 = k1;
                    flag6 = flag1;
                    int k6 = j2;
                    l3 = i5;
                    i5 = k6;
                    l4 = 0;
                }
            } else
            if (k3 > 127)
            {
                l5 = k1 + 1;
                i6 = j3 + 1;
                if (i6 > i3)
                {
                    i3 = i6;
                    flag6 = flag1;
                    i5 = j2;
                    l4 = i6;
                    i4 = l1;
                    j4 = l5;
                    l3 = 0;
                } else
                {
                    flag6 = flag1;
                    i5 = j2;
                    l4 = i6;
                    i4 = l1;
                    j4 = l5;
                    l3 = 0;
                }
            } else
            {
                i4 = l1;
                j4 = k1;
                flag6 = flag1;
                i5 = j2;
                l4 = 0;
                l3 = 0;
            }
        } else
        {
            l3 = i2;
            i4 = l1;
            j4 = k1;
            flag6 = flag1;
            int k4 = j2;
            l4 = j3;
            i5 = k4;
        }
        l2++;
        flag1 = flag6;
        k1 = j4;
        l1 = i4;
        i2 = l3;
        flag3 = flag5;
        flag7 = l4;
        j2 = i5;
        j3 = ((flag7) ? 1 : 0);
        if (true) goto _L3; else goto _L2
_L2:
        if (flag3 && j > 0)
        {
            flag4 = false;
        } else
        {
            flag4 = flag3;
        }
        if (flag1 && k1 > 0)
        {
            flag1 = false;
        }
        if (flag4 && (flag2 || j1 + (k + i1) > 0))
        {
            return "UTF8";
        }
        if (flag1 && (b || j2 >= 3 || i3 >= 3))
        {
            return "SJIS";
        }
        if (flag && flag1)
        {
            if (j2 == 2 && l1 == 2 || k2 * 10 >= i)
            {
                return "SJIS";
            } else
            {
                return "ISO8859_1";
            }
        }
        if (flag)
        {
            return "ISO8859_1";
        }
        if (flag1)
        {
            return "SJIS";
        }
        if (flag4)
        {
            return "UTF8";
        } else
        {
            return a;
        }
        flag5 = flag3;
          goto _L4
    }

    static 
    {
        boolean flag;
        if ("SJIS".equalsIgnoreCase(a) || "EUC_JP".equalsIgnoreCase(a))
        {
            flag = true;
        } else
        {
            flag = false;
        }
        b = flag;
    }
}
