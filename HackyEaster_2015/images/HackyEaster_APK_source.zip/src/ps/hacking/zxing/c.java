// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing;

import ps.hacking.zxing.b.a;
import ps.hacking.zxing.b.b;

// Referenced classes of package ps.hacking.zxing:
//            b, g

public final class c
{

    private final ps.hacking.zxing.b a;
    private b b;

    public c(ps.hacking.zxing.b b1)
    {
        if (b1 == null)
        {
            throw new IllegalArgumentException("Binarizer must be non-null.");
        } else
        {
            a = b1;
            return;
        }
    }

    public int a()
    {
        return a.c();
    }

    public a a(int i, a a1)
    {
        return a.(i, a1);
    }

    public int b()
    {
        return a.d();
    }

    public b c()
    {
        if (b == null)
        {
            b = a.();
        }
        return b;
    }

    public boolean d()
    {
        return a.().d();
    }

    public c e()
    {
        g g1 = a.().e();
        return new c(a.(g1));
    }
}
