// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.c;

import java.util.Map;
import ps.hacking.zxing.b.b;
import ps.hacking.zxing.b.g;
import ps.hacking.zxing.c;
import ps.hacking.zxing.c.a.f;
import ps.hacking.zxing.e;
import ps.hacking.zxing.i;
import ps.hacking.zxing.k;
import ps.hacking.zxing.m;
import ps.hacking.zxing.n;
import ps.hacking.zxing.o;

public final class a
    implements k
{

    private static final o a[] = new o[0];
    private final f b = new f();

    public a()
    {
    }

    private static int a(int ai[], b b1)
    {
        int j = b1.d();
        int l = ai[0];
        for (int i1 = ai[1]; l < j && b1.a(l, i1); l++) { }
        if (l == j)
        {
            throw i.a();
        }
        int j1 = l - ai[0];
        if (j1 == 0)
        {
            throw i.a();
        } else
        {
            return j1;
        }
    }

    private static b a(b b1)
    {
        int ai[] = b1.b();
        int ai1[] = b1.c();
        if (ai == null || ai1 == null)
        {
            throw i.a();
        }
        int j = a(ai, b1);
        int l = ai[1];
        int i1 = ai1[1];
        int j1 = ai[0];
        int k1 = (1 + (ai1[0] - j1)) / j;
        int l1 = (1 + (i1 - l)) / j;
        if (k1 <= 0 || l1 <= 0)
        {
            throw i.a();
        }
        int i2 = j >> 1;
        int j2 = l + i2;
        int k2 = j1 + i2;
        b b2 = new b(k1, l1);
        for (int l2 = 0; l2 < l1; l2++)
        {
            int i3 = j2 + l2 * j;
            for (int j3 = 0; j3 < k1; j3++)
            {
                if (b1.a(k2 + j3 * j, i3))
                {
                    b2.b(j3, l2);
                }
            }

        }

        return b2;
    }

    public m a(c c1, Map map)
    {
        ps.hacking.zxing.b.e e1;
        o ao[];
        m m1;
        java.util.List list;
        String s;
        if (map != null && map.containsKey(e.b))
        {
            b b1 = a(c1.c());
            e1 = b.a(b1);
            ao = a;
        } else
        {
            g g1 = (new ps.hacking.zxing.c.b.a(c1.c())).a();
            e1 = b.a(g1.d());
            ao = g1.e();
        }
        m1 = new m(e1.b(), e1.a(), ao, ps.hacking.zxing.a.f);
        list = e1.c();
        if (list != null)
        {
            m1.a(n.c, list);
        }
        s = e1.d();
        if (s != null)
        {
            m1.a(n.d, s);
        }
        return m1;
    }

    public void a()
    {
    }

}
