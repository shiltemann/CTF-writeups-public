// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.c.a;


// Referenced classes of package ps.hacking.zxing.c.a:
//            g, j, i

final class b
{

    private final int a;
    private final byte b[];

    private b(int k, byte abyte0[])
    {
        a = k;
        b = abyte0;
    }

    static b[] a(byte abyte0[], g g1)
    {
        j j1 = g1.g();
        i ai[] = j1.b();
        int k = ai.length;
        int l = 0;
        int i1 = 0;
        for (; l < k; l++)
        {
            i1 += ai[l].a();
        }

        b ab[] = new b[i1];
        int k1 = ai.length;
        int l1 = 0;
        int i2;
        int k6;
        for (i2 = 0; l1 < k1; i2 = k6)
        {
            i j6 = ai[l1];
            k6 = i2;
            for (int l6 = 0; l6 < j6.a();)
            {
                int i7 = j6.b();
                int j7 = i7 + j1.a();
                int k7 = k6 + 1;
                ab[k6] = new b(i7, new byte[j7]);
                l6++;
                k6 = k7;
            }

            l1++;
        }

        int j2 = ab[0].b.length - j1.a();
        int k2 = j2 - 1;
        int l2 = 0;
        int i3 = 0;
        for (; l2 < k2; l2++)
        {
            for (int l5 = 0; l5 < i2;)
            {
                byte abyte3[] = ab[l5].b;
                int i6 = i3 + 1;
                abyte3[l2] = abyte0[i3];
                l5++;
                i3 = i6;
            }

        }

        boolean flag;
        int j3;
        int k3;
        if (g1.a() == 24)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (flag)
        {
            j3 = 8;
        } else
        {
            j3 = i2;
        }
        for (k3 = 0; k3 < j3;)
        {
            byte abyte2[] = ab[k3].b;
            int j5 = j2 - 1;
            int k5 = i3 + 1;
            abyte2[j5] = abyte0[i3];
            k3++;
            i3 = k5;
        }

        int l3 = ab[0].b.length;
        int i4;
        int k4;
        for (i4 = i3; j2 < l3; i4 = k4)
        {
            int j4 = 0;
            k4 = i4;
            while (j4 < i2) 
            {
                int l4;
                byte abyte1[];
                int i5;
                if (flag && j4 > 7)
                {
                    l4 = j2 - 1;
                } else
                {
                    l4 = j2;
                }
                abyte1 = ab[j4].b;
                i5 = k4 + 1;
                abyte1[l4] = abyte0[k4];
                j4++;
                k4 = i5;
            }
            j2++;
        }

        if (i4 != abyte0.length)
        {
            throw new IllegalArgumentException();
        } else
        {
            return ab;
        }
    }

    int a()
    {
        return a;
    }

    byte[] b()
    {
        return b;
    }
}
