// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.c.a;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import ps.hacking.zxing.b.e;
import ps.hacking.zxing.f;

// Referenced classes of package ps.hacking.zxing.c.a:
//            e, d

final class c
{

    private static final char a[] = {
        '*', '*', '*', ' ', '0', '1', '2', '3', '4', '5', 
        '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F', 
        'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 
        'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'
    };
    private static final char b[] = {
        '!', '"', '#', '$', '%', '&', '\'', '(', ')', '*', 
        '+', ',', '-', '.', '/', ':', ';', '<', '=', '>', 
        '?', '@', '[', '\\', ']', '^', '_'
    };
    private static final char c[] = {
        '*', '*', '*', ' ', '0', '1', '2', '3', '4', '5', 
        '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f', 
        'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 
        'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'
    };
    private static final char d[] = {
        '\'', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 
        'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 
        'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '{', '|', '}', 
        '~', '\177'
    };

    private static int a(int i, int j)
    {
        int k = i - (1 + (j * 149) % 255);
        if (k >= 0)
        {
            return k;
        } else
        {
            return k + 256;
        }
    }

    static e a(byte abyte0[])
    {
        ps.hacking.zxing.b.c c1;
        StringBuilder stringbuilder;
        StringBuilder stringbuilder1;
        ArrayList arraylist;
        ps.hacking.zxing.c.a.e e1;
        c1 = new ps.hacking.zxing.b.c(abyte0);
        stringbuilder = new StringBuilder(100);
        stringbuilder1 = new StringBuilder(0);
        arraylist = new ArrayList(1);
        e1 = e.b;
_L3:
        if (e1 != e.b) goto _L2; else goto _L1
_L1:
        e1 = a(c1, stringbuilder, stringbuilder1);
_L10:
        if (e1 == e.a || c1.c() <= 0)
        {
            if (stringbuilder1.length() > 0)
            {
                stringbuilder.append(stringbuilder1.toString());
            }
            String s = stringbuilder.toString();
            Object obj;
            if (arraylist.isEmpty())
            {
                obj = null;
            } else
            {
                obj = arraylist;
            }
            return new e(abyte0, s, ((List) (obj)), null);
        }
        if (true) goto _L3; else goto _L2
_L2:
        d.a[e1.ordinal()];
        JVM INSTR tableswitch 1 5: default 168
    //                   1 172
    //                   2 185
    //                   3 193
    //                   4 201
    //                   5 209;
           goto _L4 _L5 _L6 _L7 _L8 _L9
_L9:
        break MISSING_BLOCK_LABEL_209;
_L4:
        throw f.a();
_L5:
        a(c1, stringbuilder);
_L11:
        e1 = e.b;
          goto _L10
_L6:
        b(c1, stringbuilder);
          goto _L11
_L7:
        c(c1, stringbuilder);
          goto _L11
_L8:
        d(c1, stringbuilder);
          goto _L11
        a(c1, stringbuilder, ((Collection) (arraylist)));
          goto _L11
    }

    private static ps.hacking.zxing.c.a.e a(ps.hacking.zxing.b.c c1, StringBuilder stringbuilder, StringBuilder stringbuilder1)
    {
        boolean flag = false;
        do
        {
            int i = c1.a(8);
            if (i == 0)
            {
                throw f.a();
            }
            if (i <= 128)
            {
                int j;
                int k;
                if (flag)
                {
                    k = i + 128;
                } else
                {
                    k = i;
                }
                stringbuilder.append((char)(k - 1));
                return e.b;
            }
            if (i == 129)
            {
                return e.a;
            }
            if (i <= 229)
            {
                j = i - 130;
                if (j < 10)
                {
                    stringbuilder.append('0');
                }
                stringbuilder.append(j);
            } else
            {
                if (i == 230)
                {
                    return e.c;
                }
                if (i == 231)
                {
                    return e.g;
                }
                if (i == 232)
                {
                    stringbuilder.append('\035');
                } else
                if (i != 233 && i != 234)
                {
                    if (i == 235)
                    {
                        flag = true;
                    } else
                    if (i == 236)
                    {
                        stringbuilder.append("[)>\03605\035");
                        stringbuilder1.insert(0, "\036\004");
                    } else
                    if (i == 237)
                    {
                        stringbuilder.append("[)>\03606\035");
                        stringbuilder1.insert(0, "\036\004");
                    } else
                    {
                        if (i == 238)
                        {
                            return ps.hacking.zxing.c.a.e.e;
                        }
                        if (i == 239)
                        {
                            return e.d;
                        }
                        if (i == 240)
                        {
                            return ps.hacking.zxing.c.a.e.f;
                        }
                        if (i != 241 && i >= 242 && (i != 254 || c1.c() != 0))
                        {
                            throw f.a();
                        }
                    }
                }
            }
            if (c1.c() <= 0)
            {
                return e.b;
            }
        } while (true);
    }

    private static void a(int i, int j, int ai[])
    {
        int k = -1 + (j + (i << 8));
        int l = k / 1600;
        ai[0] = l;
        int i1 = k - l * 1600;
        int j1 = i1 / 40;
        ai[1] = j1;
        ai[2] = i1 - j1 * 40;
    }

    private static void a(ps.hacking.zxing.b.c c1, StringBuilder stringbuilder)
    {
        int ai[];
        int i;
        boolean flag;
        ai = new int[3];
        i = 0;
        flag = false;
_L13:
        if (c1.c() != 8) goto _L2; else goto _L1
_L1:
        int j;
        return;
_L2:
        if ((j = c1.a(8)) == 254) goto _L1; else goto _L3
_L3:
        int k;
        a(j, c1.a(8), ai);
        k = 0;
_L10:
        int l;
        if (k >= 3)
        {
            continue; /* Loop/switch isn't completed */
        }
        l = ai[k];
        i;
        JVM INSTR tableswitch 0 3: default 92
    //                   0 96
    //                   1 167
    //                   2 203
    //                   3 289;
           goto _L4 _L5 _L6 _L7 _L8
_L8:
        break MISSING_BLOCK_LABEL_289;
_L6:
        break; /* Loop/switch isn't completed */
_L4:
        throw f.a();
_L5:
        if (l < 3)
        {
            i = l + 1;
        } else
        if (l < a.length)
        {
            char c3 = a[l];
            if (flag)
            {
                stringbuilder.append((char)(c3 + 128));
                flag = false;
            } else
            {
                stringbuilder.append(c3);
            }
        } else
        {
            throw f.a();
        }
_L11:
        k++;
        if (true) goto _L10; else goto _L9
_L9:
        if (flag)
        {
            stringbuilder.append((char)(l + 128));
            flag = false;
        } else
        {
            stringbuilder.append((char)l);
        }
        i = 0;
          goto _L11
_L7:
        if (l < b.length)
        {
            char c2 = b[l];
            if (flag)
            {
                stringbuilder.append((char)(c2 + 128));
                flag = false;
            } else
            {
                stringbuilder.append(c2);
            }
        } else
        if (l == 27)
        {
            stringbuilder.append('\035');
        } else
        if (l == 30)
        {
            flag = true;
        } else
        {
            throw f.a();
        }
        i = 0;
          goto _L11
        if (flag)
        {
            stringbuilder.append((char)(l + 224));
            flag = false;
        } else
        {
            stringbuilder.append((char)(l + 96));
        }
        i = 0;
          goto _L11
        if (c1.c() > 0) goto _L13; else goto _L12
_L12:
    }

    private static void a(ps.hacking.zxing.b.c c1, StringBuilder stringbuilder, Collection collection)
    {
        int i = 1 + c1.b();
        int j = c1.a(8);
        int k = i + 1;
        int l = a(j, i);
        int l1;
        if (l == 0)
        {
            l1 = c1.c() / 8;
        } else
        if (l < 250)
        {
            l1 = l;
        } else
        {
            int i1 = 250 * (l - 249);
            int j1 = c1.a(8);
            int k1 = k + 1;
            l1 = i1 + a(j1, k);
            k = k1;
        }
        if (l1 < 0)
        {
            throw f.a();
        }
        byte abyte0[] = new byte[l1];
        for (int i2 = 0; i2 < l1;)
        {
            if (c1.c() < 8)
            {
                throw f.a();
            }
            int j2 = c1.a(8);
            int k2 = k + 1;
            abyte0[i2] = (byte)a(j2, k);
            i2++;
            k = k2;
        }

        collection.add(abyte0);
        try
        {
            stringbuilder.append(new String(abyte0, "ISO8859_1"));
            return;
        }
        catch (UnsupportedEncodingException unsupportedencodingexception)
        {
            throw new IllegalStateException((new StringBuilder()).append("Platform does not support required encoding: ").append(unsupportedencodingexception).toString());
        }
    }

    private static void b(ps.hacking.zxing.b.c c1, StringBuilder stringbuilder)
    {
        int ai[];
        int i;
        boolean flag;
        ai = new int[3];
        i = 0;
        flag = false;
_L13:
        if (c1.c() != 8) goto _L2; else goto _L1
_L1:
        int j;
        return;
_L2:
        if ((j = c1.a(8)) == 254) goto _L1; else goto _L3
_L3:
        int k;
        a(j, c1.a(8), ai);
        k = 0;
_L10:
        int l;
        if (k >= 3)
        {
            continue; /* Loop/switch isn't completed */
        }
        l = ai[k];
        i;
        JVM INSTR tableswitch 0 3: default 92
    //                   0 96
    //                   1 167
    //                   2 203
    //                   3 289;
           goto _L4 _L5 _L6 _L7 _L8
_L8:
        break MISSING_BLOCK_LABEL_289;
_L6:
        break; /* Loop/switch isn't completed */
_L4:
        throw f.a();
_L5:
        if (l < 3)
        {
            i = l + 1;
        } else
        if (l < c.length)
        {
            char c4 = c[l];
            if (flag)
            {
                stringbuilder.append((char)(c4 + 128));
                flag = false;
            } else
            {
                stringbuilder.append(c4);
            }
        } else
        {
            throw f.a();
        }
_L11:
        k++;
        if (true) goto _L10; else goto _L9
_L9:
        if (flag)
        {
            stringbuilder.append((char)(l + 128));
            flag = false;
        } else
        {
            stringbuilder.append((char)l);
        }
        i = 0;
          goto _L11
_L7:
        if (l < b.length)
        {
            char c3 = b[l];
            if (flag)
            {
                stringbuilder.append((char)(c3 + 128));
                flag = false;
            } else
            {
                stringbuilder.append(c3);
            }
        } else
        if (l == 27)
        {
            stringbuilder.append('\035');
        } else
        if (l == 30)
        {
            flag = true;
        } else
        {
            throw f.a();
        }
        i = 0;
          goto _L11
        if (l < d.length)
        {
            char c2 = d[l];
            if (flag)
            {
                stringbuilder.append((char)(c2 + 128));
                flag = false;
            } else
            {
                stringbuilder.append(c2);
            }
            i = 0;
        } else
        {
            throw f.a();
        }
          goto _L11
        if (c1.c() > 0) goto _L13; else goto _L12
_L12:
    }

    private static void c(ps.hacking.zxing.b.c c1, StringBuilder stringbuilder)
    {
        int ai[] = new int[3];
_L5:
        if (c1.c() != 8) goto _L2; else goto _L1
_L1:
        int i;
        return;
_L2:
        if ((i = c1.a(8)) == 254) goto _L1; else goto _L3
_L3:
        a(i, c1.a(8), ai);
        int j = 0;
        while (j < 3) 
        {
            int k = ai[j];
            if (k == 0)
            {
                stringbuilder.append('\r');
            } else
            if (k == 1)
            {
                stringbuilder.append('*');
            } else
            if (k == 2)
            {
                stringbuilder.append('>');
            } else
            if (k == 3)
            {
                stringbuilder.append(' ');
            } else
            if (k < 14)
            {
                stringbuilder.append((char)(k + 44));
            } else
            if (k < 40)
            {
                stringbuilder.append((char)(k + 51));
            } else
            {
                throw f.a();
            }
            j++;
        }
        if (c1.c() <= 0)
        {
            return;
        }
        if (true) goto _L5; else goto _L4
_L4:
    }

    private static void d(ps.hacking.zxing.b.c c1, StringBuilder stringbuilder)
    {
_L7:
        if (c1.c() > 16) goto _L2; else goto _L1
_L1:
        return;
_L2:
        int i = 0;
_L5:
        if (i >= 4) goto _L4; else goto _L3
_L3:
        int j;
label0:
        {
            j = c1.a(6);
            if (j != 31)
            {
                break label0;
            }
            int k = 8 - c1.a();
            if (k != 8)
            {
                c1.a(k);
                return;
            }
        }
          goto _L1
        if ((j & 0x20) == 0)
        {
            j |= 0x40;
        }
        stringbuilder.append((char)j);
        i++;
          goto _L5
_L4:
        if (c1.c() <= 0)
        {
            return;
        }
        if (true) goto _L7; else goto _L6
_L6:
    }

}
