// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.c.a;

import ps.hacking.zxing.b.b;
import ps.hacking.zxing.b.b.a;
import ps.hacking.zxing.b.b.c;
import ps.hacking.zxing.b.b.d;
import ps.hacking.zxing.b.e;

// Referenced classes of package ps.hacking.zxing.c.a:
//            a, b, c

public final class f
{

    private final c a;

    public f()
    {
        a = new c(a.f);
    }

    private void a(byte abyte0[], int i)
    {
        int j = 0;
        int k = abyte0.length;
        int ai[] = new int[k];
        for (int l = 0; l < k; l++)
        {
            ai[l] = 0xff & abyte0[l];
        }

        int i1 = abyte0.length - i;
        try
        {
            a.a(ai, i1);
        }
        catch (d d1)
        {
            throw ps.hacking.zxing.d.a();
        }
        for (; j < i; j++)
        {
            abyte0[j] = (byte)ai[j];
        }

    }

    public e a(b b1)
    {
        ps.hacking.zxing.c.a.a a1 = new ps.hacking.zxing.c.a.a(b1);
        g g = a1.a();
        ps.hacking.zxing.c.a.b ab[] = ps.hacking.zxing.c.a.b.a(a1.b(), g);
        int i = ab.length;
        int j = ab.length;
        int k = 0;
        int l = 0;
        for (; k < j; k++)
        {
            l += ab[k].a();
        }

        byte abyte0[] = new byte[l];
        for (int i1 = 0; i1 < i; i1++)
        {
            ps.hacking.zxing.c.a.b b2 = ab[i1];
            byte abyte1[] = b2.b();
            int j1 = b2.a();
            a(abyte1, j1);
            for (int k1 = 0; k1 < j1; k1++)
            {
                abyte0[i1 + k1 * i] = abyte1[k1];
            }

        }

        return ps.hacking.zxing.c.a.c.a(abyte0);
    }
}
