// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.c.a;


// Referenced classes of package ps.hacking.zxing.c.a:
//            h

final class i
{

    private final int a;
    private final int b;

    private i(int j, int k)
    {
        a = j;
        b = k;
    }

    i(int j, int k, h h)
    {
        this(j, k);
    }

    int a()
    {
        return a;
    }

    int b()
    {
        return b;
    }
}
