// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.c.b;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import ps.hacking.zxing.b.a.b;
import ps.hacking.zxing.b.g;
import ps.hacking.zxing.b.i;
import ps.hacking.zxing.o;

// Referenced classes of package ps.hacking.zxing.c.b:
//            c, d

public final class a
{

    private final ps.hacking.zxing.b.b a;
    private final b b;

    public a(ps.hacking.zxing.b.b b1)
    {
        a = b1;
        b = new b(b1);
    }

    private static int a(o o1, o o2)
    {
        return ps.hacking.zxing.b.a.a.a(o.a(o1, o2));
    }

    private static ps.hacking.zxing.b.b a(ps.hacking.zxing.b.b b1, o o1, o o2, o o3, o o4, int j, int k)
    {
        return i.a().a(b1, j, k, 0.5F, 0.5F, (float)j - 0.5F, 0.5F, (float)j - 0.5F, (float)k - 0.5F, 0.5F, (float)k - 0.5F, o1.a(), o1.b(), o4.a(), o4.b(), o3.a(), o3.b(), o2.a(), o2.b());
    }

    private o a(o o1, o o2, o o3, o o4, int j)
    {
        o o5;
        o o6;
        float f = (float)a(o1, o2) / (float)j;
        int k = a(o3, o4);
        float f1 = (o4.a() - o3.a()) / (float)k;
        float f2 = (o4.b() - o3.b()) / (float)k;
        o5 = new o(o4.a() + f1 * f, o4.b() + f * f2);
        float f3 = (float)a(o1, o3) / (float)j;
        int l = a(o2, o4);
        float f4 = (o4.a() - o2.a()) / (float)l;
        float f5 = (o4.b() - o2.b()) / (float)l;
        o6 = new o(o4.a() + f4 * f3, o4.b() + f3 * f5);
        if (a(o5)) goto _L2; else goto _L1
_L1:
        if (!a(o6)) goto _L4; else goto _L3
_L3:
        o5 = o6;
_L6:
        return o5;
_L4:
        return null;
_L2:
        if (a(o6) && Math.abs(b(o3, o5).c() - b(o2, o5).c()) > Math.abs(b(o3, o6).c() - b(o2, o6).c()))
        {
            return o6;
        }
        if (true) goto _L6; else goto _L5
_L5:
    }

    private o a(o o1, o o2, o o3, o o4, int j, int k)
    {
        o o5;
        o o6;
        float f = (float)a(o1, o2) / (float)j;
        int l = a(o3, o4);
        float f1 = (o4.a() - o3.a()) / (float)l;
        float f2 = (o4.b() - o3.b()) / (float)l;
        o5 = new o(o4.a() + f1 * f, o4.b() + f * f2);
        float f3 = (float)a(o1, o3) / (float)k;
        int i1 = a(o2, o4);
        float f4 = (o4.a() - o2.a()) / (float)i1;
        float f5 = (o4.b() - o2.b()) / (float)i1;
        o6 = new o(o4.a() + f4 * f3, o4.b() + f3 * f5);
        if (a(o5)) goto _L2; else goto _L1
_L1:
        if (!a(o6)) goto _L4; else goto _L3
_L3:
        return o6;
_L4:
        return null;
_L2:
        if (!a(o6))
        {
            return o5;
        }
        if (Math.abs(j - b(o3, o5).c()) + Math.abs(k - b(o2, o5).c()) <= Math.abs(j - b(o3, o6).c()) + Math.abs(k - b(o2, o6).c()))
        {
            return o5;
        }
        if (true) goto _L3; else goto _L5
_L5:
    }

    private static void a(Map map, o o1)
    {
        Integer integer = (Integer)map.get(o1);
        int j;
        if (integer == null)
        {
            j = 1;
        } else
        {
            j = 1 + integer.intValue();
        }
        map.put(o1, Integer.valueOf(j));
    }

    private boolean a(o o1)
    {
        return o1.a() >= 0.0F && o1.a() < (float)a.d() && o1.b() > 0.0F && o1.b() < (float)a.e();
    }

    private c b(o o1, o o2)
    {
        int j = (int)o1.a();
        int k = (int)o1.b();
        int l = (int)o2.a();
        int i1 = (int)o2.b();
        boolean flag;
        int l1;
        int i2;
        int j2;
        byte byte0;
        byte byte1;
        int k2;
        ps.hacking.zxing.b.b b1;
        int l2;
        int i3;
        boolean flag1;
        int j3;
        int k3;
        int l3;
        ps.hacking.zxing.b.b b2;
        int i4;
        int j4;
        boolean flag2;
        int k4;
        if (Math.abs(i1 - k) > Math.abs(l - j))
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (!flag)
        {
            int j1 = i1;
            i1 = l;
            l = j1;
            int k1 = k;
            k = j;
            j = k1;
        }
        l1 = Math.abs(i1 - k);
        i2 = Math.abs(l - j);
        j2 = -l1 >> 1;
        if (j < l)
        {
            byte0 = 1;
        } else
        {
            byte0 = -1;
        }
        if (k < i1)
        {
            byte1 = 1;
        } else
        {
            byte1 = -1;
        }
        k2 = 0;
        b1 = a;
        if (flag)
        {
            l2 = j;
        } else
        {
            l2 = k;
        }
        if (flag)
        {
            i3 = k;
        } else
        {
            i3 = j;
        }
        flag1 = b1.a(l2, i3);
        j3 = j;
        k3 = j2;
        if (k == i1) goto _L2; else goto _L1
_L1:
        b2 = a;
        if (flag)
        {
            i4 = j3;
        } else
        {
            i4 = k;
        }
        if (flag)
        {
            j4 = k;
        } else
        {
            j4 = j3;
        }
        flag2 = b2.a(i4, j4);
        if (flag2 != flag1)
        {
            k2++;
            flag1 = flag2;
        }
        k4 = k3 + i2;
        if (k4 <= 0) goto _L4; else goto _L3
_L3:
        if (j3 != l) goto _L6; else goto _L5
_L5:
        l3 = k2;
_L8:
        return new c(o1, o2, l3, null);
_L6:
        j3 += byte0;
        k4 -= l1;
_L4:
        k += byte1;
        k3 = k4;
        break MISSING_BLOCK_LABEL_142;
_L2:
        l3 = k2;
        if (true) goto _L8; else goto _L7
_L7:
    }

    public g a()
    {
        o ao[] = b.a();
        o o1 = ao[0];
        o o2 = ao[1];
        o o3 = ao[2];
        o o4 = ao[3];
        ArrayList arraylist = new ArrayList(4);
        arraylist.add(b(o1, o2));
        arraylist.add(b(o1, o3));
        arraylist.add(b(o2, o4));
        arraylist.add(b(o3, o4));
        Collections.sort(arraylist, new d(null));
        c c1 = (c)arraylist.get(0);
        c c2 = (c)arraylist.get(1);
        HashMap hashmap = new HashMap();
        a(((Map) (hashmap)), c1.a());
        a(((Map) (hashmap)), c1.b());
        a(((Map) (hashmap)), c2.a());
        a(((Map) (hashmap)), c2.b());
        o o5 = null;
        o o6 = null;
        o o7 = null;
        Iterator iterator = hashmap.entrySet().iterator();
        while (iterator.hasNext()) 
        {
            java.util.Map.Entry entry = (java.util.Map.Entry)iterator.next();
            o o13 = (o)entry.getKey();
            o o14;
            o o15;
            if (((Integer)entry.getValue()).intValue() == 2)
            {
                o14 = o13;
                o13 = o7;
                o15 = o5;
            } else
            if (o5 == null)
            {
                o14 = o6;
                o o16 = o7;
                o15 = o13;
                o13 = o16;
            } else
            {
                o14 = o6;
                o15 = o5;
            }
            o6 = o14;
            o5 = o15;
            o7 = o13;
        }
        if (o5 == null || o6 == null || o7 == null)
        {
            throw ps.hacking.zxing.i.a();
        }
        o ao1[] = {
            o5, o6, o7
        };
        o.a(ao1);
        o o8 = ao1[0];
        o o9 = ao1[1];
        o o10 = ao1[2];
        o o11;
        int j;
        int k;
        int l;
        int i1;
        o o12;
        ps.hacking.zxing.b.b b1;
        if (!hashmap.containsKey(o1))
        {
            o11 = o1;
        } else
        if (!hashmap.containsKey(o2))
        {
            o11 = o2;
        } else
        if (!hashmap.containsKey(o3))
        {
            o11 = o3;
        } else
        {
            o11 = o4;
        }
        j = b(o10, o11).c();
        k = b(o8, o11).c();
        if ((j & 1) == 1)
        {
            j++;
        }
        l = j + 2;
        if ((k & 1) == 1)
        {
            k++;
        }
        i1 = k + 2;
        if (l * 4 >= i1 * 7 || i1 * 4 >= l * 7)
        {
            o12 = a(o9, o8, o10, o11, l, i1);
            if (o12 == null)
            {
                o12 = o11;
            }
            int j1 = b(o10, o12).c();
            int k1 = b(o8, o12).c();
            if ((j1 & 1) == 1)
            {
                j1++;
            }
            if ((k1 & 1) == 1)
            {
                k1++;
            }
            b1 = a(a, o10, o9, o8, o12, j1, k1);
        } else
        {
            o12 = a(o9, o8, o10, o11, Math.min(i1, l));
            if (o12 == null)
            {
                o12 = o11;
            }
            int l1 = 1 + Math.max(b(o10, o12).c(), b(o8, o12).c());
            if ((l1 & 1) == 1)
            {
                l1++;
            }
            b1 = a(a, o10, o9, o8, o12, l1, l1);
        }
        return new g(b1, new o[] {
            o10, o9, o8, o12
        });
    }
}
