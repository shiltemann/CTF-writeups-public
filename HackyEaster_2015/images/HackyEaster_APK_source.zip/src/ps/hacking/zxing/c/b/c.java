// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.c.b;

import ps.hacking.zxing.o;

// Referenced classes of package ps.hacking.zxing.c.b:
//            b

final class c
{

    private final o a;
    private final o b;
    private final int c;

    private c(o o, o o1, int i)
    {
        a = o;
        b = o1;
        c = i;
    }

    c(o o, o o1, int i, b b1)
    {
        this(o, o1, i);
    }

    o a()
    {
        return a;
    }

    o b()
    {
        return b;
    }

    public int c()
    {
        return c;
    }

    public String toString()
    {
        return (new StringBuilder()).append(a).append("/").append(b).append('/').append(c).toString();
    }
}
