// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.d;

import java.util.Map;
import ps.hacking.zxing.b.b;
import ps.hacking.zxing.d.a.c;
import ps.hacking.zxing.e;
import ps.hacking.zxing.i;
import ps.hacking.zxing.k;
import ps.hacking.zxing.m;
import ps.hacking.zxing.n;
import ps.hacking.zxing.o;

public final class a
    implements k
{

    private static final o a[] = new o[0];
    private final c b = new c();

    public a()
    {
    }

    private static b a(b b1)
    {
        int ai[] = b1.a();
        if (ai == null)
        {
            throw i.a();
        }
        int j = ai[0];
        int l = ai[1];
        int i1 = ai[2];
        int j1 = ai[3];
        b b2 = new b(30, 33);
        for (int k1 = 0; k1 < 33; k1++)
        {
            int l1 = l + (k1 * j1 + j1 / 2) / 33;
            for (int i2 = 0; i2 < 30; i2++)
            {
                if (b1.a(j + (i2 * i1 + i1 / 2 + (i1 * (k1 & 1)) / 2) / 30, l1))
                {
                    b2.b(i2, k1);
                }
            }

        }

        return b2;
    }

    public m a(ps.hacking.zxing.c c1, Map map)
    {
        if (map != null && map.containsKey(e.b))
        {
            b b1 = a(c1.c());
            ps.hacking.zxing.b.e e1 = b.a(b1, map);
            o ao[] = a;
            m m1 = new m(e1.b(), e1.a(), ao, ps.hacking.zxing.a.j);
            String s = e1.d();
            if (s != null)
            {
                m1.a(n.d, s);
            }
            return m1;
        } else
        {
            throw i.a();
        }
    }

    public void a()
    {
    }

}
