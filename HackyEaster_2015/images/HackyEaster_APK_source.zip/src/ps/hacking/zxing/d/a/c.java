// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.d.a;

import java.util.Map;
import ps.hacking.zxing.b.b;
import ps.hacking.zxing.b.b.a;
import ps.hacking.zxing.b.b.d;
import ps.hacking.zxing.b.e;
import ps.hacking.zxing.f;

// Referenced classes of package ps.hacking.zxing.d.a:
//            a, b

public final class c
{

    private final ps.hacking.zxing.b.b.c a;

    public c()
    {
        a = new ps.hacking.zxing.b.b.c(a.h);
    }

    private void a(byte abyte0[], int i, int j, int k, int l)
    {
        int i1 = 0;
        int j1 = j + k;
        int k1;
        int ai[];
        if (l == 0)
        {
            k1 = 1;
        } else
        {
            k1 = 2;
        }
        ai = new int[j1 / k1];
        for (int l1 = 0; l1 < j1; l1++)
        {
            if (l == 0 || l1 % 2 == l - 1)
            {
                ai[l1 / k1] = 0xff & abyte0[l1 + i];
            }
        }

        try
        {
            a.a(ai, k / k1);
        }
        catch (d d1)
        {
            throw ps.hacking.zxing.d.a();
        }
        for (; i1 < j; i1++)
        {
            if (l == 0 || i1 % 2 == l - 1)
            {
                abyte0[i1 + i] = (byte)ai[i1 / k1];
            }
        }

    }

    public e a(b b1, Map map)
    {
        byte abyte0[];
        int i;
        abyte0 = (new ps.hacking.zxing.d.a.a(b1)).a();
        a(abyte0, 0, 10, 10, 0);
        i = 0xf & abyte0[0];
        i;
        JVM INSTR tableswitch 2 5: default 64
    //                   2 68
    //                   3 68
    //                   4 68
    //                   5 132;
           goto _L1 _L2 _L2 _L2 _L3
_L1:
        throw f.a();
_L2:
        byte abyte1[];
        a(abyte0, 20, 84, 40, 1);
        a(abyte0, 20, 84, 40, 2);
        abyte1 = new byte[94];
_L5:
        System.arraycopy(abyte0, 0, abyte1, 0, 10);
        System.arraycopy(abyte0, 20, abyte1, 10, -10 + abyte1.length);
        return ps.hacking.zxing.d.a.b.a(abyte1, i);
_L3:
        a(abyte0, 20, 68, 56, 1);
        a(abyte0, 20, 68, 56, 2);
        abyte1 = new byte[78];
        if (true) goto _L5; else goto _L4
_L4:
    }
}
