// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing;


public final class e extends Enum
{

    public static final e a;
    public static final e b;
    public static final e c;
    public static final e d;
    public static final e e;
    public static final e f;
    public static final e g;
    public static final e h;
    private static final e i[];

    private e(String s, int j)
    {
        super(s, j);
    }

    public static e valueOf(String s)
    {
        return (e)Enum.valueOf(ps/hacking/zxing/e, s);
    }

    public static e[] values()
    {
        return (e[])i.clone();
    }

    static 
    {
        a = new e("OTHER", 0);
        b = new e("PURE_BARCODE", 1);
        c = new e("POSSIBLE_FORMATS", 2);
        d = new e("TRY_HARDER", 3);
        e = new e("CHARACTER_SET", 4);
        f = new e("ALLOWED_LENGTHS", 5);
        g = new e("ASSUME_CODE_39_CHECK_DIGIT", 6);
        h = new e("NEED_RESULT_POINT_CALLBACK", 7);
        e ae[] = new e[8];
        ae[0] = a;
        ae[1] = b;
        ae[2] = c;
        ae[3] = d;
        ae[4] = e;
        ae[5] = f;
        ae[6] = g;
        ae[7] = h;
        i = ae;
    }
}
