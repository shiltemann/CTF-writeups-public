// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.e;

import java.util.Map;
import ps.hacking.zxing.i;
import ps.hacking.zxing.m;
import ps.hacking.zxing.o;

// Referenced classes of package ps.hacking.zxing.e:
//            k

public final class a extends k
{

    static final char a[] = "0123456789-$:/.+ABCD".toCharArray();
    static final int b[] = {
        3, 6, 9, 96, 18, 66, 33, 36, 48, 72, 
        12, 24, 69, 81, 84, 21, 26, 41, 11, 14
    };
    private static final char c[] = {
        'A', 'B', 'C', 'D'
    };
    private final StringBuilder d = new StringBuilder(20);
    private int e[];
    private int f;

    public a()
    {
        e = new int[80];
        f = 0;
    }

    private void a(ps.hacking.zxing.b.a a1)
    {
        f = 0;
        int j = a1.d(0);
        int l = a1.a();
        if (j >= l)
        {
            throw i.a();
        }
        boolean flag = true;
        int i1 = j;
        int j1 = 0;
        while (i1 < l) 
        {
            if (flag ^ a1.a(i1))
            {
                j1++;
            } else
            {
                b(j1);
                boolean flag1;
                if (!flag)
                {
                    flag1 = true;
                } else
                {
                    flag1 = false;
                }
                flag = flag1;
                j1 = 1;
            }
            i1++;
        }
        b(j1);
    }

    static boolean a(char ac[], char c1)
    {
        boolean flag = false;
        if (ac == null) goto _L2; else goto _L1
_L1:
        int j;
        int l;
        j = ac.length;
        l = 0;
_L7:
        flag = false;
        if (l >= j) goto _L2; else goto _L3
_L3:
        if (ac[l] != c1) goto _L5; else goto _L4
_L4:
        flag = true;
_L2:
        return flag;
_L5:
        l++;
        if (true) goto _L7; else goto _L6
_L6:
    }

    private int b()
    {
        for (int j = 1; j < f; j += 2)
        {
            int l = c(j);
            if (l == -1 || !a(c, a[l]))
            {
                continue;
            }
            int i1 = 0;
            for (int j1 = j; j1 < j + 7; j1++)
            {
                i1 += e[j1];
            }

            if (j == 1 || e[j - 1] >= i1 / 2)
            {
                return j;
            }
        }

        throw i.a();
    }

    private void b(int j)
    {
        e[f] = j;
        f = 1 + f;
        if (f >= e.length)
        {
            int ai[] = new int[2 * f];
            System.arraycopy(e, 0, ai, 0, f);
            e = ai;
        }
    }

    private int c(int j)
    {
        int l1;
        int i2;
        int l = j + 7;
        if (l >= f)
        {
            return -1;
        }
        int ai[] = {
            0, 0
        };
        int ai1[] = {
            0x7fffffff, 0x7fffffff
        };
        int ai2[] = {
            0, 0
        };
        for (int i1 = 0; i1 < 2; i1++)
        {
            for (int k2 = j + i1; k2 < l; k2 += 2)
            {
                if (e[k2] < ai1[i1])
                {
                    ai1[i1] = e[k2];
                }
                if (e[k2] > ai[i1])
                {
                    ai[i1] = e[k2];
                }
            }

            ai2[i1] = (ai1[i1] + ai[i1]) / 2;
        }

        int j1 = 0;
        int k1 = 128;
        l1 = 0;
        do
        {
            i2 = 0;
            if (j1 >= 7)
            {
                break;
            }
            int j2 = j1 & 1;
            k1 >>= 1;
            if (e[j + j1] > ai2[j2])
            {
                l1 |= k1;
            }
            j1++;
        } while (true);
_L3:
        if (i2 < b.length)
        {
            if (b[i2] == l1)
            {
                return i2;
            }
        } else
        {
            return -1;
        }
        if (true) goto _L2; else goto _L1
_L2:
        i2++;
        if (true) goto _L3; else goto _L1
_L1:
    }

    public m a(int j, ps.hacking.zxing.b.a a1, Map map)
    {
        a(a1);
        int l = b();
        d.setLength(0);
        int i1 = l;
        int j1;
        int k1;
        int l1;
        int i2;
        do
        {
            j1 = c(i1);
            if (j1 == -1)
            {
                throw i.a();
            }
            d.append((char)j1);
            i1 += 8;
        } while ((d.length() <= 1 || !a(c, a[j1])) && i1 < f);
        k1 = e[i1 - 1];
        l1 = -8;
        i2 = 0;
        for (; l1 < -1; l1++)
        {
            i2 += e[i1 + l1];
        }

        if (i1 < f && k1 < i2 / 2)
        {
            throw i.a();
        }
        a(l);
        for (int j2 = 0; j2 < d.length(); j2++)
        {
            d.setCharAt(j2, a[d.charAt(j2)]);
        }

        char c1 = d.charAt(0);
        if (!a(c, c1))
        {
            throw i.a();
        }
        char c2 = d.charAt(-1 + d.length());
        if (!a(c, c2))
        {
            throw i.a();
        }
        if (d.length() <= 3)
        {
            throw i.a();
        }
        d.deleteCharAt(-1 + d.length());
        d.deleteCharAt(0);
        int k2 = 0;
        int l2;
        int i3;
        for (l2 = 0; k2 < l; l2 = i3)
        {
            i3 = l2 + e[k2];
            k2++;
        }

        float f1 = l2;
        for (; l < i1 - 1; l++)
        {
            l2 += e[l];
        }

        float f2 = l2;
        String s = d.toString();
        o ao[] = new o[2];
        ao[0] = new o(f1, j);
        ao[1] = new o(f2, j);
        return new m(s, null, ao, ps.hacking.zxing.a.b);
    }

    void a(int j)
    {
        int ai[] = {
            0, 0, 0, 0
        };
        int ai1[] = {
            0, 0, 0, 0
        };
        int l = -1 + d.length();
        int i1 = 0;
        int j1 = j;
        int ai2[];
        int ai3[];
        int j2;
        do
        {
            int k1 = b[d.charAt(i1)];
            for (int l1 = 6; l1 >= 0; l1--)
            {
                int k3 = (l1 & 1) + 2 * (k1 & 1);
                ai[k3] = ai[k3] + e[j1 + l1];
                ai1[k3] = 1 + ai1[k3];
                k1 >>= 1;
            }

            if (i1 >= l)
            {
                ai2 = new int[4];
                ai3 = new int[4];
                int i2 = 0;
                do
                {
                    j2 = 0;
                    if (i2 >= 2)
                    {
                        break;
                    }
                    ai3[i2] = 0;
                    ai3[i2 + 2] = (ai[i2] << 8) / ai1[i2] + (ai[i2 + 2] << 8) / ai1[i2 + 2] >> 1;
                    ai2[i2] = ai3[i2 + 2];
                    ai2[i2 + 2] = (384 + 512 * ai[i2 + 2]) / ai1[i2 + 2];
                    i2++;
                } while (true);
                break;
            }
            j1 += 8;
            i1++;
        } while (true);
        do
        {
            int k2 = b[d.charAt(j2)];
            for (int l2 = 6; l2 >= 0; l2--)
            {
                int i3 = (l2 & 1) + 2 * (k2 & 1);
                int j3 = e[j + l2] << 8;
                if (j3 < ai3[i3] || j3 > ai2[i3])
                {
                    throw i.a();
                }
                k2 >>= 1;
            }

            if (j2 < l)
            {
                j += 8;
                j2++;
            } else
            {
                return;
            }
        } while (true);
    }

}
