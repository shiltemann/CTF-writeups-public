// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.e.a;

import ps.hacking.zxing.e.k;
import ps.hacking.zxing.i;

public abstract class a extends k
{

    private final int a[] = new int[4];
    private final int b[] = new int[8];
    private final float c[] = new float[4];
    private final float d[] = new float[4];
    private final int e[];
    private final int f[];

    protected a()
    {
        e = new int[b.length / 2];
        f = new int[b.length / 2];
    }

    protected static int a(int ai[])
    {
        int j = 0;
        int l = ai.length;
        int i1 = 0;
        for (; j < l; j++)
        {
            i1 += ai[j];
        }

        return i1;
    }

    protected static int a(int ai[], int ai1[][])
    {
        for (int j = 0; j < ai1.length; j++)
        {
            if (a(ai, ai1[j], 102) < 51)
            {
                return j;
            }
        }

        throw i.a();
    }

    protected static void a(int ai[], float af[])
    {
        int j = 0;
        float f1 = af[0];
        for (int l = 1; l < ai.length; l++)
        {
            if (af[l] > f1)
            {
                f1 = af[l];
                j = l;
            }
        }

        ai[j] = 1 + ai[j];
    }

    protected static void b(int ai[], float af[])
    {
        int j = 0;
        float f1 = af[0];
        for (int l = 1; l < ai.length; l++)
        {
            if (af[l] < f1)
            {
                f1 = af[l];
                j = l;
            }
        }

        ai[j] = -1 + ai[j];
    }

    protected static boolean b(int ai[])
    {
        int j = ai[0] + ai[1];
        int l = j + ai[2] + ai[3];
        float f1 = (float)j / (float)l;
        if (f1 >= 0.7916667F && f1 <= 0.8928571F)
        {
            int i1 = 0x7fffffff;
            int j1 = 0x80000000;
            int k1 = ai.length;
            int l1 = 0;
            while (l1 < k1) 
            {
                int i2 = ai[l1];
                if (i2 > j1)
                {
                    j1 = i2;
                }
                if (i2 >= i1)
                {
                    i2 = i1;
                }
                l1++;
                i1 = i2;
            }
            return j1 < i1 * 10;
        } else
        {
            return false;
        }
    }

    protected final int[] b()
    {
        return a;
    }

    protected final int[] c()
    {
        return b;
    }

    protected final float[] d()
    {
        return c;
    }

    protected final float[] e()
    {
        return d;
    }

    protected final int[] f()
    {
        return e;
    }

    protected final int[] g()
    {
        return f;
    }
}
