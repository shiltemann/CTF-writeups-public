// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.e.a.a;

import java.util.List;
import ps.hacking.zxing.e.a.b;

// Referenced classes of package ps.hacking.zxing.e.a.a:
//            b

final class a
{

    static ps.hacking.zxing.b.a a(List list)
    {
        int i = -1 + (list.size() << 1);
        int j;
        ps.hacking.zxing.b.a a1;
        int k;
        int l;
        int i1;
        int j1;
        int k1;
        if (((ps.hacking.zxing.e.a.a.b)list.get(-1 + list.size())).c() == null)
        {
            j = i - 1;
        } else
        {
            j = i;
        }
        a1 = new ps.hacking.zxing.b.a(j * 12);
        k = ((ps.hacking.zxing.e.a.a.b)list.get(0)).c().a();
        l = 11;
        int i3;
        for (i1 = 0; l >= 0; i1 = i3)
        {
            if ((k & 1 << l) != 0)
            {
                a1.b(i1);
            }
            i3 = i1 + 1;
            l--;
        }

        j1 = 1;
        k1 = i1;
label0:
        for (; j1 < list.size(); j1++)
        {
            ps.hacking.zxing.e.a.a.b b1 = (ps.hacking.zxing.e.a.a.b)list.get(j1);
            int l1 = b1.b().a();
            for (int i2 = 11; i2 >= 0;)
            {
                if ((l1 & 1 << i2) != 0)
                {
                    a1.b(k1);
                }
                int l2 = k1 + 1;
                i2--;
                k1 = l2;
            }

            if (b1.c() == null)
            {
                continue;
            }
            int j2 = b1.c().a();
            int k2 = 11;
            do
            {
                if (k2 < 0)
                {
                    continue label0;
                }
                if ((j2 & 1 << k2) != 0)
                {
                    a1.b(k1);
                }
                k1++;
                k2--;
            } while (true);
        }

        return a1;
    }
}
