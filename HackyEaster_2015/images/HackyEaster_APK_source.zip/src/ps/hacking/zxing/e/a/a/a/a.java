// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.e.a.a.a;


// Referenced classes of package ps.hacking.zxing.e.a.a.a:
//            f

final class a extends f
{

    a(ps.hacking.zxing.b.a a1)
    {
        super(a1);
    }

    protected int a(int i)
    {
        return i;
    }

    protected void a(StringBuilder stringbuilder, int i)
    {
        stringbuilder.append("(3103)");
    }
}
