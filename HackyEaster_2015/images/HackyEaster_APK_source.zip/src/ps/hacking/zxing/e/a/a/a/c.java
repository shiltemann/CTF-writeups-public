// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.e.a.a.a;

import ps.hacking.zxing.b.a;
import ps.hacking.zxing.i;

// Referenced classes of package ps.hacking.zxing.e.a.a.a:
//            h, t, p

final class c extends h
{

    c(a a1)
    {
        super(a1);
    }

    public String a()
    {
        if (b().a() < 48)
        {
            throw i.a();
        } else
        {
            StringBuilder stringbuilder = new StringBuilder();
            b(stringbuilder, 8);
            int j = c().a(48, 2);
            stringbuilder.append("(392");
            stringbuilder.append(j);
            stringbuilder.append(')');
            stringbuilder.append(c().a(50, null).a());
            return stringbuilder.toString();
        }
    }
}
