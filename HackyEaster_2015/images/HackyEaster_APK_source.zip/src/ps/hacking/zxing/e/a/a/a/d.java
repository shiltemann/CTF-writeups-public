// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.e.a.a.a;

import ps.hacking.zxing.b.a;
import ps.hacking.zxing.i;

// Referenced classes of package ps.hacking.zxing.e.a.a.a:
//            h, t, p

final class d extends h
{

    d(a a1)
    {
        super(a1);
    }

    public String a()
    {
        if (b().a() < 48)
        {
            throw i.a();
        }
        StringBuilder stringbuilder = new StringBuilder();
        b(stringbuilder, 8);
        int j = c().a(48, 2);
        stringbuilder.append("(393");
        stringbuilder.append(j);
        stringbuilder.append(')');
        int k = c().a(50, 10);
        if (k / 100 == 0)
        {
            stringbuilder.append('0');
        }
        if (k / 10 == 0)
        {
            stringbuilder.append('0');
        }
        stringbuilder.append(k);
        stringbuilder.append(c().a(60, null).a());
        return stringbuilder.toString();
    }
}
