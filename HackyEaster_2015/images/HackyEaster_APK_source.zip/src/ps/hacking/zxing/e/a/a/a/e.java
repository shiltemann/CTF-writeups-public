// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.e.a.a.a;

import ps.hacking.zxing.b.a;
import ps.hacking.zxing.i;

// Referenced classes of package ps.hacking.zxing.e.a.a.a:
//            i, t

final class e extends ps.hacking.zxing.e.a.a.a.i
{

    private final String a;
    private final String b;

    e(a a1, String s, String s1)
    {
        super(a1);
        a = s1;
        b = s;
    }

    private void c(StringBuilder stringbuilder, int j)
    {
        int k = c().a(j, 16);
        if (k == 38400)
        {
            return;
        }
        stringbuilder.append('(');
        stringbuilder.append(a);
        stringbuilder.append(')');
        int l = k % 32;
        int i1 = k / 32;
        int j1 = 1 + i1 % 12;
        int k1 = i1 / 12;
        if (k1 / 10 == 0)
        {
            stringbuilder.append('0');
        }
        stringbuilder.append(k1);
        if (j1 / 10 == 0)
        {
            stringbuilder.append('0');
        }
        stringbuilder.append(j1);
        if (l / 10 == 0)
        {
            stringbuilder.append('0');
        }
        stringbuilder.append(l);
    }

    protected int a(int j)
    {
        return j % 0x186a0;
    }

    public String a()
    {
        if (b().a() != 84)
        {
            throw i.a();
        } else
        {
            StringBuilder stringbuilder = new StringBuilder();
            b(stringbuilder, 8);
            b(stringbuilder, 48, 20);
            c(stringbuilder, 68);
            return stringbuilder.toString();
        }
    }

    protected void a(StringBuilder stringbuilder, int j)
    {
        int k = j / 0x186a0;
        stringbuilder.append('(');
        stringbuilder.append(b);
        stringbuilder.append(k);
        stringbuilder.append(')');
    }
}
