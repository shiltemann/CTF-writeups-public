// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.e.a.a.a;

import ps.hacking.zxing.b.a;
import ps.hacking.zxing.i;

// Referenced classes of package ps.hacking.zxing.e.a.a.a:
//            i

abstract class f extends ps.hacking.zxing.e.a.a.a.i
{

    f(a a1)
    {
        super(a1);
    }

    public String a()
    {
        if (b().a() != 60)
        {
            throw i.a();
        } else
        {
            StringBuilder stringbuilder = new StringBuilder();
            b(stringbuilder, 5);
            b(stringbuilder, 45, 15);
            return stringbuilder.toString();
        }
    }
}
