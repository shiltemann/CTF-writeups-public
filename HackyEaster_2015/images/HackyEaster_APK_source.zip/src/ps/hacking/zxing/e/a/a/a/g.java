// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.e.a.a.a;

import ps.hacking.zxing.b.a;

// Referenced classes of package ps.hacking.zxing.e.a.a.a:
//            h, t

final class g extends h
{

    g(a a1)
    {
        super(a1);
    }

    public String a()
    {
        StringBuilder stringbuilder = new StringBuilder();
        stringbuilder.append("(01)");
        int i = stringbuilder.length();
        stringbuilder.append(c().a(4, 4));
        a(stringbuilder, 8, i);
        return c().a(stringbuilder, 48);
    }
}
