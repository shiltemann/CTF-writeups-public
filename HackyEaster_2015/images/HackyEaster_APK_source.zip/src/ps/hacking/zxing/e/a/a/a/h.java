// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.e.a.a.a;

import ps.hacking.zxing.b.a;

// Referenced classes of package ps.hacking.zxing.e.a.a.a:
//            j, t

abstract class h extends j
{

    h(a a1)
    {
        super(a1);
    }

    private static void a(StringBuilder stringbuilder, int i)
    {
        int k = 0;
        int l = 0;
        for (; k < 13; k++)
        {
            int j1 = -48 + stringbuilder.charAt(k + i);
            if ((k & 1) == 0)
            {
                j1 *= 3;
            }
            l += j1;
        }

        int i1 = 10 - l % 10;
        if (i1 == 10)
        {
            i1 = 0;
        }
        stringbuilder.append(i1);
    }

    protected final void a(StringBuilder stringbuilder, int i, int k)
    {
        for (int l = 0; l < 4; l++)
        {
            int i1 = c().a(i + l * 10, 10);
            if (i1 / 100 == 0)
            {
                stringbuilder.append('0');
            }
            if (i1 / 10 == 0)
            {
                stringbuilder.append('0');
            }
            stringbuilder.append(i1);
        }

        a(stringbuilder, k);
    }

    protected final void b(StringBuilder stringbuilder, int i)
    {
        stringbuilder.append("(01)");
        int k = stringbuilder.length();
        stringbuilder.append('9');
        a(stringbuilder, i, k);
    }
}
