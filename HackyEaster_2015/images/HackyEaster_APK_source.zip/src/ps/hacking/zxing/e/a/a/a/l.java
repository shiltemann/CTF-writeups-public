// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.e.a.a.a;


// Referenced classes of package ps.hacking.zxing.e.a.a.a:
//            p

final class l
{

    private final p a;
    private final boolean b;

    l(p p, boolean flag)
    {
        b = flag;
        a = p;
    }

    l(boolean flag)
    {
        this(null, flag);
    }

    p a()
    {
        return a;
    }

    boolean b()
    {
        return b;
    }
}
