// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.e.a.a.a;


// Referenced classes of package ps.hacking.zxing.e.a.a.a:
//            n

final class m
{

    private int a;
    private n b;

    m()
    {
        a = 0;
        b = n.a;
    }

    int a()
    {
        return a;
    }

    void a(int i)
    {
        a = i;
    }

    void b(int i)
    {
        a = i + a;
    }

    boolean b()
    {
        return b == n.b;
    }

    boolean c()
    {
        return b == n.c;
    }

    void d()
    {
        b = n.a;
    }

    void e()
    {
        b = n.b;
    }

    void f()
    {
        b = n.c;
    }
}
