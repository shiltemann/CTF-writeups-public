// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.e.a.a.a;


// Referenced classes of package ps.hacking.zxing.e.a.a.a:
//            r

final class q extends r
{

    private final int a;
    private final int b;

    q(int i, int j, int k)
    {
        super(i);
        a = j;
        b = k;
        if (a < 0 || a > 10)
        {
            throw new IllegalArgumentException((new StringBuilder()).append("Invalid firstDigit: ").append(j).toString());
        }
        if (b < 0 || b > 10)
        {
            throw new IllegalArgumentException((new StringBuilder()).append("Invalid secondDigit: ").append(k).toString());
        } else
        {
            return;
        }
    }

    int a()
    {
        return a;
    }

    int b()
    {
        return b;
    }

    boolean c()
    {
        return a == 10;
    }

    boolean d()
    {
        return b == 10;
    }
}
