// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.e.a.a;

import ps.hacking.zxing.e.a.c;

final class b
{

    private final boolean a;
    private final ps.hacking.zxing.e.a.b b;
    private final ps.hacking.zxing.e.a.b c;
    private final c d;

    b(ps.hacking.zxing.e.a.b b1, ps.hacking.zxing.e.a.b b2, c c1, boolean flag)
    {
        b = b1;
        c = b2;
        d = c1;
        a = flag;
    }

    boolean a()
    {
        return a;
    }

    ps.hacking.zxing.e.a.b b()
    {
        return b;
    }

    ps.hacking.zxing.e.a.b c()
    {
        return c;
    }

    c d()
    {
        return d;
    }

    public boolean e()
    {
        return c == null;
    }
}
