// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.e.a.a;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import ps.hacking.zxing.e.a.a;
import ps.hacking.zxing.e.a.a.a.j;
import ps.hacking.zxing.e.a.b;
import ps.hacking.zxing.e.a.f;
import ps.hacking.zxing.i;
import ps.hacking.zxing.m;
import ps.hacking.zxing.o;

// Referenced classes of package ps.hacking.zxing.e.a.a:
//            a, b

public final class c extends a
{

    private static final int a[] = {
        7, 5, 4, 3, 1
    };
    private static final int b[] = {
        4, 20, 52, 104, 204
    };
    private static final int c[] = {
        0, 348, 1388, 2948, 3988
    };
    private static final int d[][] = {
        {
            1, 8, 4, 1
        }, {
            3, 6, 4, 1
        }, {
            3, 4, 6, 1
        }, {
            3, 2, 8, 1
        }, {
            2, 6, 5, 1
        }, {
            2, 2, 9, 1
        }
    };
    private static final int e[][] = {
        {
            1, 3, 9, 27, 81, 32, 96, 77
        }, {
            20, 60, 180, 118, 143, 7, 21, 63
        }, {
            189, 145, 13, 39, 117, 140, 209, 205
        }, {
            193, 157, 49, 147, 19, 57, 171, 91
        }, {
            62, 186, 136, 197, 169, 85, 44, 132
        }, {
            185, 133, 188, 142, 4, 12, 36, 108
        }, {
            113, 128, 173, 97, 80, 29, 87, 50
        }, {
            150, 28, 84, 41, 123, 158, 52, 156
        }, {
            46, 138, 203, 187, 139, 206, 196, 166
        }, {
            76, 17, 51, 153, 37, 111, 122, 155
        }, {
            43, 129, 176, 106, 107, 110, 119, 146
        }, {
            16, 48, 144, 10, 30, 90, 59, 177
        }, {
            109, 116, 137, 200, 178, 112, 125, 164
        }, {
            70, 210, 208, 202, 184, 130, 179, 115
        }, {
            134, 191, 151, 31, 93, 68, 204, 190
        }, {
            148, 22, 66, 198, 172, 94, 71, 2
        }, {
            6, 18, 54, 162, 64, 192, 154, 40
        }, {
            120, 149, 25, 75, 14, 42, 126, 167
        }, {
            79, 26, 78, 23, 69, 207, 199, 175
        }, {
            103, 98, 83, 38, 114, 131, 182, 124
        }, {
            161, 61, 183, 127, 170, 88, 53, 159
        }, {
            55, 165, 73, 8, 24, 72, 5, 15
        }, {
            45, 135, 194, 160, 58, 174, 100, 89
        }
    };
    private static final int f[][] = {
        {
            0, 0
        }, {
            0, 1, 1
        }, {
            0, 2, 1, 3
        }, {
            0, 4, 1, 3, 2
        }, {
            0, 4, 1, 3, 3, 5
        }, {
            0, 4, 1, 3, 4, 5, 5
        }, {
            0, 0, 1, 1, 2, 2, 3, 3
        }, {
            0, 0, 1, 1, 2, 2, 3, 4, 4
        }, {
            0, 0, 1, 1, 2, 2, 3, 4, 5, 5
        }, {
            0, 0, 1, 1, 2, 3, 3, 4, 4, 5, 
            5
        }
    };
    private static final int g = f[-1 + f.length].length;
    private final List h = new ArrayList(11);
    private final int i[] = new int[2];
    private final int j[];

    public c()
    {
        j = new int[g];
    }

    private static int a(ps.hacking.zxing.b.a a1, int k)
    {
        if (a1.a(k))
        {
            return a1.c(a1.d(k));
        } else
        {
            return a1.d(a1.c(k));
        }
    }

    private ps.hacking.zxing.e.a.c a(ps.hacking.zxing.b.a a1, int k, boolean flag)
    {
        int l;
        int i1;
        int j1;
        int ai[];
        int l1;
        if (flag)
        {
            int i2;
            for (i2 = -1 + i[0]; i2 >= 0 && !a1.a(i2); i2--) { }
            l = i2 + 1;
            j1 = i[0] - l;
            i1 = i[1];
        } else
        {
            l = i[0];
            i1 = a1.d(1 + i[1]);
            j1 = i1 - i[1];
        }
        ai = b();
        System.arraycopy(ai, 0, ai, 1, -1 + ai.length);
        ai[0] = j1;
        try
        {
            l1 = a(ai, d);
        }
        catch (i k1)
        {
            return null;
        }
        return new ps.hacking.zxing.e.a.c(l1, new int[] {
            l, i1
        }, l, i1, k);
    }

    private static m a(List list)
    {
        String s = ps.hacking.zxing.e.a.a.a.j.a(ps.hacking.zxing.e.a.a.a.a(list)).a();
        o ao[] = ((ps.hacking.zxing.e.a.a.b)list.get(0)).d().c();
        o ao1[] = ((ps.hacking.zxing.e.a.a.b)list.get(-1 + list.size())).d().c();
        o ao2[] = new o[4];
        ao2[0] = ao[0];
        ao2[1] = ao[1];
        ao2[2] = ao1[0];
        ao2[3] = ao1[1];
        return new m(s, null, ao2, ps.hacking.zxing.a.n);
    }

    private void a(int k)
    {
        int l = 1;
        int i1 = a(f());
        int j1 = a(g());
        int k1 = (i1 + j1) - k;
        int l1;
        int i2;
        int j2;
        int k2;
        int l2;
        int i3;
        if ((i1 & 1) == l)
        {
            l1 = l;
        } else
        {
            l1 = 0;
        }
        if ((j1 & 1) == 0)
        {
            i2 = l;
        } else
        {
            i2 = 0;
        }
        int j3;
        int k3;
        if (i1 > 13)
        {
            j2 = l;
            k2 = 0;
        } else
        if (i1 < 4)
        {
            k2 = l;
            j2 = 0;
        } else
        {
            j2 = 0;
            k2 = 0;
        }
        if (j1 > 13)
        {
            i3 = 0;
            l2 = l;
        } else
        if (j1 < 4)
        {
            i3 = l;
            l2 = 0;
        } else
        {
            l2 = 0;
            i3 = 0;
        }
        if (k1 == l)
        {
            if (l1 != 0)
            {
                if (i2 != 0)
                {
                    throw ps.hacking.zxing.i.a();
                }
                k3 = k2;
                int j4 = l;
                l = i3;
                j3 = j4;
            } else
            {
                if (i2 == 0)
                {
                    throw ps.hacking.zxing.i.a();
                }
                l2 = l;
                l = i3;
                j3 = j2;
                k3 = k2;
            }
            break MISSING_BLOCK_LABEL_147;
        }
        if (k1 == -1)
        {
            if (l1 != 0)
            {
                if (i2 != 0)
                {
                    throw ps.hacking.zxing.i.a();
                }
                int i4 = i3;
                j3 = j2;
                k3 = l;
                l = i4;
            } else
            {
                if (i2 == 0)
                {
                    throw ps.hacking.zxing.i.a();
                }
                j3 = j2;
                k3 = k2;
            }
            continue; /* Loop/switch isn't completed */
        }
        if (k1 == 0)
        {
            if (l1 != 0)
            {
                if (i2 == 0)
                {
                    throw ps.hacking.zxing.i.a();
                }
                if (i1 < j1)
                {
                    l2 = l;
                    int l3 = i3;
                    j3 = j2;
                    k3 = l;
                    l = l3;
                } else
                {
                    j3 = l;
                    k3 = k2;
                }
                continue; /* Loop/switch isn't completed */
            }
            if (i2 != 0)
            {
                throw ps.hacking.zxing.i.a();
            }
        } else
        {
            throw ps.hacking.zxing.i.a();
        }
        l = i3;
        j3 = j2;
        k3 = k2;
          goto _L1
_L3:
        if (k3 != 0)
        {
            if (j3 != 0)
            {
                throw ps.hacking.zxing.i.a();
            }
            a(f(), d());
        }
        if (j3 != 0)
        {
            b(f(), d());
        }
        if (l != 0)
        {
            if (l2 != 0)
            {
                throw ps.hacking.zxing.i.a();
            }
            a(g(), d());
        }
        if (l2 != 0)
        {
            b(g(), e());
        }
        return;
_L1:
        if (true) goto _L3; else goto _L2
_L2:
    }

    private boolean a(List list, ps.hacking.zxing.e.a.c c1)
    {
        int k;
        int ai[][];
        int i1;
        int j1;
        k = 1 + list.size();
        if (k > j.length)
        {
            throw ps.hacking.zxing.i.a();
        }
        for (int l = 0; l < list.size(); l++)
        {
            j[l] = ((ps.hacking.zxing.e.a.a.b)list.get(l)).d().a();
        }

        j[k - 1] = c1.a();
        ai = f;
        i1 = ai.length;
        j1 = 0;
_L6:
        if (j1 >= i1) goto _L2; else goto _L1
_L1:
        int ai1[];
        int k1;
        ai1 = ai[j1];
        if (ai1.length < k)
        {
            continue; /* Loop/switch isn't completed */
        }
        k1 = 0;
_L5:
        if (k1 >= k)
        {
            break MISSING_BLOCK_LABEL_180;
        }
        if (j[k1] == ai1[k1]) goto _L4; else goto _L3
_L3:
        boolean flag = false;
_L7:
        if (!flag)
        {
            continue; /* Loop/switch isn't completed */
        }
        int l1 = ai1.length;
        boolean flag1 = false;
        if (k == l1)
        {
            flag1 = true;
        }
        return flag1;
_L4:
        k1++;
          goto _L5
        j1++;
          goto _L6
_L2:
        throw ps.hacking.zxing.i.a();
        flag = true;
          goto _L7
    }

    private static boolean a(ps.hacking.zxing.e.a.c c1, boolean flag, boolean flag1)
    {
        return c1.a() != 0 || !flag || !flag1;
    }

    private void b(ps.hacking.zxing.b.a a1, List list, int k)
    {
        int ai[] = b();
        ai[0] = 0;
        ai[1] = 0;
        ai[2] = 0;
        ai[3] = 0;
        int l = a1.a();
        boolean flag;
        boolean flag1;
        int i1;
        if (k < 0)
        {
            if (list.isEmpty())
            {
                k = 0;
            } else
            {
                k = ((ps.hacking.zxing.e.a.a.b)list.get(-1 + list.size())).d().b()[1];
            }
        }
        if (list.size() % 2 != 0)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        flag1 = false;
        i1 = k;
        do
        {
label0:
            {
label1:
                {
                    int j1;
                    int l1;
                    boolean flag2;
                    int i2;
                    if (i1 < l)
                    {
                        int k1;
                        if (!a1.a(i1))
                        {
                            flag1 = true;
                        } else
                        {
                            flag1 = false;
                        }
                        if (flag1)
                        {
                            break label1;
                        }
                    }
                    j1 = i1;
                    k1 = i1;
                    l1 = 0;
                    flag2 = flag1;
                    i2 = k1;
                    while (j1 < l) 
                    {
                        if (flag2 ^ a1.a(j1))
                        {
                            ai[l1] = 1 + ai[l1];
                        } else
                        {
                            if (l1 == 3)
                            {
                                if (flag)
                                {
                                    c(ai);
                                }
                                if (b(ai))
                                {
                                    i[0] = i2;
                                    i[1] = j1;
                                    return;
                                }
                                if (flag)
                                {
                                    c(ai);
                                }
                                i2 += ai[0] + ai[1];
                                ai[0] = ai[2];
                                ai[1] = ai[3];
                                ai[2] = 0;
                                ai[3] = 0;
                                l1--;
                            } else
                            {
                                l1++;
                            }
                            ai[l1] = 1;
                            if (!flag2)
                            {
                                flag2 = true;
                            } else
                            {
                                flag2 = false;
                            }
                        }
                        j1++;
                    }
                    break label0;
                }
                i1++;
                continue;
            }
            throw ps.hacking.zxing.i.a();
        } while (true);
    }

    private static void c(int ai[])
    {
        int k = ai.length;
        for (int l = 0; l < k / 2; l++)
        {
            int i1 = ai[l];
            ai[l] = ai[-1 + (k - l)];
            ai[-1 + (k - l)] = i1;
        }

    }

    private boolean h()
    {
        ps.hacking.zxing.e.a.a.b b1 = (ps.hacking.zxing.e.a.a.b)h.get(0);
        b b2 = b1.b();
        int k = b1.c().b();
        int l = 2;
        int i1 = k;
        for (int j1 = 1; j1 < h.size(); j1++)
        {
            ps.hacking.zxing.e.a.a.b b3 = (ps.hacking.zxing.e.a.a.b)h.get(j1);
            i1 += b3.b().b();
            l++;
            b b4 = b3.c();
            if (b4 != null)
            {
                i1 += b4.b();
                l++;
            }
        }

        return i1 % 211 + 211 * (l - 4) == b2.a();
    }

    List a(int k, ps.hacking.zxing.b.a a1)
    {
        ps.hacking.zxing.e.a.a.b b1;
        do
        {
            do
            {
                b1 = a(a1, h, k);
                h.add(b1);
            } while (!b1.a());
            if (h())
            {
                return h;
            }
        } while (!b1.e());
        throw ps.hacking.zxing.i.a();
    }

    ps.hacking.zxing.e.a.a.b a(ps.hacking.zxing.b.a a1, List list, int k)
    {
        boolean flag2;
        b b2;
        boolean flag;
        int l;
        boolean flag1;
        if (list.size() % 2 == 0)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        l = -1;
        flag1 = true;
        do
        {
            b(a1, list, l);
            ps.hacking.zxing.e.a.c c1 = a(a1, k, flag);
            b b1;
            b b3;
            if (c1 == null)
            {
                l = a(a1, i[0]);
            } else
            {
                flag1 = false;
            }
        } while (flag1);
        flag2 = a(list, c1);
        b1 = a(a1, c1, flag, true);
        b3 = a(a1, c1, flag, false);
        b2 = b3;
_L2:
        return new ps.hacking.zxing.e.a.a.b(b1, b2, c1, flag2);
        i i1;
        i1;
        if (flag2)
        {
            b2 = null;
        } else
        {
            throw i1;
        }
        if (true) goto _L2; else goto _L1
_L1:
    }

    b a(ps.hacking.zxing.b.a a1, ps.hacking.zxing.e.a.c c1, boolean flag, boolean flag1)
    {
        int ai[] = c();
        ai[0] = 0;
        ai[1] = 0;
        ai[2] = 0;
        ai[3] = 0;
        ai[4] = 0;
        ai[5] = 0;
        ai[6] = 0;
        ai[7] = 0;
        float f1;
        int ai1[];
        int ai2[];
        float af[];
        float af1[];
        int j1;
        if (flag1)
        {
            b(a1, c1.b()[0], ai);
        } else
        {
            a(a1, 1 + c1.b()[1], ai);
            int k = 0;
            int l = -1 + ai.length;
            while (k < l) 
            {
                int i1 = ai[k];
                ai[k] = ai[l];
                ai[l] = i1;
                k++;
                l--;
            }
        }
        f1 = (float)a(ai) / (float)17;
        ai1 = f();
        ai2 = g();
        af = d();
        af1 = e();
        j1 = 0;
        do
        {
            if (j1 >= ai.length)
            {
                break;
            }
            float f2 = (1.0F * (float)ai[j1]) / f1;
            int l6 = (int)(0.5F + f2);
            int i7;
            if (l6 < 1)
            {
                l6 = 1;
            } else
            if (l6 > 8)
            {
                l6 = 8;
            }
            i7 = j1 >> 1;
            if ((j1 & 1) == 0)
            {
                ai1[i7] = l6;
                af[i7] = f2 - (float)l6;
            } else
            {
                ai2[i7] = l6;
                af1[i7] = f2 - (float)l6;
            }
            j1++;
        } while (true);
        a(17);
        int k1 = 4 * c1.a();
        int l1;
        int i2;
        int j2;
        int k2;
        int l2;
        int i3;
        int j3;
        int k3;
        if (flag)
        {
            l1 = 0;
        } else
        {
            l1 = 2;
        }
        i2 = k1 + l1;
        if (flag1)
        {
            j2 = 0;
        } else
        {
            j2 = 1;
        }
        k2 = -1 + (j2 + i2);
        l2 = -1 + ai1.length;
        i3 = 0;
        j3 = l2;
        k3 = 0;
        while (j3 >= 0) 
        {
            if (a(c1, flag, flag1))
            {
                k3 += e[k2][j3 * 2] * ai1[j3];
            }
            int k6 = i3 + ai1[j3];
            j3--;
            i3 = k6;
        }
        int l3 = -1 + ai2.length;
        int i4 = 0;
        int j4 = 0;
        for (int k4 = l3; k4 >= 0; k4--)
        {
            if (a(c1, flag, flag1))
            {
                i4 += e[k2][1 + k4 * 2] * ai2[k4];
            }
            j4 += ai2[k4];
        }

        int l4 = k3 + i4;
        if ((i3 & 1) != 0 || i3 > 13 || i3 < 4)
        {
            throw ps.hacking.zxing.i.a();
        } else
        {
            int i5 = (13 - i3) / 2;
            int j5 = a[i5];
            int k5 = 9 - j5;
            int l5 = ps.hacking.zxing.e.a.f.a(ai1, j5, true);
            int i6 = ps.hacking.zxing.e.a.f.a(ai2, k5, false);
            int j6 = b[i5];
            return new b(c[i5] + (i6 + l5 * j6), l4);
        }
    }

    public m a(int k, ps.hacking.zxing.b.a a1, Map map)
    {
        a();
        a(k, a1);
        return a(h);
    }

    public void a()
    {
        h.clear();
    }

}
