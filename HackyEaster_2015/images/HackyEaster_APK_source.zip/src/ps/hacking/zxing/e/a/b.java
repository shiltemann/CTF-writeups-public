// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.e.a;


public class b
{

    private final int a;
    private final int b;

    public b(int i, int j)
    {
        a = i;
        b = j;
    }

    public final int a()
    {
        return a;
    }

    public final int b()
    {
        return b;
    }
}
