// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.e.a;

import ps.hacking.zxing.o;

public final class c
{

    private final int a;
    private final int b[];
    private final o c[];

    public c(int i, int ai[], int j, int k, int l)
    {
        a = i;
        b = ai;
        o ao[] = new o[2];
        ao[0] = new o(j, l);
        ao[1] = new o(k, l);
        c = ao;
    }

    public int a()
    {
        return a;
    }

    public int[] b()
    {
        return b;
    }

    public o[] c()
    {
        return c;
    }
}
