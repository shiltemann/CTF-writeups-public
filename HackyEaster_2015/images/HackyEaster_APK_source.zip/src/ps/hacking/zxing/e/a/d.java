// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.e.a;


// Referenced classes of package ps.hacking.zxing.e.a:
//            b, c

final class d extends b
{

    private final c a;
    private int b;

    d(int i, int j, c c1)
    {
        super(i, j);
        a = c1;
    }

    c c()
    {
        return a;
    }

    int d()
    {
        return b;
    }

    void e()
    {
        b = 1 + b;
    }
}
