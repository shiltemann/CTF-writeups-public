// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.e.a;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import ps.hacking.zxing.b.a;
import ps.hacking.zxing.i;
import ps.hacking.zxing.m;
import ps.hacking.zxing.o;
import ps.hacking.zxing.p;

// Referenced classes of package ps.hacking.zxing.e.a:
//            a, c, f, b, 
//            d

public final class e extends ps.hacking.zxing.e.a.a
{

    private static final int a[] = {
        1, 10, 34, 70, 126
    };
    private static final int b[] = {
        4, 20, 48, 81
    };
    private static final int c[] = {
        0, 161, 961, 2015, 2715
    };
    private static final int d[] = {
        0, 336, 1036, 1516
    };
    private static final int e[] = {
        8, 6, 4, 3, 1
    };
    private static final int f[] = {
        2, 4, 6, 8
    };
    private static final int g[][] = {
        {
            3, 8, 2, 1
        }, {
            3, 5, 5, 1
        }, {
            3, 3, 7, 1
        }, {
            3, 1, 9, 1
        }, {
            2, 7, 4, 1
        }, {
            2, 5, 6, 1
        }, {
            2, 3, 8, 1
        }, {
            1, 5, 7, 1
        }, {
            1, 3, 9, 1
        }
    };
    private final List h = new ArrayList();
    private final List i = new ArrayList();

    public e()
    {
    }

    private b a(a a1, c c1, boolean flag)
    {
        int ai[] = c();
        ai[0] = 0;
        ai[1] = 0;
        ai[2] = 0;
        ai[3] = 0;
        ai[4] = 0;
        ai[5] = 0;
        ai[6] = 0;
        ai[7] = 0;
        int i1;
        float f1;
        int ai1[];
        int ai2[];
        float af[];
        float af1[];
        int j1;
        if (flag)
        {
            b(a1, c1.b()[0], ai);
        } else
        {
            a(a1, 1 + c1.b()[1], ai);
            int j = 0;
            int k = -1 + ai.length;
            while (j < k) 
            {
                int l = ai[j];
                ai[j] = ai[k];
                ai[k] = l;
                j++;
                k--;
            }
        }
        if (flag)
        {
            i1 = 16;
        } else
        {
            i1 = 15;
        }
        f1 = (float)a(ai) / (float)i1;
        ai1 = f();
        ai2 = g();
        af = d();
        af1 = e();
        j1 = 0;
        do
        {
            if (j1 >= ai.length)
            {
                break;
            }
            float f2 = (float)ai[j1] / f1;
            int l6 = (int)(0.5F + f2);
            int i7;
            if (l6 < 1)
            {
                l6 = 1;
            } else
            if (l6 > 8)
            {
                l6 = 8;
            }
            i7 = j1 >> 1;
            if ((j1 & 1) == 0)
            {
                ai1[i7] = l6;
                af[i7] = f2 - (float)l6;
            } else
            {
                ai2[i7] = l6;
                af1[i7] = f2 - (float)l6;
            }
            j1++;
        } while (true);
        a(flag, i1);
        int k1 = -1 + ai1.length;
        int l1 = 0;
        int i2;
        int k6;
        for (i2 = 0; k1 >= 0; i2 = k6)
        {
            int j6 = l1 * 9 + ai1[k1];
            k6 = i2 + ai1[k1];
            k1--;
            l1 = j6;
        }

        int j2 = 0;
        int k2 = 0;
        for (int l2 = -1 + ai2.length; l2 >= 0; l2--)
        {
            j2 = j2 * 9 + ai2[l2];
            k2 += ai2[l2];
        }

        int i3 = l1 + j2 * 3;
        if (flag)
        {
            if ((i2 & 1) != 0 || i2 > 12 || i2 < 4)
            {
                throw ps.hacking.zxing.i.a();
            } else
            {
                int l4 = (12 - i2) / 2;
                int i5 = e[l4];
                int j5 = 9 - i5;
                int k5 = ps.hacking.zxing.e.a.f.a(ai1, i5, false);
                int l5 = ps.hacking.zxing.e.a.f.a(ai2, j5, true);
                int i6 = a[l4];
                return new b(c[l4] + (l5 + k5 * i6), i3);
            }
        }
        if ((k2 & 1) != 0 || k2 > 10 || k2 < 4)
        {
            throw ps.hacking.zxing.i.a();
        } else
        {
            int j3 = (10 - k2) / 2;
            int k3 = f[j3];
            int l3 = 9 - k3;
            int i4 = ps.hacking.zxing.e.a.f.a(ai1, k3, true);
            int j4 = ps.hacking.zxing.e.a.f.a(ai2, l3, false);
            int k4 = b[j3];
            return new b(d[j3] + (i4 + j4 * k4), i3);
        }
    }

    private c a(a a1, int j, boolean flag, int ai[])
    {
        boolean flag1 = a1.a(ai[0]);
        int k;
        for (k = -1 + ai[0]; k >= 0 && flag1 ^ a1.a(k); k--) { }
        int l = k + 1;
        int i1 = ai[0] - l;
        int ai1[] = b();
        System.arraycopy(ai1, 0, ai1, 1, -1 + ai1.length);
        ai1[0] = i1;
        int j1 = a(ai1, g);
        int k1 = ai[1];
        int l1;
        int ai2[];
        if (flag)
        {
            l1 = (-1 + a1.a()) - l;
            k1 = (-1 + a1.a()) - k1;
        } else
        {
            l1 = l;
        }
        ai2 = new int[2];
        ai2[0] = l;
        ai2[1] = ai[1];
        return new c(j1, ai2, l1, k1, j);
    }

    private d a(a a1, boolean flag, int j, Map map)
    {
        int ai[];
        c c1;
        p p1;
        p p2;
        float f1;
        try
        {
            ai = a(a1, 0, flag);
            c1 = a(a1, j, flag, ai);
        }
        catch (i k)
        {
            return null;
        }
        if (map != null) goto _L2; else goto _L1
_L1:
        p2 = null;
_L4:
        if (p2 == null)
        {
            break MISSING_BLOCK_LABEL_81;
        }
        f1 = (float)(ai[0] + ai[1]) / 2.0F;
        if (!flag)
        {
            break MISSING_BLOCK_LABEL_63;
        }
        f1 = (float)(-1 + a1.a()) - f1;
        p2.a(new o(f1, j));
        b b1 = a(a1, c1, true);
        b b2 = a(a1, c1, false);
        return new d(1597 * b1.a() + b2.a(), b1.b() + 4 * b2.b(), c1);
_L2:
        p1 = (p)map.get(ps.hacking.zxing.e.h);
        p2 = p1;
        if (true) goto _L4; else goto _L3
_L3:
    }

    private static m a(d d1, d d2)
    {
        String s = String.valueOf(0x453af5L * (long)d1.a() + (long)d2.a());
        StringBuilder stringbuilder = new StringBuilder(14);
        for (int j = 13 - s.length(); j > 0; j--)
        {
            stringbuilder.append('0');
        }

        stringbuilder.append(s);
        int k = 0;
        int l = 0;
        for (; k < 13; k++)
        {
            int j1 = -48 + stringbuilder.charAt(k);
            if ((k & 1) == 0)
            {
                j1 *= 3;
            }
            l += j1;
        }

        int i1 = 10 - l % 10;
        if (i1 == 10)
        {
            i1 = 0;
        }
        stringbuilder.append(i1);
        o ao[] = d1.c().c();
        o ao1[] = d2.c().c();
        String s1 = String.valueOf(stringbuilder.toString());
        o ao2[] = new o[4];
        ao2[0] = ao[0];
        ao2[1] = ao[1];
        ao2[2] = ao1[0];
        ao2[3] = ao1[1];
        return new m(s1, null, ao2, ps.hacking.zxing.a.m);
    }

    private static void a(Collection collection, d d1)
    {
        if (d1 != null) goto _L2; else goto _L1
_L1:
        return;
_L2:
        boolean flag;
        Iterator iterator = collection.iterator();
        d d2;
        do
        {
            if (!iterator.hasNext())
            {
                break; /* Loop/switch isn't completed */
            }
            d2 = (d)iterator.next();
        } while (d2.a() != d1.a());
        d2.e();
        flag = true;
_L4:
        if (!flag)
        {
            collection.add(d1);
            return;
        }
        if (true) goto _L1; else goto _L3
_L3:
        flag = false;
          goto _L4
        if (true) goto _L1; else goto _L5
_L5:
    }

    private void a(boolean flag, int j)
    {
        int k;
        int l;
        int i1;
        int j1;
        int i2;
        int j2;
        int k2;
        int l2;
        int i3;
        int j3;
        k = 1;
        l = a(f());
        i1 = a(g());
        j1 = (l + i1) - j;
        int k1 = l & 1;
        int l1;
        if (flag)
        {
            l1 = k;
        } else
        {
            l1 = 0;
        }
        if (k1 == l1)
        {
            i2 = k;
        } else
        {
            i2 = 0;
        }
        if ((i1 & 1) == k)
        {
            j2 = k;
        } else
        {
            j2 = 0;
        }
        if (!flag) goto _L2; else goto _L1
_L1:
        if (l > 12)
        {
            k2 = k;
            l2 = 0;
        } else
        if (l < 4)
        {
            l2 = k;
            k2 = 0;
        } else
        {
            k2 = 0;
            l2 = 0;
        }
        if (i1 <= 12) goto _L4; else goto _L3
_L3:
        j3 = 0;
        i3 = k;
_L7:
        if (j1 == k)
        {
            if (i2 != 0)
            {
                if (j2 != 0)
                {
                    throw ps.hacking.zxing.i.a();
                }
                int l3 = l2;
                int k4 = k;
                k = j3;
                int k3 = k4;
                do
                {
                    if (l3 != 0)
                    {
                        int i4;
                        int j4;
                        if (k3 != 0)
                        {
                            throw ps.hacking.zxing.i.a();
                        }
                        a(f(), d());
                    }
                    if (k3 != 0)
                    {
                        b(f(), d());
                    }
                    if (k != 0)
                    {
                        if (i3 != 0)
                        {
                            throw ps.hacking.zxing.i.a();
                        }
                        a(g(), d());
                    }
                    if (i3 != 0)
                    {
                        b(g(), e());
                    }
                    return;
                } while (true);
            } else
            {
                if (j2 == 0)
                {
                    throw ps.hacking.zxing.i.a();
                }
                i3 = k;
                k = j3;
                k3 = k2;
                l3 = l2;
                continue;
            }
        } else
        {
            if (j1 == -1)
            {
                if (i2 != 0)
                {
                    if (j2 != 0)
                    {
                        throw ps.hacking.zxing.i.a();
                    }
                    j4 = j3;
                    k3 = k2;
                    l3 = k;
                    k = j4;
                } else
                {
                    if (j2 == 0)
                    {
                        throw ps.hacking.zxing.i.a();
                    }
                    k3 = k2;
                    l3 = l2;
                }
                continue;
            }
            if (j1 == 0)
            {
                if (i2 != 0)
                {
                    if (j2 == 0)
                    {
                        throw ps.hacking.zxing.i.a();
                    }
                    if (l < i1)
                    {
                        i3 = k;
                        i4 = j3;
                        k3 = k2;
                        l3 = k;
                        k = i4;
                    } else
                    {
                        k3 = k;
                        l3 = l2;
                    }
                    continue;
                }
                if (j2 != 0)
                {
                    throw ps.hacking.zxing.i.a();
                }
            } else
            {
                throw ps.hacking.zxing.i.a();
            }
            k = j3;
            k3 = k2;
            l3 = l2;
            continue;
        }
_L4:
        if (i1 < 4)
        {
            j3 = k;
            i3 = 0;
            continue; /* Loop/switch isn't completed */
        }
          goto _L5
_L2:
        if (l > 11)
        {
            k2 = k;
            l2 = 0;
        } else
        if (l < 5)
        {
            l2 = k;
            k2 = 0;
        } else
        {
            k2 = 0;
            l2 = 0;
        }
        if (i1 > 10)
        {
            i3 = k;
            j3 = 0;
            continue; /* Loop/switch isn't completed */
        }
        if (i1 < 4)
        {
            j3 = k;
            i3 = 0;
            continue; /* Loop/switch isn't completed */
        }
_L5:
        i3 = 0;
        j3 = 0;
        if (true) goto _L7; else goto _L6
_L6:
    }

    private int[] a(a a1, int j, boolean flag)
    {
        int ai[] = b();
        ai[0] = 0;
        ai[1] = 0;
        ai[2] = 0;
        ai[3] = 0;
        int k = a1.a();
        boolean flag1 = false;
        int l = j;
        do
        {
label0:
            {
label1:
                {
                    int i1;
                    boolean flag2;
                    int j1;
                    int k1;
                    if (l < k)
                    {
                        if (!a1.a(l))
                        {
                            flag1 = true;
                        } else
                        {
                            flag1 = false;
                        }
                        if (flag != flag1)
                        {
                            break label1;
                        }
                    }
                    i1 = l;
                    flag2 = flag1;
                    j1 = l;
                    k1 = 0;
                    while (i1 < k) 
                    {
                        if (flag2 ^ a1.a(i1))
                        {
                            ai[k1] = 1 + ai[k1];
                        } else
                        {
                            if (k1 == 3)
                            {
                                if (b(ai))
                                {
                                    return (new int[] {
                                        j1, i1
                                    });
                                }
                                j1 += ai[0] + ai[1];
                                ai[0] = ai[2];
                                ai[1] = ai[3];
                                ai[2] = 0;
                                ai[3] = 0;
                                k1--;
                            } else
                            {
                                k1++;
                            }
                            ai[k1] = 1;
                            if (!flag2)
                            {
                                flag2 = true;
                            } else
                            {
                                flag2 = false;
                            }
                        }
                        i1++;
                    }
                    break label0;
                }
                l++;
                continue;
            }
            throw ps.hacking.zxing.i.a();
        } while (true);
    }

    private static boolean b(d d1, d d2)
    {
        int j = d1.c().a();
        int k = d2.c().a();
        if ((j != 0 || k != 8) && j == 8)
        {
            if (k != 0);
        }
        int l = (d1.b() + 16 * d2.b()) % 79;
        int i1 = 9 * d1.c().a() + d2.c().a();
        if (i1 > 72)
        {
            i1--;
        }
        if (i1 > 8)
        {
            i1--;
        }
        return l == i1;
    }

    public m a(int j, a a1, Map map)
    {
        d d1 = a(a1, false, j, map);
        a(((Collection) (h)), d1);
        a1.c();
        d d2 = a(a1, true, j, map);
        a(((Collection) (i)), d2);
        a1.c();
        Iterator iterator = h.iterator();
        d d3;
        d d4;
label0:
        do
        {
            if (iterator.hasNext())
            {
                d3 = (d)iterator.next();
                if (d3.d() <= 1)
                {
                    continue;
                }
                Iterator iterator1 = i.iterator();
                do
                {
                    if (!iterator1.hasNext())
                    {
                        continue label0;
                    }
                    d4 = (d)iterator1.next();
                } while (d4.d() <= 1 || !b(d3, d4));
                break;
            } else
            {
                throw ps.hacking.zxing.i.a();
            }
        } while (true);
        return a(d3, d4);
    }

    public void a()
    {
        h.clear();
        i.clear();
    }

}
