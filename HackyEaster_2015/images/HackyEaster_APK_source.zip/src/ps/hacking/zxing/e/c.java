// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.e;

import java.util.Map;
import ps.hacking.zxing.b.a;
import ps.hacking.zxing.d;
import ps.hacking.zxing.f;
import ps.hacking.zxing.i;
import ps.hacking.zxing.m;
import ps.hacking.zxing.o;

// Referenced classes of package ps.hacking.zxing.e:
//            k

public final class c extends k
{

    static final int a[] = {
        52, 289, 97, 352, 49, 304, 112, 37, 292, 100, 
        265, 73, 328, 25, 280, 88, 13, 268, 76, 28, 
        259, 67, 322, 19, 274, 82, 7, 262, 70, 22, 
        385, 193, 448, 145, 400, 208, 133, 388, 196, 148, 
        168, 162, 138, 42
    };
    private static final char b[] = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ-. *$/+%".toCharArray();
    private static final int c = a[39];
    private final boolean d;
    private final boolean e;

    public c()
    {
        d = false;
        e = false;
    }

    public c(boolean flag)
    {
        d = flag;
        e = false;
    }

    private static char a(int j)
    {
        for (int l = 0; l < a.length; l++)
        {
            if (a[l] == j)
            {
                return b[l];
            }
        }

        throw i.a();
    }

    private static int a(int ai[])
    {
        int j = ai.length;
        int l = 0;
        do
        {
            int i1 = 0x7fffffff;
            int j1 = ai.length;
            for (int k1 = 0; k1 < j1; k1++)
            {
                int k3 = ai[k1];
                if (k3 < i1 && k3 > l)
                {
                    i1 = k3;
                }
            }

            int l1 = 0;
            int i2 = 0;
            int j2 = 0;
            int k2 = 0;
            for (; i2 < j; i2++)
            {
                int j3 = ai[i2];
                if (ai[i2] > i1)
                {
                    j2 |= 1 << j - 1 - i2;
                    l1++;
                    k2 += j3;
                }
            }

            int l2 = 0;
            if (l1 == 3)
            {
                do
                {
label0:
                    {
                        if (l2 < j && l1 > 0)
                        {
                            int i3 = ai[l2];
                            if (ai[l2] <= i1)
                            {
                                break label0;
                            }
                            l1--;
                            if (i3 << 1 < k2)
                            {
                                break label0;
                            }
                            j2 = -1;
                        }
                        return j2;
                    }
                    l2++;
                } while (true);
            }
            if (l1 <= 3)
            {
                return -1;
            }
            l = i1;
        } while (true);
    }

    private static String a(CharSequence charsequence)
    {
        int j;
        StringBuilder stringbuilder;
        int l;
        j = charsequence.length();
        stringbuilder = new StringBuilder(j);
        l = 0;
_L9:
        char c1;
        char c2;
        if (l >= j)
        {
            break MISSING_BLOCK_LABEL_307;
        }
        c1 = charsequence.charAt(l);
        if (c1 != '+' && c1 != '$' && c1 != '%' && c1 != '/')
        {
            break MISSING_BLOCK_LABEL_294;
        }
        c2 = charsequence.charAt(l + 1);
        c1;
        JVM INSTR lookupswitch 4: default 116
    //                   36: 168
    //                   37: 197
    //                   43: 139
    //                   47: 251;
           goto _L1 _L2 _L3 _L4 _L5
_L1:
        char c3 = '\0';
_L6:
        int i1;
        stringbuilder.append(c3);
        i1 = l + 1;
_L7:
        l = i1 + 1;
        continue; /* Loop/switch isn't completed */
_L4:
        if (c2 >= 'A' && c2 <= 'Z')
        {
            c3 = (char)(c2 + 32);
        } else
        {
            throw f.a();
        }
          goto _L6
_L2:
        if (c2 >= 'A' && c2 <= 'Z')
        {
            c3 = (char)(c2 - 64);
        } else
        {
            throw f.a();
        }
          goto _L6
_L3:
        if (c2 >= 'A' && c2 <= 'E')
        {
            c3 = (char)(c2 - 38);
        } else
        if (c2 >= 'F' && c2 <= 'W')
        {
            c3 = (char)(c2 - 11);
        } else
        {
            throw f.a();
        }
          goto _L6
_L5:
        if (c2 >= 'A' && c2 <= 'O')
        {
            c3 = (char)(c2 - 32);
        } else
        if (c2 == 'Z')
        {
            c3 = ':';
        } else
        {
            throw f.a();
        }
          goto _L6
        stringbuilder.append(c1);
        i1 = l;
          goto _L7
        return stringbuilder.toString();
        if (true) goto _L9; else goto _L8
_L8:
    }

    private static int[] a(a a1, int ai[])
    {
        int j = a1.a();
        int l = a1.c(0);
        int i1 = ai.length;
        int j1 = l;
        boolean flag = false;
        int k1 = 0;
        while (j1 < j) 
        {
            if (flag ^ a1.a(j1))
            {
                ai[k1] = 1 + ai[k1];
            } else
            {
                if (k1 == i1 - 1)
                {
                    if (a(ai) == c && a1.a(Math.max(0, l - (j1 - l >> 1)), l, false))
                    {
                        return (new int[] {
                            l, j1
                        });
                    }
                    l += ai[0] + ai[1];
                    System.arraycopy(ai, 2, ai, 0, i1 - 2);
                    ai[i1 - 2] = 0;
                    ai[i1 - 1] = 0;
                    k1--;
                } else
                {
                    k1++;
                }
                ai[k1] = 1;
                if (!flag)
                {
                    flag = true;
                } else
                {
                    flag = false;
                }
            }
            j1++;
        }
        throw i.a();
    }

    public m a(int j, a a1, Map map)
    {
        int ai[] = new int[9];
        int ai1[] = a(a1, ai);
        int l = a1.c(ai1[1]);
        int i1 = a1.a();
        StringBuilder stringbuilder = new StringBuilder(20);
        do
        {
            a(a1, l, ai);
            int j1 = a(ai);
            if (j1 < 0)
            {
                throw i.a();
            }
            char c1 = a(j1);
            stringbuilder.append(c1);
            int k1 = ai.length;
            int l1 = 0;
            int i2 = l;
            for (; l1 < k1; l1++)
            {
                i2 += ai[l1];
            }

            int j2 = a1.c(i2);
            if (c1 == '*')
            {
                stringbuilder.setLength(-1 + stringbuilder.length());
                int k2 = 0;
                int l2 = ai.length;
                for (int i3 = 0; i3 < l2; i3++)
                {
                    k2 += ai[i3];
                }

                int j3 = j2 - l - k2;
                if (j2 != i1 && j3 >> 1 < k2)
                {
                    throw i.a();
                }
                if (d)
                {
                    int k3 = -1 + stringbuilder.length();
                    int l3 = 0;
                    for (int i4 = 0; i4 < k3; i4++)
                    {
                        l3 += "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ-. *$/+%".indexOf(stringbuilder.charAt(i4));
                    }

                    if (stringbuilder.charAt(k3) != b[l3 % 43])
                    {
                        throw ps.hacking.zxing.d.a();
                    }
                    stringbuilder.setLength(k3);
                }
                if (stringbuilder.length() == 0)
                {
                    throw i.a();
                }
                String s;
                float f1;
                float f2;
                o ao[];
                if (e)
                {
                    s = a(((CharSequence) (stringbuilder)));
                } else
                {
                    s = stringbuilder.toString();
                }
                f1 = (float)(ai1[1] + ai1[0]) / 2.0F;
                f2 = (float)(l + j2) / 2.0F;
                ao = new o[2];
                ao[0] = new o(f1, j);
                ao[1] = new o(f2, j);
                return new m(s, null, ao, ps.hacking.zxing.a.c);
            }
            l = j2;
        } while (true);
    }

}
