// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.e;

import java.util.Map;
import ps.hacking.zxing.b.a;
import ps.hacking.zxing.f;
import ps.hacking.zxing.i;
import ps.hacking.zxing.m;
import ps.hacking.zxing.o;

// Referenced classes of package ps.hacking.zxing.e:
//            k

public final class d extends k
{

    private static final char a[] = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ-. $/+%abcd*".toCharArray();
    private static final int b[] = {
        276, 328, 324, 322, 296, 292, 290, 336, 274, 266, 
        424, 420, 418, 404, 402, 394, 360, 356, 354, 308, 
        282, 344, 332, 326, 300, 278, 436, 434, 428, 422, 
        406, 410, 364, 358, 310, 314, 302, 468, 466, 458, 
        366, 374, 430, 294, 474, 470, 306, 350
    };
    private static final int c = b[47];

    public d()
    {
    }

    private static char a(int j)
    {
        for (int l = 0; l < b.length; l++)
        {
            if (b[l] == j)
            {
                return a[l];
            }
        }

        throw i.a();
    }

    private static int a(int ai[])
    {
        int j = ai.length;
        int l = ai.length;
        int i1 = 0;
        int j1;
        int j3;
        for (j1 = 0; i1 < l; j1 = j3)
        {
            j3 = j1 + ai[i1];
            i1++;
        }

        int k1 = 0;
        int l1 = 0;
        do
        {
label0:
            {
                if (k1 < j)
                {
                    int i2 = (9 * (ai[k1] << 8)) / j1;
                    int j2 = i2 >> 8;
                    int k2;
                    int l2;
                    int i3;
                    if ((i2 & 0xff) > 127)
                    {
                        k2 = j2 + 1;
                    } else
                    {
                        k2 = j2;
                    }
                    if (k2 >= 1 && k2 <= 4)
                    {
                        break label0;
                    }
                    l1 = -1;
                }
                return l1;
            }
            if ((k1 & 1) == 0)
            {
                for (l2 = 0; l2 < k2;)
                {
                    i3 = 1 | l1 << 1;
                    l2++;
                    l1 = i3;
                }

            } else
            {
                l1 <<= k2;
            }
            k1++;
        } while (true);
    }

    private static String a(CharSequence charsequence)
    {
        int j;
        StringBuilder stringbuilder;
        int l;
        j = charsequence.length();
        stringbuilder = new StringBuilder(j);
        l = 0;
_L9:
        char c1;
        char c2;
        if (l >= j)
        {
            break MISSING_BLOCK_LABEL_291;
        }
        c1 = charsequence.charAt(l);
        if (c1 < 'a' || c1 > 'd')
        {
            break MISSING_BLOCK_LABEL_278;
        }
        if (l >= j - 1)
        {
            throw f.a();
        }
        c2 = charsequence.charAt(l + 1);
        c1;
        JVM INSTR tableswitch 97 100: default 100
    //                   97 152
    //                   98 181
    //                   99 235
    //                   100 123;
           goto _L1 _L2 _L3 _L4 _L5
_L1:
        char c3 = '\0';
_L6:
        int i1;
        stringbuilder.append(c3);
        i1 = l + 1;
_L7:
        l = i1 + 1;
        continue; /* Loop/switch isn't completed */
_L5:
        if (c2 >= 'A' && c2 <= 'Z')
        {
            c3 = (char)(c2 + 32);
        } else
        {
            throw f.a();
        }
          goto _L6
_L2:
        if (c2 >= 'A' && c2 <= 'Z')
        {
            c3 = (char)(c2 - 64);
        } else
        {
            throw f.a();
        }
          goto _L6
_L3:
        if (c2 >= 'A' && c2 <= 'E')
        {
            c3 = (char)(c2 - 38);
        } else
        if (c2 >= 'F' && c2 <= 'W')
        {
            c3 = (char)(c2 - 11);
        } else
        {
            throw f.a();
        }
          goto _L6
_L4:
        if (c2 >= 'A' && c2 <= 'O')
        {
            c3 = (char)(c2 - 32);
        } else
        if (c2 == 'Z')
        {
            c3 = ':';
        } else
        {
            throw f.a();
        }
          goto _L6
        stringbuilder.append(c1);
        i1 = l;
          goto _L7
        return stringbuilder.toString();
        if (true) goto _L9; else goto _L8
_L8:
    }

    private static void a(CharSequence charsequence, int j, int l)
    {
        int i1 = j - 1;
        int j1 = 1;
        int k1 = i1;
        int l1;
        int i2;
        for (l1 = 0; k1 >= 0; l1 = i2)
        {
            i2 = l1 + j1 * "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ-. $/+%abcd*".indexOf(charsequence.charAt(k1));
            int j2 = j1 + 1;
            if (j2 > l)
            {
                j2 = 1;
            }
            k1--;
            j1 = j2;
        }

        if (charsequence.charAt(j) != a[l1 % 47])
        {
            throw ps.hacking.zxing.d.a();
        } else
        {
            return;
        }
    }

    private static int[] a(a a1)
    {
        int j = a1.a();
        int l = a1.c(0);
        int ai[] = new int[6];
        int i1 = ai.length;
        int j1 = l;
        boolean flag = false;
        int k1 = 0;
        while (j1 < j) 
        {
            if (flag ^ a1.a(j1))
            {
                ai[k1] = 1 + ai[k1];
            } else
            {
                if (k1 == i1 - 1)
                {
                    if (a(ai) == c)
                    {
                        return (new int[] {
                            l, j1
                        });
                    }
                    l += ai[0] + ai[1];
                    System.arraycopy(ai, 2, ai, 0, i1 - 2);
                    ai[i1 - 2] = 0;
                    ai[i1 - 1] = 0;
                    k1--;
                } else
                {
                    k1++;
                }
                ai[k1] = 1;
                if (!flag)
                {
                    flag = true;
                } else
                {
                    flag = false;
                }
            }
            j1++;
        }
        throw i.a();
    }

    private static void b(CharSequence charsequence)
    {
        int j = charsequence.length();
        a(charsequence, j - 2, 20);
        a(charsequence, j - 1, 15);
    }

    public m a(int j, a a1, Map map)
    {
        int ai[] = a(a1);
        int l = a1.c(ai[1]);
        int i1 = a1.a();
        StringBuilder stringbuilder = new StringBuilder(20);
        int ai1[] = new int[6];
        do
        {
            a(a1, l, ai1);
            int j1 = a(ai1);
            if (j1 < 0)
            {
                throw i.a();
            }
            char c1 = a(j1);
            stringbuilder.append(c1);
            int k1 = ai1.length;
            int l1 = 0;
            int i2 = l;
            for (; l1 < k1; l1++)
            {
                i2 += ai1[l1];
            }

            int j2 = a1.c(i2);
            if (c1 == '*')
            {
                stringbuilder.deleteCharAt(-1 + stringbuilder.length());
                if (j2 == i1 || !a1.a(j2))
                {
                    throw i.a();
                }
                if (stringbuilder.length() < 2)
                {
                    throw i.a();
                } else
                {
                    b(stringbuilder);
                    stringbuilder.setLength(-2 + stringbuilder.length());
                    String s = a(((CharSequence) (stringbuilder)));
                    float f1 = (float)(ai[1] + ai[0]) / 2.0F;
                    float f2 = (float)(l + j2) / 2.0F;
                    o ao[] = new o[2];
                    ao[0] = new o(f1, j);
                    ao[1] = new o(f2, j);
                    return new m(s, null, ao, ps.hacking.zxing.a.d);
                }
            }
            l = j2;
        } while (true);
    }

}
