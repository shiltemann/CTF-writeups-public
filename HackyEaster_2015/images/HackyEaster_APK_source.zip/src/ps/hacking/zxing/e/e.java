// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.e;

import ps.hacking.zxing.b.a;
import ps.hacking.zxing.i;

// Referenced classes of package ps.hacking.zxing.e:
//            p

public final class e extends p
{

    static final int a[] = {
        0, 11, 13, 14, 19, 25, 28, 21, 22, 26
    };
    private final int f[] = new int[4];

    public e()
    {
    }

    private static void a(StringBuilder stringbuilder, int j)
    {
        for (int k = 0; k < 10; k++)
        {
            if (j == a[k])
            {
                stringbuilder.insert(0, (char)(k + 48));
                return;
            }
        }

        throw i.a();
    }

    protected int a(a a1, int ai[], StringBuilder stringbuilder)
    {
        int ai1[] = f;
        ai1[0] = 0;
        ai1[1] = 0;
        ai1[2] = 0;
        ai1[3] = 0;
        int j = a1.a();
        int k = ai[1];
        int l = 0;
        int i1 = 0;
        int i3;
        for (; l < 6 && k < j; k = i3)
        {
            int k2 = a(a1, ai1, k, e);
            stringbuilder.append((char)(48 + k2 % 10));
            int l2 = ai1.length;
            i3 = k;
            for (int j3 = 0; j3 < l2; j3++)
            {
                i3 += ai1[j3];
            }

            if (k2 >= 10)
            {
                i1 |= 1 << 5 - l;
            }
            l++;
        }

        a(stringbuilder, i1);
        int j1 = a(a1, k, true, c)[1];
        int i2;
        for (int k1 = 0; k1 < 6 && j1 < j; j1 = i2)
        {
            stringbuilder.append((char)(48 + a(a1, ai1, j1, d)));
            int l1 = ai1.length;
            i2 = j1;
            for (int j2 = 0; j2 < l1; j2++)
            {
                i2 += ai1[j2];
            }

            k1++;
        }

        return j1;
    }

    ps.hacking.zxing.a b()
    {
        return ps.hacking.zxing.a.h;
    }

}
