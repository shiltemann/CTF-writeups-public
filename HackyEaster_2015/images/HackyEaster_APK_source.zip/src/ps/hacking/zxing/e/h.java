// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.e;

import java.util.Map;
import ps.hacking.zxing.b.a;
import ps.hacking.zxing.e;
import ps.hacking.zxing.f;
import ps.hacking.zxing.i;
import ps.hacking.zxing.m;
import ps.hacking.zxing.o;

// Referenced classes of package ps.hacking.zxing.e:
//            k

public final class h extends k
{

    static final int a[][] = {
        {
            1, 1, 3, 3, 1
        }, {
            3, 1, 1, 1, 3
        }, {
            1, 3, 1, 1, 3
        }, {
            3, 3, 1, 1, 1
        }, {
            1, 1, 3, 1, 3
        }, {
            3, 1, 3, 1, 1
        }, {
            1, 3, 3, 1, 1
        }, {
            1, 1, 1, 3, 3
        }, {
            3, 1, 1, 3, 1
        }, {
            1, 3, 1, 3, 1
        }
    };
    private static final int b[] = {
        44, 24, 20, 18, 16, 14, 12, 10, 8, 6
    };
    private static final int d[] = {
        1, 1, 1, 1
    };
    private static final int e[] = {
        1, 1, 3
    };
    private int c;

    public h()
    {
        c = -1;
    }

    private static int a(int ai[])
    {
        int j = 107;
        int l = -1;
        int i1 = a.length;
        int j1 = 0;
        while (j1 < i1) 
        {
            int k1 = a(ai, a[j1], 204);
            if (k1 < j)
            {
                l = j1;
            } else
            {
                k1 = j;
            }
            j1++;
            j = k1;
        }
        if (l >= 0)
        {
            return l;
        } else
        {
            throw i.a();
        }
    }

    private void a(a a1, int j)
    {
        int l = 10 * c;
        int i1 = j - 1;
        do
        {
            if (l <= 0 || i1 < 0 || a1.a(i1))
            {
                if (l != 0)
                {
                    throw i.a();
                } else
                {
                    return;
                }
            }
            l--;
            i1--;
        } while (true);
    }

    private static void a(a a1, int j, int l, StringBuilder stringbuilder)
    {
        int ai[] = new int[10];
        int ai1[] = new int[5];
        int ai2[] = new int[5];
        int l1;
        for (int i1 = j; i1 < l; i1 = l1)
        {
            a(a1, i1, ai);
            for (int j1 = 0; j1 < 5; j1++)
            {
                int j2 = j1 << 1;
                ai1[j1] = ai[j2];
                ai2[j1] = ai[j2 + 1];
            }

            stringbuilder.append((char)(48 + a(ai1)));
            stringbuilder.append((char)(48 + a(ai2)));
            int k1 = ai.length;
            l1 = i1;
            for (int i2 = 0; i2 < k1; i2++)
            {
                l1 += ai[i2];
            }

        }

    }

    private static int c(a a1)
    {
        int j = a1.a();
        int l = a1.c(0);
        if (l == j)
        {
            throw i.a();
        } else
        {
            return l;
        }
    }

    private static int[] c(a a1, int j, int ai[])
    {
        int l = ai.length;
        int ai1[] = new int[l];
        int i1 = a1.a();
        int j1 = j;
        int k1 = 0;
        boolean flag = false;
        while (j < i1) 
        {
            if (flag ^ a1.a(j))
            {
                ai1[k1] = 1 + ai1[k1];
            } else
            {
                if (k1 == l - 1)
                {
                    if (a(ai1, ai, 204) < 107)
                    {
                        return (new int[] {
                            j1, j
                        });
                    }
                    j1 += ai1[0] + ai1[1];
                    System.arraycopy(ai1, 2, ai1, 0, l - 2);
                    ai1[l - 2] = 0;
                    ai1[l - 1] = 0;
                    k1--;
                } else
                {
                    k1++;
                }
                ai1[k1] = 1;
                if (!flag)
                {
                    flag = true;
                } else
                {
                    flag = false;
                }
            }
            j++;
        }
        throw i.a();
    }

    public m a(int j, a a1, Map map)
    {
        int ai[] = a(a1);
        int ai1[] = b(a1);
        StringBuilder stringbuilder = new StringBuilder(20);
        a(a1, ai[1], ai1[0], stringbuilder);
        String s = stringbuilder.toString();
        int ai2[];
        int l;
        int i1;
        int j1;
        boolean flag;
        o ao[];
        if (map != null)
        {
            ai2 = (int[])(int[])map.get(e.f);
        } else
        {
            ai2 = null;
        }
        if (ai2 == null)
        {
            ai2 = b;
        }
        l = s.length();
        i1 = ai2.length;
        j1 = 0;
        if (j1 >= i1)
        {
            break MISSING_BLOCK_LABEL_185;
        }
        if (l != ai2[j1]) goto _L2; else goto _L1
_L1:
        flag = true;
_L4:
        if (!flag)
        {
            throw f.a();
        } else
        {
            ao = new o[2];
            ao[0] = new o(ai[1], j);
            ao[1] = new o(ai1[0], j);
            return new m(s, null, ao, ps.hacking.zxing.a.i);
        }
_L2:
        j1++;
        break MISSING_BLOCK_LABEL_92;
        flag = false;
        if (true) goto _L4; else goto _L3
_L3:
    }

    int[] a(a a1)
    {
        int ai[] = c(a1, c(a1), d);
        c = ai[1] - ai[0] >> 2;
        a(a1, ai[0]);
        return ai;
    }

    int[] b(a a1)
    {
        a1.c();
        int ai[];
        ai = c(a1, c(a1), e);
        a(a1, ai[0]);
        int j = ai[0];
        ai[0] = a1.a() - ai[1];
        ai[1] = a1.a() - j;
        a1.c();
        return ai;
        Exception exception;
        exception;
        a1.c();
        throw exception;
    }

}
