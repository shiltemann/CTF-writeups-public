// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.e;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;
import ps.hacking.zxing.a;
import ps.hacking.zxing.e;
import ps.hacking.zxing.e.a.a.c;
import ps.hacking.zxing.k;
import ps.hacking.zxing.l;
import ps.hacking.zxing.m;

// Referenced classes of package ps.hacking.zxing.e:
//            k, j, c, d, 
//            b, h, a

public final class i extends ps.hacking.zxing.e.k
{

    private final ps.hacking.zxing.e.k a[];

    public i(Map map)
    {
        Collection collection;
        boolean flag;
        ArrayList arraylist;
        if (map == null)
        {
            collection = null;
        } else
        {
            collection = (Collection)map.get(e.c);
        }
        if (map != null && map.get(e.g) != null)
        {
            flag = true;
        } else
        {
            flag = false;
        }
        arraylist = new ArrayList();
        if (collection != null)
        {
            if (collection.contains(a.h) || collection.contains(a.o) || collection.contains(a.g) || collection.contains(a.p))
            {
                arraylist.add(new j(map));
            }
            if (collection.contains(a.c))
            {
                arraylist.add(new ps.hacking.zxing.e.c(flag));
            }
            if (collection.contains(a.d))
            {
                arraylist.add(new d());
            }
            if (collection.contains(a.e))
            {
                arraylist.add(new b());
            }
            if (collection.contains(a.i))
            {
                arraylist.add(new h());
            }
            if (collection.contains(a.b))
            {
                arraylist.add(new ps.hacking.zxing.e.a());
            }
            if (collection.contains(a.m))
            {
                arraylist.add(new ps.hacking.zxing.e.a.e());
            }
            if (collection.contains(a.n))
            {
                arraylist.add(new c());
            }
        }
        if (arraylist.isEmpty())
        {
            arraylist.add(new j(map));
            arraylist.add(new ps.hacking.zxing.e.c());
            arraylist.add(new ps.hacking.zxing.e.a());
            arraylist.add(new d());
            arraylist.add(new b());
            arraylist.add(new h());
            arraylist.add(new ps.hacking.zxing.e.a.e());
            arraylist.add(new c());
        }
        a = (ps.hacking.zxing.e.k[])arraylist.toArray(new ps.hacking.zxing.e.k[arraylist.size()]);
    }

    public m a(int i1, ps.hacking.zxing.b.a a1, Map map)
    {
        ps.hacking.zxing.e.k ak[];
        int j1;
        int k1;
        ak = a;
        j1 = ak.length;
        k1 = 0;
_L2:
        ps.hacking.zxing.e.k k2;
        if (k1 >= j1)
        {
            break; /* Loop/switch isn't completed */
        }
        k2 = ak[k1];
        m m = k2.a(i1, a1, map);
        return m;
        l l1;
        l1;
        k1++;
        if (true) goto _L2; else goto _L1
_L1:
        throw ps.hacking.zxing.i.a();
    }

    public void a()
    {
        ps.hacking.zxing.e.k ak[] = a;
        int i1 = ak.length;
        for (int j1 = 0; j1 < i1; j1++)
        {
            ak[j1].a();
        }

    }
}
