// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.e;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;
import ps.hacking.zxing.a;
import ps.hacking.zxing.e;
import ps.hacking.zxing.i;
import ps.hacking.zxing.k;
import ps.hacking.zxing.l;
import ps.hacking.zxing.m;

// Referenced classes of package ps.hacking.zxing.e:
//            k, e, f, q, 
//            p, l

public final class j extends ps.hacking.zxing.e.k
{

    private final p a[];

    public j(Map map)
    {
        Collection collection;
        ArrayList arraylist;
        if (map == null)
        {
            collection = null;
        } else
        {
            collection = (Collection)map.get(e.c);
        }
        arraylist = new ArrayList();
        if (collection == null) goto _L2; else goto _L1
_L1:
        if (!collection.contains(a.h)) goto _L4; else goto _L3
_L3:
        arraylist.add(new ps.hacking.zxing.e.e());
_L6:
        if (collection.contains(a.g))
        {
            arraylist.add(new f());
        }
        if (collection.contains(a.p))
        {
            arraylist.add(new q());
        }
_L2:
        if (arraylist.isEmpty())
        {
            arraylist.add(new ps.hacking.zxing.e.e());
            arraylist.add(new f());
            arraylist.add(new q());
        }
        a = (p[])arraylist.toArray(new p[arraylist.size()]);
        return;
_L4:
        if (collection.contains(a.o))
        {
            arraylist.add(new ps.hacking.zxing.e.l());
        }
        if (true) goto _L6; else goto _L5
_L5:
    }

    public m a(int i1, ps.hacking.zxing.b.a a1, Map map)
    {
        int ai[];
        p ap[];
        int j1;
        int k1;
        ai = ps.hacking.zxing.e.p.a(a1);
        ap = a;
        j1 = ap.length;
        k1 = 0;
_L2:
        p p1;
        if (k1 >= j1)
        {
            break; /* Loop/switch isn't completed */
        }
        p1 = ap[k1];
        m m1 = p1.a(i1, a1, ai, map);
        boolean flag;
        Collection collection;
        boolean flag1;
        if (m1.d() == a.h && m1.a().charAt(0) == '0')
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (map == null)
        {
            collection = null;
        } else
        {
            collection = (Collection)map.get(e.c);
        }
        if (collection == null || collection.contains(a.o))
        {
            flag1 = true;
        } else
        {
            flag1 = false;
        }
        if (flag && flag1)
        {
            m m2 = new m(m1.a().substring(1), m1.b(), m1.c(), a.o);
            m2.a(m1.e());
            return m2;
        } else
        {
            return m1;
        }
        l l1;
        l1;
        k1++;
        if (true) goto _L2; else goto _L1
_L1:
        throw i.a();
    }

    public void a()
    {
        p ap[] = a;
        int i1 = ap.length;
        for (int j1 = 0; j1 < i1; j1++)
        {
            ap[j1].a();
        }

    }
}
