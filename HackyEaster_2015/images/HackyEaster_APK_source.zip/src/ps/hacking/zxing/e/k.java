// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.e;

import java.util.Arrays;
import java.util.EnumMap;
import java.util.Map;
import ps.hacking.zxing.b.a;
import ps.hacking.zxing.c;
import ps.hacking.zxing.e;
import ps.hacking.zxing.i;
import ps.hacking.zxing.l;
import ps.hacking.zxing.m;
import ps.hacking.zxing.n;
import ps.hacking.zxing.o;

public abstract class k
    implements ps.hacking.zxing.k
{

    public k()
    {
    }

    protected static int a(int ai[], int ai1[], int j)
    {
        int i1;
        int k1;
        int l1;
        i1 = ai.length;
        int j1 = 0;
        k1 = 0;
        l1 = 0;
        for (; j1 < i1; j1++)
        {
            l1 += ai[j1];
            k1 += ai1[j1];
        }

        if (l1 >= k1) goto _L2; else goto _L1
_L1:
        return 0x7fffffff;
_L2:
        int l2;
        int i2 = (l1 << 8) / k1;
        int j2 = j * i2 >> 8;
        int k2 = 0;
        l2 = 0;
        do
        {
label0:
            {
                if (k2 >= i1)
                {
                    break label0;
                }
                int i3 = ai[k2] << 8;
                int j3 = i2 * ai1[k2];
                int k3;
                if (i3 > j3)
                {
                    k3 = i3 - j3;
                } else
                {
                    k3 = j3 - i3;
                }
                if (k3 > j2)
                {
                    continue; /* Loop/switch isn't completed */
                }
                l2 += k3;
                k2++;
            }
        } while (true);
        if (true) goto _L1; else goto _L3
_L3:
        return l2 / l1;
    }

    protected static void a(a a1, int j, int ai[])
    {
        int i1;
        int j1;
        boolean flag1;
        int k1;
        boolean flag3;
        i1 = ai.length;
        Arrays.fill(ai, 0, i1, 0);
        j1 = a1.a();
        if (j >= j1)
        {
            throw i.a();
        }
        boolean flag;
        if (!a1.a(j))
        {
            flag = true;
        } else
        {
            flag = false;
        }
        flag1 = flag;
        k1 = 0;
        if (j >= j1)
        {
            break MISSING_BLOCK_LABEL_162;
        }
        if (!(flag1 ^ a1.a(j)))
        {
            break; /* Loop/switch isn't completed */
        }
        ai[k1] = 1 + ai[k1];
        flag3 = flag1;
_L5:
        j++;
        flag1 = flag3;
        if (true) goto _L2; else goto _L1
_L2:
        break MISSING_BLOCK_LABEL_44;
_L1:
        int l1 = k1 + 1;
        if (l1 != i1) goto _L4; else goto _L3
_L3:
        boolean flag2;
        int i2;
        if (l1 != i1 && (l1 != i1 - 1 || j != j1))
        {
            throw i.a();
        } else
        {
            return;
        }
_L4:
        ai[l1] = 1;
        if (!flag1)
        {
            flag2 = true;
        } else
        {
            flag2 = false;
        }
        i2 = l1;
        flag3 = flag2;
        k1 = i2;
          goto _L5
        l1 = k1;
          goto _L3
    }

    private m b(c c1, Map map)
    {
        int j;
        int i2;
        a a2;
        Object obj;
        int k2;
        j = c1.a();
        int i1 = c1.b();
        a a1 = new a(j);
        int j1 = i1 >> 1;
        boolean flag;
        byte byte0;
        int k1;
        int l1;
        if (map != null && map.containsKey(e.d))
        {
            flag = true;
        } else
        {
            flag = false;
        }
        if (flag)
        {
            byte0 = 8;
        } else
        {
            byte0 = 5;
        }
        k1 = Math.max(1, i1 >> byte0);
        if (flag)
        {
            l1 = i1;
        } else
        {
            l1 = 15;
        }
        i2 = 0;
        a2 = a1;
        obj = map;
_L4:
label0:
        {
            if (i2 < l1)
            {
                int j2 = i2 + 1 >> 1;
                boolean flag1;
                if ((i2 & 1) == 0)
                {
                    flag1 = true;
                } else
                {
                    flag1 = false;
                }
                if (!flag1)
                {
                    j2 = -j2;
                }
                k2 = j1 + j2 * k1;
                if (k2 >= 0 && k2 < i1)
                {
                    break label0;
                }
            }
            throw i.a();
        }
        a a3 = c1.a(k2, a2);
        int i3;
        a2 = a3;
        i3 = 0;
_L3:
        if (i3 >= 2) goto _L2; else goto _L1
_L1:
        Object obj1;
        if (i3 != 1)
        {
            break MISSING_BLOCK_LABEL_384;
        }
        a2.c();
        if (obj == null || !((Map) (obj)).containsKey(e.h))
        {
            break MISSING_BLOCK_LABEL_384;
        }
        obj1 = new EnumMap(ps/hacking/zxing/e);
        ((Map) (obj1)).putAll(((Map) (obj)));
        ((Map) (obj1)).remove(e.h);
_L5:
        m m1 = a(k2, a2, ((Map) (obj1)));
        if (i3 != 1)
        {
            break MISSING_BLOCK_LABEL_361;
        }
        o ao[];
        m1.a(n.b, Integer.valueOf(180));
        ao = m1.c();
        if (ao == null)
        {
            break MISSING_BLOCK_LABEL_361;
        }
        ao[0] = new o((float)j - ao[0].a() - 1.0F, ao[0].b());
        ao[1] = new o((float)j - ao[1].a() - 1.0F, ao[1].b());
        return m1;
        l l3;
        l3;
        i3++;
        obj = obj1;
          goto _L3
        i l2;
        l2;
_L2:
        i2++;
          goto _L4
        obj1 = obj;
          goto _L5
    }

    protected static void b(a a1, int j, int ai[])
    {
        int i1 = ai.length;
        boolean flag = a1.a(j);
        do
        {
            if (j <= 0 || i1 < 0)
            {
                break;
            }
            j--;
            if (a1.a(j) != flag)
            {
                i1--;
                if (!flag)
                {
                    flag = true;
                } else
                {
                    flag = false;
                }
            }
        } while (true);
        if (i1 >= 0)
        {
            throw i.a();
        } else
        {
            a(a1, j + 1, ai);
            return;
        }
    }

    public abstract m a(int j, a a1, Map map);

    public m a(c c1, Map map)
    {
        m m2;
        try
        {
            m2 = b(c1, map);
        }
        catch (i j)
        {
            boolean flag;
            if (map != null && map.containsKey(e.d))
            {
                flag = true;
            } else
            {
                flag = false;
            }
            if (flag && c1.d())
            {
                c c2 = c1.e();
                m m1 = b(c2, map);
                Map map1 = m1.e();
                int i1;
                o ao[];
                if (map1 != null && map1.containsKey(n.b))
                {
                    i1 = (270 + ((Integer)map1.get(n.b)).intValue()) % 360;
                } else
                {
                    i1 = 270;
                }
                m1.a(n.b, Integer.valueOf(i1));
                ao = m1.c();
                if (ao != null)
                {
                    int j1 = c2.b();
                    for (int k1 = 0; k1 < ao.length; k1++)
                    {
                        ao[k1] = new o((float)j1 - ao[k1].b() - 1.0F, ao[k1].a());
                    }

                }
                return m1;
            } else
            {
                throw j;
            }
        }
        return m2;
    }

    public void a()
    {
    }
}
