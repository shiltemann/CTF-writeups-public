// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.e;

import java.util.Map;
import ps.hacking.zxing.a;
import ps.hacking.zxing.c;
import ps.hacking.zxing.f;
import ps.hacking.zxing.m;

// Referenced classes of package ps.hacking.zxing.e:
//            p, e

public final class l extends p
{

    private final p a = new e();

    public l()
    {
    }

    private static m a(m m1)
    {
        String s = m1.a();
        if (s.charAt(0) == '0')
        {
            return new m(s.substring(1), null, m1.c(), a.o);
        } else
        {
            throw f.a();
        }
    }

    protected int a(ps.hacking.zxing.b.a a1, int ai[], StringBuilder stringbuilder)
    {
        return a.a(a1, ai, stringbuilder);
    }

    public m a(int i, ps.hacking.zxing.b.a a1, Map map)
    {
        return a(a.a(i, a1, map));
    }

    public m a(int i, ps.hacking.zxing.b.a a1, int ai[], Map map)
    {
        return a(a.a(i, a1, ai, map));
    }

    public m a(c c, Map map)
    {
        return a(a.a(c, map));
    }

    a b()
    {
        return a.o;
    }
}
