// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.e;

import java.util.EnumMap;
import java.util.Map;
import ps.hacking.zxing.b.a;
import ps.hacking.zxing.i;
import ps.hacking.zxing.n;
import ps.hacking.zxing.o;

// Referenced classes of package ps.hacking.zxing.e:
//            p

final class m
{

    private final int a[] = new int[4];
    private final StringBuilder b = new StringBuilder();

    m()
    {
    }

    private static Map a(String s)
    {
        if (s.length() != 2)
        {
            return null;
        } else
        {
            EnumMap enummap = new EnumMap(ps/hacking/zxing/n);
            enummap.put(n.e, Integer.valueOf(s));
            return enummap;
        }
    }

    int a(a a1, int ai[], StringBuilder stringbuilder)
    {
        int ai1[] = a;
        ai1[0] = 0;
        ai1[1] = 0;
        ai1[2] = 0;
        ai1[3] = 0;
        int j = a1.a();
        int k = ai[1];
        int l = 0;
        int i1 = 0;
        for (; l < 2 && k < j; l++)
        {
            int j1 = ps.hacking.zxing.e.p.a(a1, ai1, k, p.e);
            stringbuilder.append((char)(48 + j1 % 10));
            int k1 = ai1.length;
            for (int l1 = 0; l1 < k1;)
            {
                int i2 = k + ai1[l1];
                l1++;
                k = i2;
            }

            if (j1 >= 10)
            {
                i1 |= 1 << 1 - l;
            }
            if (l != 1)
            {
                k = a1.d(a1.c(k));
            }
        }

        if (stringbuilder.length() != 2)
        {
            throw i.a();
        }
        if (Integer.parseInt(stringbuilder.toString()) % 4 != i1)
        {
            throw i.a();
        } else
        {
            return k;
        }
    }

    ps.hacking.zxing.m a(int j, a a1, int ai[])
    {
        StringBuilder stringbuilder = b;
        stringbuilder.setLength(0);
        int k = a(a1, ai, stringbuilder);
        String s = stringbuilder.toString();
        Map map = a(s);
        o ao[] = new o[2];
        ao[0] = new o((float)(ai[0] + ai[1]) / 2.0F, j);
        ao[1] = new o(k, j);
        ps.hacking.zxing.m m1 = new ps.hacking.zxing.m(s, null, ao, ps.hacking.zxing.a.q);
        if (map != null)
        {
            m1.a(map);
        }
        return m1;
    }
}
