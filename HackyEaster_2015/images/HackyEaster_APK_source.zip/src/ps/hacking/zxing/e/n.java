// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.e;

import java.util.EnumMap;
import java.util.Map;
import ps.hacking.zxing.b.a;
import ps.hacking.zxing.i;
import ps.hacking.zxing.m;
import ps.hacking.zxing.o;

// Referenced classes of package ps.hacking.zxing.e:
//            p

final class n
{

    private static final int a[] = {
        24, 20, 18, 17, 12, 6, 3, 10, 9, 5
    };
    private final int b[] = new int[4];
    private final StringBuilder c = new StringBuilder();

    n()
    {
    }

    private static int a(int j)
    {
        for (int k = 0; k < 10; k++)
        {
            if (j == a[k])
            {
                return k;
            }
        }

        throw i.a();
    }

    private static int a(CharSequence charsequence)
    {
        int j = charsequence.length();
        int k = 0;
        for (int l = j - 2; l >= 0; l -= 2)
        {
            k += -48 + charsequence.charAt(l);
        }

        int i1 = k * 3;
        for (int j1 = j - 1; j1 >= 0; j1 -= 2)
        {
            i1 += -48 + charsequence.charAt(j1);
        }

        return (i1 * 3) % 10;
    }

    private static Map a(String s)
    {
        String s1;
        if (s.length() == 5)
        {
            if ((s1 = b(s)) != null)
            {
                EnumMap enummap = new EnumMap(ps/hacking/zxing/n);
                enummap.put(ps.hacking.zxing.n.f, s1);
                return enummap;
            }
        }
        return null;
    }

    private static String b(String s)
    {
        s.charAt(0);
        JVM INSTR lookupswitch 3: default 40
    //                   48: 124
    //                   53: 130
    //                   57: 136;
           goto _L1 _L2 _L3 _L4
_L4:
        break MISSING_BLOCK_LABEL_136;
_L1:
        String s1 = "";
_L5:
        int j = Integer.parseInt(s.substring(1));
        String s2 = String.valueOf(j / 100);
        int k = j % 100;
        String s3;
        if (k < 10)
        {
            s3 = (new StringBuilder()).append("0").append(k).toString();
        } else
        {
            s3 = String.valueOf(k);
        }
        return (new StringBuilder()).append(s1).append(s2).append('.').append(s3).toString();
_L2:
        s1 = "\302\243";
          goto _L5
_L3:
        s1 = "$";
          goto _L5
        if ("90000".equals(s))
        {
            return null;
        }
        if ("99991".equals(s))
        {
            return "0.00";
        }
        if ("99990".equals(s))
        {
            return "Used";
        }
        s1 = "";
          goto _L5
    }

    int a(a a1, int ai[], StringBuilder stringbuilder)
    {
        int ai1[] = b;
        ai1[0] = 0;
        ai1[1] = 0;
        ai1[2] = 0;
        ai1[3] = 0;
        int j = a1.a();
        int k = ai[1];
        int l = 0;
        int i1 = 0;
        for (; l < 5 && k < j; l++)
        {
            int k1 = ps.hacking.zxing.e.p.a(a1, ai1, k, p.e);
            stringbuilder.append((char)(48 + k1 % 10));
            int l1 = ai1.length;
            for (int i2 = 0; i2 < l1;)
            {
                int j2 = k + ai1[i2];
                i2++;
                k = j2;
            }

            if (k1 >= 10)
            {
                i1 |= 1 << 4 - l;
            }
            if (l != 4)
            {
                k = a1.d(a1.c(k));
            }
        }

        if (stringbuilder.length() != 5)
        {
            throw i.a();
        }
        int j1 = a(i1);
        if (a(((CharSequence) (stringbuilder.toString()))) != j1)
        {
            throw i.a();
        } else
        {
            return k;
        }
    }

    m a(int j, a a1, int ai[])
    {
        StringBuilder stringbuilder = c;
        stringbuilder.setLength(0);
        int k = a(a1, ai, stringbuilder);
        String s = stringbuilder.toString();
        Map map = a(s);
        o ao[] = new o[2];
        ao[0] = new o((float)(ai[0] + ai[1]) / 2.0F, j);
        ao[1] = new o(k, j);
        m m1 = new m(s, null, ao, ps.hacking.zxing.a.q);
        if (map != null)
        {
            m1.a(map);
        }
        return m1;
    }

}
