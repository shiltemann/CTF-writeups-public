// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.e;

import ps.hacking.zxing.b.a;
import ps.hacking.zxing.l;
import ps.hacking.zxing.m;

// Referenced classes of package ps.hacking.zxing.e:
//            m, n, p

final class o
{

    private static final int a[] = {
        1, 1, 2
    };
    private final ps.hacking.zxing.e.m b = new ps.hacking.zxing.e.m();
    private final n c = new n();

    o()
    {
    }

    m a(int i, a a1, int j)
    {
        int ai[] = ps.hacking.zxing.e.p.a(a1, j, false, a);
        m m1;
        try
        {
            m1 = c.a(i, a1, ai);
        }
        catch (l l1)
        {
            return b.a(i, a1, ai);
        }
        return m1;
    }

}
