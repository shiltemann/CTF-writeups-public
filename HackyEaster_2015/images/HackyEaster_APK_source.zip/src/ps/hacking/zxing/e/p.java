// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.e;

import java.util.Arrays;
import java.util.Map;
import ps.hacking.zxing.b.a;
import ps.hacking.zxing.d;
import ps.hacking.zxing.e;
import ps.hacking.zxing.f;
import ps.hacking.zxing.i;
import ps.hacking.zxing.l;
import ps.hacking.zxing.m;
import ps.hacking.zxing.n;
import ps.hacking.zxing.o;

// Referenced classes of package ps.hacking.zxing.e:
//            k, o, g

public abstract class p extends k
{

    static final int b[] = {
        1, 1, 1
    };
    static final int c[] = {
        1, 1, 1, 1, 1
    };
    static final int d[][] = {
        {
            3, 2, 1, 1
        }, {
            2, 2, 2, 1
        }, {
            2, 1, 2, 2
        }, {
            1, 4, 1, 1
        }, {
            1, 1, 3, 2
        }, {
            1, 2, 3, 1
        }, {
            1, 1, 1, 4
        }, {
            1, 3, 1, 2
        }, {
            1, 2, 1, 3
        }, {
            3, 1, 1, 2
        }
    };
    static final int e[][];
    private final StringBuilder a = new StringBuilder(20);
    private final ps.hacking.zxing.e.o f = new ps.hacking.zxing.e.o();
    private final g g = new g();

    protected p()
    {
    }

    static int a(a a1, int ai[], int j, int ai1[][])
    {
        a(a1, j, ai);
        int i1 = 122;
        int j1 = -1;
        int k1 = ai1.length;
        int l1 = 0;
        while (l1 < k1) 
        {
            int i2 = a(ai, ai1[l1], 179);
            if (i2 < i1)
            {
                j1 = l1;
            } else
            {
                i2 = i1;
            }
            l1++;
            i1 = i2;
        }
        if (j1 >= 0)
        {
            return j1;
        } else
        {
            throw i.a();
        }
    }

    static boolean a(CharSequence charsequence)
    {
        int j = charsequence.length();
        if (j != 0)
        {
            int i1 = j - 2;
            int j1 = 0;
            for (; i1 >= 0; i1 -= 2)
            {
                int j2 = -48 + charsequence.charAt(i1);
                if (j2 < 0 || j2 > 9)
                {
                    throw ps.hacking.zxing.f.a();
                }
                j1 += j2;
            }

            int k1 = j1 * 3;
            for (int l1 = j - 1; l1 >= 0; l1 -= 2)
            {
                int i2 = -48 + charsequence.charAt(l1);
                if (i2 < 0 || i2 > 9)
                {
                    throw ps.hacking.zxing.f.a();
                }
                k1 += i2;
            }

            if (k1 % 10 == 0)
            {
                return true;
            }
        }
        return false;
    }

    static int[] a(a a1)
    {
        int ai[] = new int[b.length];
        int j = 0;
        int ai1[] = null;
        boolean flag = false;
        do
        {
            if (flag)
            {
                break;
            }
            Arrays.fill(ai, 0, b.length, 0);
            ai1 = a(a1, j, false, b, ai);
            int i1 = ai1[0];
            j = ai1[1];
            int j1 = i1 - (j - i1);
            if (j1 >= 0)
            {
                flag = a1.a(j1, i1, false);
            }
        } while (true);
        return ai1;
    }

    static int[] a(a a1, int j, boolean flag, int ai[])
    {
        return a(a1, j, flag, ai, new int[ai.length]);
    }

    private static int[] a(a a1, int j, boolean flag, int ai[], int ai1[])
    {
        int i1 = ai.length;
        int j1 = a1.a();
        int k1;
        int l1;
        int i2;
        boolean flag1;
        if (flag)
        {
            k1 = a1.d(j);
        } else
        {
            k1 = a1.c(j);
        }
        l1 = k1;
        i2 = 0;
        flag1 = flag;
        while (l1 < j1) 
        {
            if (flag1 ^ a1.a(l1))
            {
                ai1[i2] = 1 + ai1[i2];
            } else
            {
                if (i2 == i1 - 1)
                {
                    if (a(ai1, ai, 179) < 122)
                    {
                        return (new int[] {
                            k1, l1
                        });
                    }
                    k1 += ai1[0] + ai1[1];
                    System.arraycopy(ai1, 2, ai1, 0, i1 - 2);
                    ai1[i1 - 2] = 0;
                    ai1[i1 - 1] = 0;
                    i2--;
                } else
                {
                    i2++;
                }
                ai1[i2] = 1;
                if (!flag1)
                {
                    flag1 = true;
                } else
                {
                    flag1 = false;
                }
            }
            l1++;
        }
        throw i.a();
    }

    protected abstract int a(a a1, int ai[], StringBuilder stringbuilder);

    public m a(int j, a a1, Map map)
    {
        return a(j, a1, a(a1), map);
    }

    public m a(int j, a a1, int ai[], Map map)
    {
        ps.hacking.zxing.p p1;
        StringBuilder stringbuilder;
        int i1;
        int ai1[];
        int j1;
        int k1;
        if (map == null)
        {
            p1 = null;
        } else
        {
            p1 = (ps.hacking.zxing.p)map.get(e.h);
        }
        if (p1 != null)
        {
            p1.a(new o((float)(ai[0] + ai[1]) / 2.0F, j));
        }
        stringbuilder = a;
        stringbuilder.setLength(0);
        i1 = a(a1, ai, stringbuilder);
        if (p1 != null)
        {
            p1.a(new o(i1, j));
        }
        ai1 = a(a1, i1);
        if (p1 != null)
        {
            p1.a(new o((float)(ai1[0] + ai1[1]) / 2.0F, j));
        }
        j1 = ai1[1];
        k1 = j1 + (j1 - ai1[0]);
        if (k1 >= a1.a() || !a1.a(j1, k1, false))
        {
            throw i.a();
        }
        String s = stringbuilder.toString();
        if (!a(s))
        {
            throw ps.hacking.zxing.d.a();
        }
        float f1 = (float)(ai[1] + ai[0]) / 2.0F;
        float f2 = (float)(ai1[1] + ai1[0]) / 2.0F;
        ps.hacking.zxing.a a2 = b();
        o ao[] = new o[2];
        ao[0] = new o(f1, j);
        ao[1] = new o(f2, j);
        m m1 = new m(s, null, ao, a2);
        try
        {
            m m2 = f.a(j, a1, ai1[1]);
            m1.a(n.h, m2.a());
            m1.a(m2.e());
            m1.a(m2.c());
        }
        catch (l l1) { }
        if (a2 == ps.hacking.zxing.a.h || a2 == ps.hacking.zxing.a.o)
        {
            String s1 = g.a(s);
            if (s1 != null)
            {
                m1.a(n.g, s1);
            }
        }
        return m1;
    }

    boolean a(String s)
    {
        return a(((CharSequence) (s)));
    }

    int[] a(a a1, int j)
    {
        return a(a1, j, false, b);
    }

    abstract ps.hacking.zxing.a b();

    static 
    {
        e = new int[20][];
        System.arraycopy(d, 0, e, 0, 10);
        for (int j = 10; j < 20; j++)
        {
            int ai[] = d[j - 10];
            int ai1[] = new int[ai.length];
            for (int i1 = 0; i1 < ai.length; i1++)
            {
                ai1[i1] = ai[-1 + (ai.length - i1)];
            }

            e[j] = ai1;
        }

    }
}
