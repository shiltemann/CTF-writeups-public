// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.e;

import ps.hacking.zxing.b.a;
import ps.hacking.zxing.i;

// Referenced classes of package ps.hacking.zxing.e:
//            p

public final class q extends p
{

    private static final int a[] = {
        1, 1, 1, 1, 1, 1
    };
    private static final int f[][] = {
        {
            56, 52, 50, 49, 44, 38, 35, 42, 41, 37
        }, {
            7, 11, 13, 14, 19, 25, 28, 21, 22, 26
        }
    };
    private final int g[] = new int[4];

    public q()
    {
    }

    private static void a(StringBuilder stringbuilder, int j)
    {
        for (int k = 0; k <= 1; k++)
        {
            for (int l = 0; l < 10; l++)
            {
                if (j == f[k][l])
                {
                    stringbuilder.insert(0, (char)(k + 48));
                    stringbuilder.append((char)(l + 48));
                    return;
                }
            }

        }

        throw i.a();
    }

    public static String b(String s)
    {
        char ac[];
        StringBuilder stringbuilder;
        char c;
        ac = new char[6];
        s.getChars(1, 7, ac, 0);
        stringbuilder = new StringBuilder(12);
        stringbuilder.append(s.charAt(0));
        c = ac[5];
        c;
        JVM INSTR tableswitch 48 52: default 76
    //                   48 114
    //                   49 114
    //                   50 114
    //                   51 147
    //                   52 173;
           goto _L1 _L2 _L2 _L2 _L3 _L4
_L1:
        stringbuilder.append(ac, 0, 5);
        stringbuilder.append("0000");
        stringbuilder.append(c);
_L6:
        stringbuilder.append(s.charAt(7));
        return stringbuilder.toString();
_L2:
        stringbuilder.append(ac, 0, 2);
        stringbuilder.append(c);
        stringbuilder.append("0000");
        stringbuilder.append(ac, 2, 3);
        continue; /* Loop/switch isn't completed */
_L3:
        stringbuilder.append(ac, 0, 3);
        stringbuilder.append("00000");
        stringbuilder.append(ac, 3, 2);
        continue; /* Loop/switch isn't completed */
_L4:
        stringbuilder.append(ac, 0, 4);
        stringbuilder.append("00000");
        stringbuilder.append(ac[4]);
        if (true) goto _L6; else goto _L5
_L5:
    }

    protected int a(a a1, int ai[], StringBuilder stringbuilder)
    {
        int ai1[] = g;
        ai1[0] = 0;
        ai1[1] = 0;
        ai1[2] = 0;
        ai1[3] = 0;
        int j = a1.a();
        int k = ai[1];
        int l = 0;
        int i1 = 0;
        int l1;
        for (; l < 6 && k < j; k = l1)
        {
            int j1 = a(a1, ai1, k, e);
            stringbuilder.append((char)(48 + j1 % 10));
            int k1 = ai1.length;
            l1 = k;
            for (int i2 = 0; i2 < k1; i2++)
            {
                l1 += ai1[i2];
            }

            if (j1 >= 10)
            {
                i1 |= 1 << 5 - l;
            }
            l++;
        }

        a(stringbuilder, i1);
        return k;
    }

    protected boolean a(String s)
    {
        return super.a(b(s));
    }

    protected int[] a(a a1, int j)
    {
        return a(a1, j, true, a);
    }

    ps.hacking.zxing.a b()
    {
        return ps.hacking.zxing.a.p;
    }

}
