// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.f;

import java.util.Map;
import ps.hacking.zxing.b.b;
import ps.hacking.zxing.b.g;
import ps.hacking.zxing.c;
import ps.hacking.zxing.f.a.e;
import ps.hacking.zxing.i;
import ps.hacking.zxing.k;
import ps.hacking.zxing.m;
import ps.hacking.zxing.o;

public final class a
    implements k
{

    private static final o a[] = new o[0];
    private final e b = new e();

    public a()
    {
    }

    private static int a(int j, int l, b b1)
    {
        int i1 = b1.d();
        int j1 = 0;
        boolean flag1;
        for (boolean flag = true; j < i1 - 1 && j1 < 8; flag = flag1)
        {
            j++;
            flag1 = b1.a(j, l);
            if (flag != flag1)
            {
                j1++;
            }
        }

        if (j == i1 - 1)
        {
            throw i.a();
        } else
        {
            return j;
        }
    }

    private static int a(int ai[], b b1)
    {
        int j = ai[0];
        int l = ai[1];
        int i1;
        for (i1 = b1.d(); j < i1 && b1.a(j, l); j++) { }
        if (j == i1)
        {
            throw i.a();
        }
        int j1 = j - ai[0] >>> 3;
        if (j1 == 0)
        {
            throw i.a();
        } else
        {
            return j1;
        }
    }

    private static b a(b b1)
    {
        int ai[] = b1.b();
        int ai1[] = b1.c();
        if (ai == null || ai1 == null)
        {
            throw i.a();
        }
        int j = a(ai, b1);
        int l = ai[1];
        int i1 = ai1[1];
        int j1 = a(ai[0], l, b1);
        int k1 = (1 + (b(ai[0], l, b1) - j1)) / j;
        int l1 = (1 + (i1 - l)) / j;
        if (k1 <= 0 || l1 <= 0)
        {
            throw i.a();
        }
        int i2 = j >> 1;
        int j2 = l + i2;
        int k2 = j1 + i2;
        b b2 = new b(k1, l1);
        for (int l2 = 0; l2 < l1; l2++)
        {
            int i3 = j2 + l2 * j;
            for (int j3 = 0; j3 < k1; j3++)
            {
                if (b1.a(k2 + j3 * j, i3))
                {
                    b2.b(j3, l2);
                }
            }

        }

        return b2;
    }

    private static int b(int j, int l, b b1)
    {
        int i1;
        for (i1 = -1 + b1.d(); i1 > j && !b1.a(i1, l); i1--) { }
        int j1 = 0;
        boolean flag = true;
        int k1;
        for (; i1 > j && j1 < 9; i1 = k1)
        {
            k1 = i1 - 1;
            boolean flag1 = b1.a(k1, l);
            if (flag != flag1)
            {
                j1++;
            }
            flag = flag1;
        }

        if (i1 == j)
        {
            throw i.a();
        } else
        {
            return i1;
        }
    }

    public m a(c c1, Map map)
    {
        ps.hacking.zxing.b.e e1;
        o ao[];
        if (map != null && map.containsKey(ps.hacking.zxing.e.b))
        {
            b b1 = a(c1.c());
            e1 = b.a(b1);
            ao = a;
        } else
        {
            g g1 = (new ps.hacking.zxing.f.b.a(c1)).a();
            e1 = b.a(g1.d());
            ao = g1.e();
        }
        return new m(e1.b(), e1.a(), ao, ps.hacking.zxing.a.k);
    }

    public void a()
    {
    }

}
