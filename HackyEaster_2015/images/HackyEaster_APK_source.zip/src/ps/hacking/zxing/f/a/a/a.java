// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.f.a.a;

import ps.hacking.zxing.d;

// Referenced classes of package ps.hacking.zxing.f.a.a:
//            b, c

public final class a
{

    private final b a;

    public a()
    {
        a = b.a;
    }

    private int[] a(c c1)
    {
        int i = c1.a();
        int ai[] = new int[i];
        int j = 0;
        for (int k = 1; k < a.c() && j < i; k++)
        {
            if (c1.b(k) == 0)
            {
                ai[j] = a.c(k);
                j++;
            }
        }

        if (j != i)
        {
            throw d.a();
        } else
        {
            return ai;
        }
    }

    private int[] a(c c1, c c2, int ai[])
    {
        int i = c2.a();
        int ai1[] = new int[i];
        for (int j = 1; j <= i; j++)
        {
            ai1[i - j] = a.d(j, c2.a(j));
        }

        c c3 = new c(a, ai1);
        int k = ai.length;
        int ai2[] = new int[k];
        for (int l = 0; l < k; l++)
        {
            int i1 = a.c(ai[l]);
            int j1 = a.c(0, c1.b(i1));
            int k1 = a.c(c3.b(i1));
            ai2[l] = a.d(j1, k1);
        }

        return ai2;
    }

    private c[] a(c c1, c c2, int i)
    {
        c c4;
        c c5;
        int j;
        if (c1.a() >= c2.a())
        {
            c c3 = c2;
            c2 = c1;
            c1 = c3;
        }
        c4 = a.a();
        c5 = a.b();
        while (c1.a() >= i / 2) 
        {
            if (c1.b())
            {
                throw d.a();
            }
            c c6 = a.a();
            int l = c1.a(c1.a());
            int i1 = a.c(l);
            c c7 = c6;
            c c8;
            int j1;
            int k1;
            for (c8 = c2; c8.a() >= c1.a() && !c8.b(); c8 = c8.b(c1.a(j1, k1)))
            {
                j1 = c8.a() - c1.a();
                k1 = a.d(c8.a(c8.a()), i1);
                c7 = c7.a(a.a(j1, k1));
            }

            c c9 = c7.c(c5).b(c4).c();
            c2 = c1;
            c1 = c8;
            c c10 = c5;
            c5 = c9;
            c4 = c10;
        }
        j = c5.a(0);
        if (j == 0)
        {
            throw d.a();
        } else
        {
            int k = a.c(j);
            return (new c[] {
                c5.c(k), c1.c(k)
            });
        }
    }

    public void a(int ai[], int i, int ai1[])
    {
        c c1 = new c(a, ai);
        int ai2[] = new int[i];
        int j = i;
        boolean flag = false;
        for (; j > 0; j--)
        {
            int i2 = c1.b(a.a(j));
            ai2[i - j] = i2;
            if (i2 != 0)
            {
                flag = true;
            }
        }

        if (flag)
        {
            c c2 = a.b();
            int k = ai1.length;
            c c3 = c2;
            for (int l = 0; l < k; l++)
            {
                int k1 = ai1[l];
                int l1 = a.a((-1 + ai.length) - k1);
                b b1 = a;
                int ai5[] = new int[2];
                ai5[0] = a.c(0, l1);
                ai5[1] = 1;
                c3 = c3.c(new c(b1, ai5));
            }

            c c4 = new c(a, ai2);
            c ac[] = a(a.a(i, 1), c4, i);
            c c5 = ac[0];
            c c6 = ac[1];
            int ai3[] = a(c5);
            int ai4[] = a(c6, c5, ai3);
            for (int i1 = 0; i1 < ai3.length; i1++)
            {
                int j1 = (-1 + ai.length) - a.b(ai3[i1]);
                if (j1 < 0)
                {
                    throw d.a();
                }
                ai[j1] = a.c(ai[j1], ai4[i1]);
            }

        }
    }
}
