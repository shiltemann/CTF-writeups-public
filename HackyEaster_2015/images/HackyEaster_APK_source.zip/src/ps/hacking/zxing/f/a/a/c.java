// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.f.a.a;


// Referenced classes of package ps.hacking.zxing.f.a.a:
//            b

final class c
{

    private final b a;
    private final int b[];

    c(b b1, int ai[])
    {
        int i = 1;
        super();
        if (ai.length == 0)
        {
            throw new IllegalArgumentException();
        }
        a = b1;
        int j = ai.length;
        if (j > i && ai[0] == 0)
        {
            for (; i < j && ai[i] == 0; i++) { }
            if (i == j)
            {
                b = b1.a().b;
                return;
            } else
            {
                b = new int[j - i];
                System.arraycopy(ai, i, b, 0, b.length);
                return;
            }
        } else
        {
            b = ai;
            return;
        }
    }

    int a()
    {
        return -1 + b.length;
    }

    int a(int i)
    {
        return b[(-1 + b.length) - i];
    }

    c a(int i, int j)
    {
        if (i < 0)
        {
            throw new IllegalArgumentException();
        }
        if (j == 0)
        {
            return a.a();
        }
        int k = b.length;
        int ai[] = new int[k + i];
        for (int l = 0; l < k; l++)
        {
            ai[l] = a.d(b[l], j);
        }

        return new c(a, ai);
    }

    c a(c c1)
    {
        if (!a.equals(c1.a))
        {
            throw new IllegalArgumentException("ModulusPolys do not have same ModulusGF field");
        }
        if (b())
        {
            return c1;
        }
        if (c1.b())
        {
            return this;
        }
        int ai[] = b;
        int ai1[] = c1.b;
        int ai3[];
        int i;
        if (ai.length <= ai1.length)
        {
            int ai2[] = ai1;
            ai1 = ai;
            ai = ai2;
        }
        ai3 = new int[ai.length];
        i = ai.length - ai1.length;
        System.arraycopy(ai, 0, ai3, 0, i);
        for (int j = i; j < ai.length; j++)
        {
            ai3[j] = a.b(ai1[j - i], ai[j]);
        }

        return new c(a, ai3);
    }

    int b(int i)
    {
        int j = 0;
        if (i != 0) goto _L2; else goto _L1
_L1:
        int l = a(0);
_L4:
        return l;
_L2:
        int k;
        k = b.length;
        if (i != 1)
        {
            break; /* Loop/switch isn't completed */
        }
        int ai[] = b;
        int k1 = ai.length;
        l = 0;
        while (j < k1) 
        {
            int l1 = ai[j];
            int i2 = a.b(l, l1);
            j++;
            l = i2;
        }
        if (true) goto _L4; else goto _L3
_L3:
        l = b[0];
        int i1 = 1;
        while (i1 < k) 
        {
            int j1 = a.b(a.d(i, l), b[i1]);
            i1++;
            l = j1;
        }
        if (true) goto _L4; else goto _L5
_L5:
    }

    c b(c c1)
    {
        if (!a.equals(c1.a))
        {
            throw new IllegalArgumentException("ModulusPolys do not have same ModulusGF field");
        }
        if (c1.b())
        {
            return this;
        } else
        {
            return a(c1.c());
        }
    }

    boolean b()
    {
        int i = b[0];
        boolean flag = false;
        if (i == 0)
        {
            flag = true;
        }
        return flag;
    }

    c c()
    {
        int i = b.length;
        int ai[] = new int[i];
        for (int j = 0; j < i; j++)
        {
            ai[j] = a.c(0, b[j]);
        }

        return new c(a, ai);
    }

    c c(int i)
    {
        if (i == 0)
        {
            this = a.a();
        } else
        if (i != 1)
        {
            int j = b.length;
            int ai[] = new int[j];
            for (int k = 0; k < j; k++)
            {
                ai[k] = a.d(b[k], i);
            }

            return new c(a, ai);
        }
        return this;
    }

    c c(c c1)
    {
        if (!a.equals(c1.a))
        {
            throw new IllegalArgumentException("ModulusPolys do not have same ModulusGF field");
        }
        if (b() || c1.b())
        {
            return a.a();
        }
        int ai[] = b;
        int i = ai.length;
        int ai1[] = c1.b;
        int j = ai1.length;
        int ai2[] = new int[-1 + (i + j)];
        for (int k = 0; k < i; k++)
        {
            int l = ai[k];
            for (int i1 = 0; i1 < j; i1++)
            {
                ai2[k + i1] = a.b(ai2[k + i1], a.d(l, ai1[i1]));
            }

        }

        return new c(a, ai2);
    }

    public String toString()
    {
        StringBuilder stringbuilder = new StringBuilder(8 * a());
        int i = a();
        do
        {
            if (i >= 0)
            {
                int j = a(i);
                if (j != 0)
                {
                    if (j < 0)
                    {
                        stringbuilder.append(" - ");
                        j = -j;
                    } else
                    if (stringbuilder.length() > 0)
                    {
                        stringbuilder.append(" + ");
                    }
                    if (i == 0 || j != 1)
                    {
                        stringbuilder.append(j);
                    }
                    if (i != 0)
                    {
                        if (i == 1)
                        {
                            stringbuilder.append('x');
                        } else
                        {
                            stringbuilder.append("x^");
                            stringbuilder.append(i);
                        }
                    }
                }
                i--;
                continue;
            }
            return stringbuilder.toString();
        } while (true);
    }
}
