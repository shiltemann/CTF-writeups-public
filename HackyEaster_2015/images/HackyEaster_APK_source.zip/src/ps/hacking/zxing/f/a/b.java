// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.f.a;

import java.math.BigInteger;
import ps.hacking.zxing.b.e;
import ps.hacking.zxing.f;

// Referenced classes of package ps.hacking.zxing.f.a:
//            d, c

final class b
{

    private static final char a[] = {
        ';', '<', '>', '@', '[', '\\', '}', '_', '`', '~', 
        '!', '\r', '\t', ',', ':', '\n', '-', '.', '$', '/', 
        '"', '|', '*', '(', ')', '?', '{', '}', '\''
    };
    private static final char b[] = {
        '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 
        '&', '\r', '\t', ',', ':', '#', '-', '.', '$', '/', 
        '+', '%', '*', '=', '^'
    };
    private static final BigInteger c[];

    private static int a(int i, int ai[], int j, StringBuilder stringbuilder)
    {
        if (i == 901)
        {
            int i2 = 0;
            long l2 = 0L;
            char ac1[] = new char[6];
            int ai1[] = new int[6];
            boolean flag1 = false;
            int j2 = j + 1;
            int k2 = ai[j];
            for (int i3 = j2; i3 < ai[0] && !flag1;)
            {
                int l3 = i2 + 1;
                ai1[i2] = k2;
                l2 = l2 * 900L + (long)k2;
                int i4 = i3 + 1;
                k2 = ai[i3];
                int k;
                long l;
                boolean flag;
                int i1;
                int j1;
                char ac[];
                int k1;
                long l1;
                int j3;
                int k3;
                if (k2 == 900 || k2 == 901 || k2 == 902 || k2 == 924 || k2 == 928 || k2 == 923 || k2 == 922)
                {
                    int j4 = i4 - 1;
                    flag1 = true;
                    i3 = j4;
                    i2 = l3;
                } else
                if (l3 % 5 == 0 && l3 > 0)
                {
                    for (int k4 = 0; k4 < 6;)
                    {
                        ac1[5 - k4] = (char)(int)(l2 % 256L);
                        long l4 = l2 >> 8;
                        k4++;
                        l2 = l4;
                    }

                    stringbuilder.append(ac1);
                    i3 = i4;
                    i2 = 0;
                } else
                {
                    i2 = l3;
                    i3 = i4;
                }
            }

            if (i3 == ai[0] && k2 < 900)
            {
                k3 = i2 + 1;
                ai1[i2] = k2;
                i2 = k3;
            }
            for (j3 = 0; j3 < i2; j3++)
            {
                stringbuilder.append((char)ai1[j3]);
            }

            j = i3;
        } else
        if (i == 924)
        {
            k = 0;
            l = 0L;
            flag = false;
            while (j < ai[0] && !flag) 
            {
                i1 = j + 1;
                j1 = ai[j];
                if (j1 < 900)
                {
                    k++;
                    l = l * 900L + (long)j1;
                    j = i1;
                } else
                if (j1 == 900 || j1 == 901 || j1 == 902 || j1 == 924 || j1 == 928 || j1 == 923 || j1 == 922)
                {
                    j = i1 - 1;
                    flag = true;
                } else
                {
                    j = i1;
                }
                if (k % 5 == 0 && k > 0)
                {
                    ac = new char[6];
                    for (k1 = 0; k1 < 6;)
                    {
                        ac[5 - k1] = (char)(int)(255L & l);
                        l1 = l >> 8;
                        k1++;
                        l = l1;
                    }

                    stringbuilder.append(ac);
                    k = 0;
                }
            }
        }
        return j;
    }

    private static int a(int ai[], int i, StringBuilder stringbuilder)
    {
        int ai1[] = new int[ai[0] << 1];
        int ai2[] = new int[ai[0] << 1];
        boolean flag = false;
        int j = 0;
label0:
        do
        {
            while (i < ai[0] && !flag) 
            {
                int k = i + 1;
                int l = ai[i];
                if (l < 900)
                {
                    ai1[j] = l / 30;
                    ai1[j + 1] = l % 30;
                    j += 2;
                    i = k;
                } else
                {
                    switch (l)
                    {
                    default:
                        i = k;
                        break;

                    case 900: 
                        int i1 = j + 1;
                        ai1[j] = 900;
                        j = i1;
                        i = k;
                        break;

                    case 901: 
                        i = k - 1;
                        flag = true;
                        break;

                    case 902: 
                        i = k - 1;
                        flag = true;
                        break;

                    case 913: 
                        ai1[j] = 913;
                        i = k + 1;
                        ai2[j] = ai[k];
                        j++;
                        break;

                    case 924: 
                        i = k - 1;
                        flag = true;
                        break;
                    }
                    continue label0;
                }
            }
            a(ai1, ai2, j, stringbuilder);
            return i;
        } while (true);
    }

    private static String a(int ai[], int i)
    {
        BigInteger biginteger = BigInteger.ZERO;
        for (int j = 0; j < i; j++)
        {
            biginteger = biginteger.add(c[-1 + (i - j)].multiply(BigInteger.valueOf(ai[j])));
        }

        String s = biginteger.toString();
        if (s.charAt(0) != '1')
        {
            throw f.a();
        } else
        {
            return s.substring(1);
        }
    }

    static e a(int ai[])
    {
        StringBuilder stringbuilder;
        int i;
        int j;
        stringbuilder = new StringBuilder(100);
        i = 2;
        j = ai[1];
_L7:
        if (i >= ai[0])
        {
            break MISSING_BLOCK_LABEL_168;
        }
        j;
        JVM INSTR lookupswitch 5: default 76
    //                   900: 106
    //                   901: 117
    //                   902: 129
    //                   913: 140
    //                   924: 152;
           goto _L1 _L2 _L3 _L4 _L5 _L6
_L1:
        int k = a(ai, i - 1, stringbuilder);
_L8:
        if (k < ai.length)
        {
            i = k + 1;
            j = ai[k];
        } else
        {
            throw f.a();
        }
        if (true) goto _L7; else goto _L2
_L2:
        k = a(ai, i, stringbuilder);
          goto _L8
_L3:
        k = a(j, ai, i, stringbuilder);
          goto _L8
_L4:
        k = b(ai, i, stringbuilder);
          goto _L8
_L5:
        k = a(j, ai, i, stringbuilder);
          goto _L8
_L6:
        k = a(j, ai, i, stringbuilder);
          goto _L8
        if (stringbuilder.length() == 0)
        {
            throw f.a();
        } else
        {
            return new e(null, stringbuilder.toString(), null, null);
        }
    }

    private static void a(int ai[], int ai1[], int i, StringBuilder stringbuilder)
    {
        d d1;
        d d2;
        int j;
        d1 = d.a;
        d2 = d.a;
        j = 0;
_L10:
        if (j >= i) goto _L2; else goto _L1
_L1:
        int k;
        int l;
        char c1;
        k = ai[j];
        l = c.a[d1.ordinal()];
        c1 = '\0';
        l;
        JVM INSTR tableswitch 1 6: default 80
    //                   1 98
    //                   2 242
    //                   3 398
    //                   4 560
    //                   5 642
    //                   6 701;
           goto _L3 _L4 _L5 _L6 _L7 _L8 _L9
_L3:
        if (c1 != 0)
        {
            stringbuilder.append(c1);
        }
        j++;
          goto _L10
_L4:
        if (k < 26)
        {
            c1 = (char)(k + 65);
        } else
        if (k == 26)
        {
            c1 = ' ';
        } else
        if (k == 27)
        {
            d1 = d.b;
            c1 = '\0';
        } else
        if (k == 28)
        {
            d1 = d.c;
            c1 = '\0';
        } else
        if (k == 29)
        {
            d d9 = ps.hacking.zxing.f.a.d.f;
            d d10 = d1;
            d1 = d9;
            d2 = d10;
            c1 = '\0';
        } else
        if (k == 913)
        {
            stringbuilder.append((char)ai1[j]);
            c1 = '\0';
        } else
        {
            c1 = '\0';
            if (k == 900)
            {
                d1 = d.a;
                c1 = '\0';
            }
        }
          goto _L3
_L5:
        if (k < 26)
        {
            c1 = (char)(k + 97);
        } else
        if (k == 26)
        {
            c1 = ' ';
        } else
        if (k == 27)
        {
            d d7 = ps.hacking.zxing.f.a.d.e;
            d d8 = d1;
            d1 = d7;
            d2 = d8;
            c1 = '\0';
        } else
        if (k == 28)
        {
            d1 = d.c;
            c1 = '\0';
        } else
        if (k == 29)
        {
            d d5 = ps.hacking.zxing.f.a.d.f;
            d d6 = d1;
            d1 = d5;
            d2 = d6;
            c1 = '\0';
        } else
        if (k == 913)
        {
            stringbuilder.append((char)ai1[j]);
            c1 = '\0';
        } else
        {
            c1 = '\0';
            if (k == 900)
            {
                d1 = d.a;
                c1 = '\0';
            }
        }
          goto _L3
_L6:
        if (k < 25)
        {
            c1 = b[k];
        } else
        if (k == 25)
        {
            d1 = d.d;
            c1 = '\0';
        } else
        if (k == 26)
        {
            c1 = ' ';
        } else
        if (k == 27)
        {
            d1 = d.b;
            c1 = '\0';
        } else
        if (k == 28)
        {
            d1 = d.a;
            c1 = '\0';
        } else
        if (k == 29)
        {
            d d3 = ps.hacking.zxing.f.a.d.f;
            d d4 = d1;
            d1 = d3;
            d2 = d4;
            c1 = '\0';
        } else
        if (k == 913)
        {
            stringbuilder.append((char)ai1[j]);
            c1 = '\0';
        } else
        {
            c1 = '\0';
            if (k == 900)
            {
                d1 = d.a;
                c1 = '\0';
            }
        }
          goto _L3
_L7:
        if (k < 29)
        {
            c1 = a[k];
        } else
        if (k == 29)
        {
            d1 = d.a;
            c1 = '\0';
        } else
        if (k == 913)
        {
            stringbuilder.append((char)ai1[j]);
            c1 = '\0';
        } else
        {
            c1 = '\0';
            if (k == 900)
            {
                d1 = d.a;
                c1 = '\0';
            }
        }
          goto _L3
_L8:
        if (k < 26)
        {
            c1 = (char)(k + 65);
            d1 = d2;
        } else
        if (k == 26)
        {
            c1 = ' ';
            d1 = d2;
        } else
        {
            if (k != 900)
            {
                break MISSING_BLOCK_LABEL_789;
            }
            d1 = d.a;
            c1 = '\0';
        }
          goto _L3
_L9:
        if (k < 29)
        {
            c1 = a[k];
            d1 = d2;
        } else
        if (k == 29)
        {
            d1 = d.a;
            c1 = '\0';
        } else
        if (k == 913)
        {
            stringbuilder.append((char)ai1[j]);
            d1 = d2;
            c1 = '\0';
        } else
        {
            if (k != 900)
            {
                break MISSING_BLOCK_LABEL_789;
            }
            d1 = d.a;
            c1 = '\0';
        }
          goto _L3
_L2:
        return;
        d1 = d2;
        c1 = '\0';
          goto _L3
    }

    private static int b(int ai[], int i, StringBuilder stringbuilder)
    {
        int ai1[] = new int[15];
        boolean flag = false;
        int j = 0;
        do
        {
            if (i >= ai[0] || flag)
            {
                break;
            }
            int k = i + 1;
            int l = ai[i];
            if (k == ai[0])
            {
                flag = true;
            }
            if (l < 900)
            {
                ai1[j] = l;
                j++;
                i = k;
            } else
            if (l == 900 || l == 901 || l == 924 || l == 928 || l == 923 || l == 922)
            {
                i = k - 1;
                flag = true;
            } else
            {
                i = k;
            }
            if (j % 15 == 0 || l == 902 || flag)
            {
                stringbuilder.append(a(ai1, j));
                j = 0;
            }
        } while (true);
        return i;
    }

    static 
    {
        c = new BigInteger[16];
        c[0] = BigInteger.ONE;
        BigInteger biginteger = BigInteger.valueOf(900L);
        c[1] = biginteger;
        for (int i = 2; i < c.length; i++)
        {
            c[i] = c[i - 1].multiply(biginteger);
        }

    }
}
