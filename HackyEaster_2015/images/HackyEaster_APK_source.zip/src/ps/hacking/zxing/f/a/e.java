// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.f.a;

import ps.hacking.zxing.b.b;
import ps.hacking.zxing.d;
import ps.hacking.zxing.f;
import ps.hacking.zxing.f.a.a.a;

// Referenced classes of package ps.hacking.zxing.f.a:
//            a, b

public final class e
{

    private final a a = new a();

    public e()
    {
    }

    private static void a(int ai[], int i)
    {
label0:
        {
            if (ai.length < 4)
            {
                throw f.a();
            }
            int j = ai[0];
            if (j > ai.length)
            {
                throw f.a();
            }
            if (j == 0)
            {
                if (i >= ai.length)
                {
                    break label0;
                }
                ai[0] = ai.length - i;
            }
            return;
        }
        throw f.a();
    }

    private void a(int ai[], int ai1[], int i)
    {
        if (ai1.length > 3 + i / 2 || i < 0 || i > 512)
        {
            throw d.a();
        } else
        {
            a.a(ai, i, ai1);
            return;
        }
    }

    public ps.hacking.zxing.b.e a(b b1)
    {
        ps.hacking.zxing.f.a.a a1 = new ps.hacking.zxing.f.a.a(b1);
        int ai[] = a1.();
        if (ai.length == 0)
        {
            throw f.a();
        } else
        {
            int i = 1 << 1 + a1.c();
            a(ai, a1.b(), i);
            a(ai, i);
            return ps.hacking.zxing.f.a.b.a(ai);
        }
    }
}
