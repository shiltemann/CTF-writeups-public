// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.f.b;

import java.util.Arrays;
import java.util.Map;
import ps.hacking.zxing.b.b;
import ps.hacking.zxing.b.g;
import ps.hacking.zxing.b.i;
import ps.hacking.zxing.c;
import ps.hacking.zxing.e;
import ps.hacking.zxing.o;

public final class a
{

    private static final int a[] = {
        8, 1, 1, 1, 1, 1, 1, 3
    };
    private static final int b[] = {
        3, 1, 1, 1, 1, 1, 1, 8
    };
    private static final int c[] = {
        7, 1, 1, 3, 1, 1, 1, 2, 1
    };
    private static final int d[] = {
        1, 2, 1, 1, 1, 3, 1, 1, 7
    };
    private final c e;

    public a(c c1)
    {
        e = c1;
    }

    private static float a(o ao[])
    {
        return ((o.a(ao[0], ao[4]) + o.a(ao[1], ao[5])) / 34F + (o.a(ao[6], ao[2]) + o.a(ao[7], ao[3])) / 36F) / 2.0F;
    }

    private static int a(o o1, o o2, o o3, o o4, float f)
    {
        return 17 * ((8 + (ps.hacking.zxing.b.a.a.a(o.a(o1, o2) / f) + ps.hacking.zxing.b.a.a.a(o.a(o3, o4) / f) >> 1)) / 17);
    }

    private static int a(int ai[], int ai1[], int j)
    {
        int k;
        int i1;
        int j1;
        k = ai.length;
        int l = 0;
        i1 = 0;
        j1 = 0;
        for (; l < k; l++)
        {
            j1 += ai[l];
            i1 += ai1[l];
        }

        if (j1 >= i1) goto _L2; else goto _L1
_L1:
        return 0x7fffffff;
_L2:
        int j2;
        int k1 = (j1 << 8) / i1;
        int l1 = j * k1 >> 8;
        int i2 = 0;
        j2 = 0;
        do
        {
label0:
            {
                if (i2 >= k)
                {
                    break label0;
                }
                int k2 = ai[i2] << 8;
                int l2 = k1 * ai1[i2];
                int i3;
                if (k2 > l2)
                {
                    i3 = k2 - l2;
                } else
                {
                    i3 = l2 - k2;
                }
                if (i3 > l1)
                {
                    continue; /* Loop/switch isn't completed */
                }
                j2 += i3;
                i2++;
            }
        } while (true);
        if (true) goto _L1; else goto _L3
_L3:
        return j2 / j1;
    }

    private static b a(b b1, o o1, o o2, o o3, o o4, int j, int k)
    {
        return i.a().a(b1, j, k, 0.0F, 0.0F, j, 0.0F, j, k, 0.0F, k, o1.a(), o1.b(), o3.a(), o3.b(), o4.a(), o4.b(), o2.a(), o2.b());
    }

    private static void a(o ao[], boolean flag)
    {
        float f;
        float f1;
        float f2;
        float f3;
        float f4;
        float f5;
        float f6;
        float f7;
        float f8;
        f = ao[0].a();
        f1 = ao[0].b();
        f2 = ao[2].a();
        f3 = ao[2].b();
        f4 = ao[4].a();
        f5 = ao[4].b();
        f6 = ao[6].a();
        f7 = ao[6].b();
        f8 = f5 - f7;
        if (flag)
        {
            f8 = -f8;
        }
        if (f8 <= 3F) goto _L2; else goto _L1
_L1:
        float f30 = f6 - f;
        float f31 = f7 - f1;
        float f32 = f30 * f30 + f31 * f31;
        float f33 = (f30 * (f4 - f)) / f32;
        ao[4] = new o(f + f30 * f33, f1 + f33 * f31);
_L8:
        float f13;
        float f14;
        float f15;
        float f16;
        float f17;
        float f18;
        float f19;
        float f20;
        float f21;
        f13 = ao[1].a();
        f14 = ao[1].b();
        f15 = ao[3].a();
        f16 = ao[3].b();
        f17 = ao[5].a();
        f18 = ao[5].b();
        f19 = ao[7].a();
        f20 = ao[7].b();
        f21 = f20 - f18;
        if (flag)
        {
            f21 = -f21;
        }
        if (f21 <= 3F) goto _L4; else goto _L3
_L3:
        float f26 = f19 - f13;
        float f27 = f20 - f14;
        float f28 = f26 * f26 + f27 * f27;
        float f29 = (f26 * (f17 - f13)) / f28;
        ao[5] = new o(f13 + f26 * f29, f14 + f29 * f27);
_L6:
        return;
_L2:
        if (-f8 > 3F)
        {
            float f9 = f2 - f4;
            float f10 = f3 - f5;
            float f11 = f9 * f9 + f10 * f10;
            float f12 = (f9 * (f2 - f6)) / f11;
            ao[6] = new o(f2 - f9 * f12, f3 - f10 * f12);
        }
        continue; /* Loop/switch isn't completed */
_L4:
        if (-f21 <= 3F) goto _L6; else goto _L5
_L5:
        float f22 = f15 - f17;
        float f23 = f16 - f18;
        float f24 = f22 * f22 + f23 * f23;
        float f25 = (f22 * (f15 - f19)) / f24;
        ao[7] = new o(f15 - f22 * f25, f16 - f23 * f25);
        return;
        if (true) goto _L8; else goto _L7
_L7:
    }

    private static int[] a(b b1, int j, int k, int l, boolean flag, int ai[], int ai1[])
    {
        Arrays.fill(ai1, 0, ai1.length, 0);
        int i1 = ai.length;
        int j1 = 0;
        int k1 = j;
        int l1 = j;
        boolean flag1 = flag;
        while (k1 < j + l) 
        {
            if (flag1 ^ b1.a(k1, k))
            {
                ai1[j1] = 1 + ai1[j1];
            } else
            {
                if (j1 == i1 - 1)
                {
                    if (a(ai1, ai, 204) < 107)
                    {
                        return (new int[] {
                            l1, k1
                        });
                    }
                    l1 += ai1[0] + ai1[1];
                    System.arraycopy(ai1, 2, ai1, 0, i1 - 2);
                    ai1[i1 - 2] = 0;
                    ai1[i1 - 1] = 0;
                    j1--;
                } else
                {
                    j1++;
                }
                ai1[j1] = 1;
                if (!flag1)
                {
                    flag1 = true;
                } else
                {
                    flag1 = false;
                }
            }
            k1++;
        }
        return null;
    }

    private static o[] a(b b1, boolean flag)
    {
        int j;
        int i1;
        int j1;
        int k1;
        int l1;
        int i2;
        int j2;
        j = 1;
        int k = b1.e();
        int l = b1.d();
        o ao[] = new o[8];
        int ai[] = new int[a.length];
        byte byte0;
        int ai1[];
        int ai2[];
        int ai3[];
        int ai4[];
        int ai5[];
        if (flag)
        {
            byte0 = 9;
        } else
        {
            byte0 = 7;
        }
        i1 = Math.max(j, k >> byte0);
        j1 = 0;
_L21:
        if (j1 >= k)
        {
            break MISSING_BLOCK_LABEL_437;
        }
        ai5 = a(b1, 0, j1, l, false, a, ai);
        if (ai5 == null) goto _L2; else goto _L1
_L1:
        ao[0] = new o(ai5[0], j1);
        ao[4] = new o(ai5[j], j1);
        k1 = j;
_L26:
        if (k1 == 0) goto _L4; else goto _L3
_L3:
        j2 = k - 1;
_L22:
        if (j2 <= 0) goto _L6; else goto _L5
_L5:
        ai4 = a(b1, 0, j2, l, false, a, ai);
        if (ai4 == null) goto _L8; else goto _L7
_L7:
        ao[j] = new o(ai4[0], j2);
        ao[5] = new o(ai4[j], j2);
        k1 = j;
_L4:
        ai1 = new int[c.length];
        if (k1 == 0) goto _L10; else goto _L9
_L9:
        i2 = 0;
_L23:
        if (i2 >= k) goto _L12; else goto _L11
_L11:
        ai3 = a(b1, 0, i2, l, false, c, ai1);
        if (ai3 == null) goto _L14; else goto _L13
_L13:
        ao[2] = new o(ai3[j], i2);
        ao[6] = new o(ai3[0], i2);
        k1 = j;
_L10:
        if (k1 == 0) goto _L16; else goto _L15
_L15:
        l1 = k - 1;
_L24:
        if (l1 <= 0) goto _L18; else goto _L17
_L17:
        ai2 = a(b1, 0, l1, l, false, c, ai1);
        if (ai2 == null) goto _L20; else goto _L19
_L19:
        ao[3] = new o(ai2[j], l1);
        ao[7] = new o(ai2[0], l1);
_L25:
        if (j != 0)
        {
            return ao;
        } else
        {
            return null;
        }
_L2:
        j1 += i1;
          goto _L21
_L8:
        j2 -= i1;
          goto _L22
_L14:
        i2 += i1;
          goto _L23
_L20:
        l1 -= i1;
          goto _L24
_L18:
        j = 0;
          goto _L25
_L16:
        j = k1;
          goto _L25
_L12:
        k1 = 0;
          goto _L10
_L6:
        k1 = 0;
          goto _L4
        k1 = 0;
          goto _L26
    }

    private static int b(o o1, o o2, o o3, o o4, float f)
    {
        return ps.hacking.zxing.b.a.a.a(o.a(o1, o3) / f) + ps.hacking.zxing.b.a.a.a(o.a(o2, o4) / f) >> 1;
    }

    private static o[] b(b b1, boolean flag)
    {
        int l;
        int i1;
        boolean flag1;
        int j1;
        int k1;
        int l1;
        int j = b1.e();
        int k = b1.d() >> 1;
        o ao[] = new o[8];
        int ai[] = new int[b.length];
        byte byte0;
        int ai1[];
        int ai2[];
        int ai3[];
        int ai4[];
        int ai5[];
        if (flag)
        {
            byte0 = 9;
        } else
        {
            byte0 = 7;
        }
        l = Math.max(1, j >> byte0);
        i1 = j - 1;
_L19:
        if (i1 <= 0)
        {
            break MISSING_BLOCK_LABEL_425;
        }
        ai5 = a(b1, k, i1, k, true, b, ai);
        if (ai5 == null) goto _L2; else goto _L1
_L1:
        ao[0] = new o(ai5[1], i1);
        ao[4] = new o(ai5[0], i1);
        flag1 = true;
_L23:
        if (!flag1) goto _L4; else goto _L3
_L3:
        l1 = 0;
_L20:
        if (l1 >= j) goto _L6; else goto _L5
_L5:
        ai4 = a(b1, k, l1, k, true, b, ai);
        if (ai4 == null) goto _L8; else goto _L7
_L7:
        ao[1] = new o(ai4[1], l1);
        ao[5] = new o(ai4[0], l1);
        flag1 = true;
_L4:
        ai1 = new int[d.length];
        if (!flag1) goto _L10; else goto _L9
_L9:
        k1 = j - 1;
_L21:
        flag1 = false;
        if (k1 <= 0) goto _L10; else goto _L11
_L11:
        ai3 = a(b1, 0, k1, k, false, d, ai1);
        if (ai3 == null) goto _L13; else goto _L12
_L12:
        ao[2] = new o(ai3[0], k1);
        ao[6] = new o(ai3[1], k1);
        flag1 = true;
_L10:
        if (!flag1) goto _L15; else goto _L14
_L14:
        j1 = 0;
_L22:
        flag1 = false;
        if (j1 >= j) goto _L15; else goto _L16
_L16:
        ai2 = a(b1, 0, j1, k, false, d, ai1);
        if (ai2 == null) goto _L18; else goto _L17
_L17:
        ao[3] = new o(ai2[0], j1);
        ao[7] = new o(ai2[1], j1);
        flag1 = true;
_L15:
        if (flag1)
        {
            return ao;
        } else
        {
            return null;
        }
_L2:
        i1 -= l;
          goto _L19
_L8:
        l1 += l;
          goto _L20
_L13:
        k1 -= l;
          goto _L21
_L18:
        j1 += l;
          goto _L22
_L6:
        flag1 = false;
          goto _L4
        flag1 = false;
          goto _L23
    }

    public g a()
    {
        return a(((Map) (null)));
    }

    public g a(Map map)
    {
        b b1 = e.c();
        boolean flag;
        o ao[];
        if (map != null && map.containsKey(e.d))
        {
            flag = true;
        } else
        {
            flag = false;
        }
        ao = a(b1, flag);
        if (ao == null)
        {
            o ao3[] = b(b1, flag);
            o ao1[];
            float f;
            int j;
            int k;
            b b2;
            o ao2[];
            if (ao3 != null)
            {
                a(ao3, true);
                ao1 = ao3;
            } else
            {
                ao1 = ao3;
            }
        } else
        {
            a(ao, false);
            ao1 = ao;
        }
        if (ao1 == null)
        {
            throw ps.hacking.zxing.i.a();
        }
        f = a(ao1);
        if (f < 1.0F)
        {
            throw ps.hacking.zxing.i.a();
        }
        j = a(ao1[4], ao1[6], ao1[5], ao1[7], f);
        if (j < 1)
        {
            throw ps.hacking.zxing.i.a();
        }
        k = b(ao1[4], ao1[6], ao1[5], ao1[7], f);
        if (k <= j)
        {
            k = j;
        }
        b2 = a(b1, ao1[4], ao1[5], ao1[6], ao1[7], j, k);
        ao2 = new o[4];
        ao2[0] = ao1[5];
        ao2[1] = ao1[4];
        ao2[2] = ao1[6];
        ao2[3] = ao1[7];
        return new g(b2, ao2);
    }

}
