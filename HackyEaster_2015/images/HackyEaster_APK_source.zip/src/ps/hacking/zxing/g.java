// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing;


public abstract class g
{

    private final int a;
    private final int b;

    protected g(int i, int j)
    {
        a = i;
        b = j;
    }

    public abstract byte[] a();

    public abstract byte[] a(int i, byte abyte0[]);

    public final int b()
    {
        return a;
    }

    public final int c()
    {
        return b;
    }

    public boolean d()
    {
        return false;
    }

    public g e()
    {
        throw new UnsupportedOperationException("This luminance source does not support rotation by 90 degrees.");
    }

    public final String toString()
    {
        byte abyte0[] = new byte[a];
        StringBuilder stringbuilder = new StringBuilder(b * (1 + a));
        byte abyte1[] = abyte0;
        for (int i = 0; i < b; i++)
        {
            abyte1 = a(i, abyte1);
            int j = 0;
            while (j < a) 
            {
                int k = 0xff & abyte1[j];
                char c1;
                if (k < 64)
                {
                    c1 = '#';
                } else
                if (k < 128)
                {
                    c1 = '+';
                } else
                if (k < 192)
                {
                    c1 = '.';
                } else
                {
                    c1 = ' ';
                }
                stringbuilder.append(c1);
                j++;
            }
            stringbuilder.append('\n');
        }

        return stringbuilder.toString();
    }
}
