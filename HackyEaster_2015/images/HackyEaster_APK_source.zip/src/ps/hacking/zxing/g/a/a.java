// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.g.a;

import ps.hacking.zxing.b.b;
import ps.hacking.zxing.f;

// Referenced classes of package ps.hacking.zxing.g.a:
//            p, r, c

final class a
{

    private final b a;
    private r b;
    private p c;

    a(b b1)
    {
        int i = b1.e();
        if (i < 21 || (i & 3) != 1)
        {
            throw f.a();
        } else
        {
            a = b1;
            return;
        }
    }

    private int a(int i, int j, int k)
    {
        if (a.a(i, j))
        {
            return 1 | k << 1;
        } else
        {
            return k << 1;
        }
    }

    p a()
    {
        int i = 0;
        if (c != null)
        {
            return c;
        }
        int j = 0;
        int k = 0;
        for (; j < 6; j++)
        {
            k = a(j, 8, k);
        }

        int l = a(8, 7, a(8, 8, a(7, 8, k)));
        for (int i1 = 5; i1 >= 0; i1--)
        {
            l = a(8, i1, l);
        }

        int j1 = a.e();
        int k1 = j1 - 7;
        for (int l1 = j1 - 1; l1 >= k1; l1--)
        {
            i = a(8, l1, i);
        }

        for (int i2 = j1 - 8; i2 < j1; i2++)
        {
            i = a(i2, 8, i);
        }

        c = ps.hacking.zxing.g.a.p.b(l, i);
        if (c != null)
        {
            return c;
        } else
        {
            throw f.a();
        }
    }

    r b()
    {
        if (b != null)
        {
            return b;
        }
        int i = a.e();
        int j = i - 17 >> 2;
        if (j <= 6)
        {
            return ps.hacking.zxing.g.a.r.b(j);
        }
        int k = i - 11;
        int l = 5;
        int i1 = 0;
        for (; l >= 0; l--)
        {
            for (int i2 = i - 9; i2 >= k; i2--)
            {
                i1 = a(i2, l, i1);
            }

        }

        r r1 = r.c(i1);
        if (r1 != null && r1.d() == i)
        {
            b = r1;
            return r1;
        }
        int j1 = 0;
        for (int k1 = 5; k1 >= 0; k1--)
        {
            for (int l1 = i - 9; l1 >= k; l1--)
            {
                j1 = a(k1, l1, j1);
            }

        }

        r r2 = r.c(j1);
        if (r2 != null && r2.d() == i)
        {
            b = r2;
            return r2;
        } else
        {
            throw f.a();
        }
    }

    byte[] c()
    {
        p p1 = a();
        r r1 = b();
        c c1 = ps.hacking.zxing.g.a.c.a(p1.b());
        int i = a.e();
        c1.a(a, i);
        b b1 = r1.e();
        byte abyte0[] = new byte[r1.c()];
        int j = i - 1;
        int k = 0;
        int l = 0;
        int i1 = 0;
        boolean flag1;
        for (boolean flag = true; j > 0; flag = flag1)
        {
            if (j == 6)
            {
                j--;
            }
            int k1;
            for (int j1 = 0; j1 < i; j1++)
            {
                int l1;
                if (flag)
                {
                    k1 = i - 1 - j1;
                } else
                {
                    k1 = j1;
                }
                for (l1 = 0; l1 < 2; l1++)
                {
                    if (b1.a(j - l1, k1))
                    {
                        continue;
                    }
                    k++;
                    l <<= 1;
                    if (a.a(j - l1, k1))
                    {
                        l |= 1;
                    }
                    if (k == 8)
                    {
                        int i2 = i1 + 1;
                        abyte0[i1] = (byte)l;
                        l = 0;
                        i1 = i2;
                        k = 0;
                    }
                }

            }

            flag1 = flag ^ true;
            j -= 2;
        }

        if (i1 != r1.c())
        {
            throw f.a();
        } else
        {
            return abyte0;
        }
    }
}
