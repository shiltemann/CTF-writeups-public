// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.g.a;


// Referenced classes of package ps.hacking.zxing.g.a:
//            c, d

final class e extends c
{

    private e()
    {
        super(null);
    }

    e(d d)
    {
        this();
    }

    boolean a(int i, int j)
    {
        return (1 & i + j) == 0;
    }
}
