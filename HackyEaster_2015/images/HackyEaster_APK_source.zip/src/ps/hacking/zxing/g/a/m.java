// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.g.a;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import ps.hacking.zxing.b.c;
import ps.hacking.zxing.b.d;
import ps.hacking.zxing.b.e;
import ps.hacking.zxing.b.l;
import ps.hacking.zxing.f;

// Referenced classes of package ps.hacking.zxing.g.a:
//            q, o, r

final class m
{

    private static final char a[] = {
        '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 
        'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 
        'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 
        'U', 'V', 'W', 'X', 'Y', 'Z', ' ', '$', '%', '*', 
        '+', '-', '.', '/', ':'
    };

    private static char a(int i)
    {
        if (i >= a.length)
        {
            throw f.a();
        } else
        {
            return a[i];
        }
    }

    private static int a(c c1)
    {
        int i = c1.a(8);
        if ((i & 0x80) == 0)
        {
            return i & 0x7f;
        }
        if ((i & 0xc0) == 128)
        {
            return c1.a(8) | (i & 0x3f) << 8;
        }
        if ((i & 0xe0) == 192)
        {
            return c1.a(16) | (i & 0x1f) << 16;
        } else
        {
            throw f.a();
        }
    }

    static e a(byte abyte0[], r r, o o1, Map map)
    {
        c c1 = new c(abyte0);
        StringBuilder stringbuilder = new StringBuilder(50);
        boolean flag = false;
        ArrayList arraylist = new ArrayList(1);
        d d1 = null;
        do
        {
            q q2;
            boolean flag1;
            if (c1.c() < 4)
            {
                q2 = q.a;
            } else
            {
                q q1;
                try
                {
                    q1 = q.a(c1.a(4));
                }
                catch (IllegalArgumentException illegalargumentexception)
                {
                    throw f.a();
                }
                q2 = q1;
            }
            if (q2 != q.a)
            {
                if (q2 == q.h || q2 == q.i)
                {
                    flag1 = true;
                } else
                if (q2 == ps.hacking.zxing.g.a.q.d)
                {
                    if (c1.c() < 16)
                    {
                        throw f.a();
                    }
                    c1.a(16);
                    flag1 = flag;
                } else
                if (q2 == ps.hacking.zxing.g.a.q.f)
                {
                    d1 = d.a(a(c1));
                    if (d1 == null)
                    {
                        throw f.a();
                    }
                    flag1 = flag;
                } else
                if (q2 == q.j)
                {
                    int j = c1.a(4);
                    int k = c1.a(q2.a(r));
                    if (j == 1)
                    {
                        a(c1, stringbuilder, k);
                    }
                    flag1 = flag;
                } else
                {
                    int i = c1.a(q2.a(r));
                    if (q2 == q.b)
                    {
                        c(c1, stringbuilder, i);
                        flag1 = flag;
                    } else
                    if (q2 == ps.hacking.zxing.g.a.q.c)
                    {
                        a(c1, stringbuilder, i, flag);
                        flag1 = flag;
                    } else
                    if (q2 == ps.hacking.zxing.g.a.q.e)
                    {
                        a(c1, stringbuilder, i, d1, ((Collection) (arraylist)), map);
                        flag1 = flag;
                    } else
                    if (q2 == q.g)
                    {
                        b(c1, stringbuilder, i);
                        flag1 = flag;
                    } else
                    {
                        throw f.a();
                    }
                }
            } else
            {
                flag1 = flag;
            }
            if (q2 == q.a)
            {
                String s = stringbuilder.toString();
                if (arraylist.isEmpty())
                {
                    arraylist = null;
                }
                String s1 = null;
                if (o1 != null)
                {
                    s1 = o1.toString();
                }
                return new e(abyte0, s, arraylist, s1);
            }
            flag = flag1;
        } while (true);
    }

    private static void a(c c1, StringBuilder stringbuilder, int i)
    {
        if (i * 13 > c1.c())
        {
            throw f.a();
        }
        byte abyte0[] = new byte[i * 2];
        int j = 0;
        while (i > 0) 
        {
            int k = c1.a(13);
            int i1 = k / 96 << 8 | k % 96;
            int j1;
            int k1;
            if (i1 < 959)
            {
                j1 = i1 + 41377;
            } else
            {
                j1 = i1 + 42657;
            }
            abyte0[j] = (byte)(0xff & j1 >> 8);
            abyte0[j + 1] = (byte)(j1 & 0xff);
            k1 = j + 2;
            i--;
            j = k1;
        }
        try
        {
            stringbuilder.append(new String(abyte0, "GB2312"));
            return;
        }
        catch (UnsupportedEncodingException unsupportedencodingexception)
        {
            throw f.a();
        }
    }

    private static void a(c c1, StringBuilder stringbuilder, int i, d d1, Collection collection, Map map)
    {
        if (i << 3 > c1.c())
        {
            throw f.a();
        }
        byte abyte0[] = new byte[i];
        for (int j = 0; j < i; j++)
        {
            abyte0[j] = (byte)c1.a(8);
        }

        String s;
        if (d1 == null)
        {
            s = l.a(abyte0, map);
        } else
        {
            s = d1.name();
        }
        try
        {
            stringbuilder.append(new String(abyte0, s));
        }
        catch (UnsupportedEncodingException unsupportedencodingexception)
        {
            throw f.a();
        }
        collection.add(abyte0);
    }

    private static void a(c c1, StringBuilder stringbuilder, int i, boolean flag)
    {
        int j = stringbuilder.length();
        for (; i > 1; i -= 2)
        {
            if (c1.c() < 11)
            {
                throw f.a();
            }
            int k = c1.a(11);
            stringbuilder.append(a(k / 45));
            stringbuilder.append(a(k % 45));
        }

        if (i == 1)
        {
            if (c1.c() < 6)
            {
                throw f.a();
            }
            stringbuilder.append(a(c1.a(6)));
        }
        if (flag)
        {
            while (j < stringbuilder.length()) 
            {
                if (stringbuilder.charAt(j) == '%')
                {
                    if (j < -1 + stringbuilder.length() && stringbuilder.charAt(j + 1) == '%')
                    {
                        stringbuilder.deleteCharAt(j + 1);
                    } else
                    {
                        stringbuilder.setCharAt(j, '\035');
                    }
                }
                j++;
            }
        }
    }

    private static void b(c c1, StringBuilder stringbuilder, int i)
    {
        if (i * 13 > c1.c())
        {
            throw f.a();
        }
        byte abyte0[] = new byte[i * 2];
        int j = 0;
        while (i > 0) 
        {
            int k = c1.a(13);
            int i1 = k / 192 << 8 | k % 192;
            int j1;
            int k1;
            if (i1 < 7936)
            {
                j1 = i1 + 33088;
            } else
            {
                j1 = i1 + 49472;
            }
            abyte0[j] = (byte)(j1 >> 8);
            abyte0[j + 1] = (byte)j1;
            k1 = j + 2;
            i--;
            j = k1;
        }
        try
        {
            stringbuilder.append(new String(abyte0, "SJIS"));
            return;
        }
        catch (UnsupportedEncodingException unsupportedencodingexception)
        {
            throw f.a();
        }
    }

    private static void c(c c1, StringBuilder stringbuilder, int i)
    {
        for (; i >= 3; i -= 3)
        {
            if (c1.c() < 10)
            {
                throw f.a();
            }
            int i1 = c1.a(10);
            if (i1 >= 1000)
            {
                throw f.a();
            }
            stringbuilder.append(a(i1 / 100));
            stringbuilder.append(a((i1 / 10) % 10));
            stringbuilder.append(a(i1 % 10));
        }

        if (i == 2)
        {
            if (c1.c() < 7)
            {
                throw f.a();
            }
            int k = c1.a(7);
            if (k >= 100)
            {
                throw f.a();
            }
            stringbuilder.append(a(k / 10));
            stringbuilder.append(a(k % 10));
        } else
        if (i == 1)
        {
            if (c1.c() < 4)
            {
                throw f.a();
            }
            int j = c1.a(4);
            if (j >= 10)
            {
                throw f.a();
            } else
            {
                stringbuilder.append(a(j));
                return;
            }
        }
    }

}
