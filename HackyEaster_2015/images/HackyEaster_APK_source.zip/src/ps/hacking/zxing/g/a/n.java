// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.g.a;

import java.util.Map;
import ps.hacking.zxing.b.b;
import ps.hacking.zxing.b.b.a;
import ps.hacking.zxing.b.b.c;
import ps.hacking.zxing.b.b.d;
import ps.hacking.zxing.b.e;

// Referenced classes of package ps.hacking.zxing.g.a:
//            a, p, b, m

public final class n
{

    private final c a;

    public n()
    {
        a = new c(a.e);
    }

    private void a(byte abyte0[], int i)
    {
        int j = 0;
        int k = abyte0.length;
        int ai[] = new int[k];
        for (int l = 0; l < k; l++)
        {
            ai[l] = 0xff & abyte0[l];
        }

        int i1 = abyte0.length - i;
        try
        {
            a.a(ai, i1);
        }
        catch (d d1)
        {
            throw ps.hacking.zxing.d.a();
        }
        for (; j < i; j++)
        {
            abyte0[j] = (byte)ai[j];
        }

    }

    public e a(b b1, Map map)
    {
        ps.hacking.zxing.g.a.a a1 = new ps.hacking.zxing.g.a.a(b1);
        r r = a1.b();
        o o = a1.a().a();
        ps.hacking.zxing.g.a.b ab[] = ps.hacking.zxing.g.a.b.a(a1.c(), r, o);
        int i = ab.length;
        int j = 0;
        int k = 0;
        for (; j < i; j++)
        {
            k += ab[j].a();
        }

        byte abyte0[] = new byte[k];
        int l = ab.length;
        int i1 = 0;
        int l1;
        for (int j1 = 0; i1 < l; j1 = l1)
        {
            ps.hacking.zxing.g.a.b b2 = ab[i1];
            byte abyte1[] = b2.b();
            int k1 = b2.a();
            a(abyte1, k1);
            l1 = j1;
            for (int i2 = 0; i2 < k1;)
            {
                int j2 = l1 + 1;
                abyte0[l1] = abyte1[i2];
                i2++;
                l1 = j2;
            }

            i1++;
        }

        return ps.hacking.zxing.g.a.m.a(abyte0, r, o, map);
    }
}
