// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.g.a;


public final class o extends Enum
{

    public static final o a;
    public static final o b;
    public static final o c;
    public static final o d;
    private static final o e[];
    private static final o g[];
    private final int f;

    private o(String s, int i, int j)
    {
        super(s, i);
        f = j;
    }

    public static o a(int i)
    {
        if (i < 0 || i >= e.length)
        {
            throw new IllegalArgumentException();
        } else
        {
            return e[i];
        }
    }

    public static o valueOf(String s)
    {
        return (o)Enum.valueOf(ps/hacking/zxing/g/a/o, s);
    }

    public static o[] values()
    {
        return (o[])g.clone();
    }

    static 
    {
        a = new o("L", 0, 1);
        b = new o("M", 1, 0);
        c = new o("Q", 2, 3);
        d = new o("H", 3, 2);
        o ao[] = new o[4];
        ao[0] = a;
        ao[1] = b;
        ao[2] = c;
        ao[3] = d;
        g = ao;
        o ao1[] = new o[4];
        ao1[0] = b;
        ao1[1] = a;
        ao1[2] = d;
        ao1[3] = c;
        e = ao1;
    }
}
