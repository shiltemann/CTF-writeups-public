// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.g.a;


// Referenced classes of package ps.hacking.zxing.g.a:
//            o

final class p
{

    private static final int a[][] = {
        {
            21522, 0
        }, {
            20773, 1
        }, {
            24188, 2
        }, {
            23371, 3
        }, {
            17913, 4
        }, {
            16590, 5
        }, {
            20375, 6
        }, {
            19104, 7
        }, {
            30660, 8
        }, {
            29427, 9
        }, {
            32170, 10
        }, {
            30877, 11
        }, {
            26159, 12
        }, {
            25368, 13
        }, {
            27713, 14
        }, {
            26998, 15
        }, {
            5769, 16
        }, {
            5054, 17
        }, {
            7399, 18
        }, {
            6608, 19
        }, {
            1890, 20
        }, {
            597, 21
        }, {
            3340, 22
        }, {
            2107, 23
        }, {
            13663, 24
        }, {
            12392, 25
        }, {
            16177, 26
        }, {
            14854, 27
        }, {
            9396, 28
        }, {
            8579, 29
        }, {
            11994, 30
        }, {
            11245, 31
        }
    };
    private static final int b[] = {
        0, 1, 1, 2, 1, 2, 2, 3, 1, 2, 
        2, 3, 2, 3, 3, 4
    };
    private final o c;
    private final byte d;

    private p(int i)
    {
        c = o.a(3 & i >> 3);
        d = (byte)(i & 7);
    }

    static int a(int i, int j)
    {
        int k = i ^ j;
        return b[k & 0xf] + b[0xf & k >>> 4] + b[0xf & k >>> 8] + b[0xf & k >>> 12] + b[0xf & k >>> 16] + b[0xf & k >>> 20] + b[0xf & k >>> 24] + b[0xf & k >>> 28];
    }

    static p b(int i, int j)
    {
        p p1 = c(i, j);
        if (p1 != null)
        {
            return p1;
        } else
        {
            return c(i ^ 0x5412, j ^ 0x5412);
        }
    }

    private static p c(int i, int j)
    {
        int k;
        int ai[][];
        int l;
        int i1;
        int j1;
        k = 0x7fffffff;
        ai = a;
        l = ai.length;
        i1 = 0;
        j1 = 0;
_L2:
        if (i1 >= l)
        {
            break; /* Loop/switch isn't completed */
        }
        int ai1[] = ai[i1];
        int k1 = ai1[0];
        if (k1 == i || k1 == j)
        {
            return new p(ai1[1]);
        }
        int l1 = a(i, k1);
        int i2;
        int j2;
        int k2;
        if (l1 < k)
        {
            i2 = ai1[1];
        } else
        {
            l1 = k;
            i2 = j1;
        }
        if (i == j)
        {
            break MISSING_BLOCK_LABEL_140;
        }
        j2 = a(j, k1);
        if (j2 >= l1)
        {
            break MISSING_BLOCK_LABEL_140;
        }
        i2 = ai1[1];
_L3:
        i1++;
        k2 = i2;
        k = j2;
        j1 = k2;
        if (true) goto _L2; else goto _L1
_L1:
        if (k <= 3)
        {
            return new p(j1);
        } else
        {
            return null;
        }
        j2 = l1;
          goto _L3
    }

    o a()
    {
        return c;
    }

    byte b()
    {
        return d;
    }

    public boolean equals(Object obj)
    {
        p p1;
        if (obj instanceof p)
        {
            if (c == (p1 = (p)obj).c && d == p1.d)
            {
                return true;
            }
        }
        return false;
    }

    public int hashCode()
    {
        return c.ordinal() << 3 | d;
    }

}
