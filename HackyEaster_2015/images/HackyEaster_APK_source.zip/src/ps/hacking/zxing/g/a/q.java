// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.g.a;


// Referenced classes of package ps.hacking.zxing.g.a:
//            r

public final class q extends Enum
{

    public static final q a;
    public static final q b;
    public static final q c;
    public static final q d;
    public static final q e;
    public static final q f;
    public static final q g;
    public static final q h;
    public static final q i;
    public static final q j;
    private static final q m[];
    private final int k[];
    private final int l;

    private q(String s, int i1, int ai[], int j1)
    {
        super(s, i1);
        k = ai;
        l = j1;
    }

    public static q a(int i1)
    {
        switch (i1)
        {
        case 6: // '\006'
        case 10: // '\n'
        case 11: // '\013'
        case 12: // '\f'
        default:
            throw new IllegalArgumentException();

        case 0: // '\0'
            return a;

        case 1: // '\001'
            return b;

        case 2: // '\002'
            return c;

        case 3: // '\003'
            return d;

        case 4: // '\004'
            return e;

        case 5: // '\005'
            return h;

        case 7: // '\007'
            return f;

        case 8: // '\b'
            return g;

        case 9: // '\t'
            return i;

        case 13: // '\r'
            return j;
        }
    }

    public static q valueOf(String s)
    {
        return (q)Enum.valueOf(ps/hacking/zxing/g/a/q, s);
    }

    public static q[] values()
    {
        return (q[])m.clone();
    }

    public int a(r r1)
    {
        int i1 = r1.a();
        int j1;
        if (i1 <= 9)
        {
            j1 = 0;
        } else
        if (i1 <= 26)
        {
            j1 = 1;
        } else
        {
            j1 = 2;
        }
        return k[j1];
    }

    static 
    {
        a = new q("TERMINATOR", 0, new int[] {
            0, 0, 0
        }, 0);
        b = new q("NUMERIC", 1, new int[] {
            10, 12, 14
        }, 1);
        c = new q("ALPHANUMERIC", 2, new int[] {
            9, 11, 13
        }, 2);
        d = new q("STRUCTURED_APPEND", 3, new int[] {
            0, 0, 0
        }, 3);
        e = new q("BYTE", 4, new int[] {
            8, 16, 16
        }, 4);
        f = new q("ECI", 5, new int[] {
            0, 0, 0
        }, 7);
        g = new q("KANJI", 6, new int[] {
            8, 10, 12
        }, 8);
        h = new q("FNC1_FIRST_POSITION", 7, new int[] {
            0, 0, 0
        }, 5);
        i = new q("FNC1_SECOND_POSITION", 8, new int[] {
            0, 0, 0
        }, 9);
        j = new q("HANZI", 9, new int[] {
            8, 10, 12
        }, 13);
        q aq[] = new q[10];
        aq[0] = a;
        aq[1] = b;
        aq[2] = c;
        aq[3] = d;
        aq[4] = e;
        aq[5] = f;
        aq[6] = g;
        aq[7] = h;
        aq[8] = i;
        aq[9] = j;
        m = aq;
    }
}
