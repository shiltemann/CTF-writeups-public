// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.g.a;

import ps.hacking.zxing.b.b;
import ps.hacking.zxing.f;

// Referenced classes of package ps.hacking.zxing.g.a:
//            t, s, p, o

public final class r
{

    private static final int a[] = {
        31892, 34236, 39577, 42195, 48118, 51042, 55367, 58893, 63784, 0x10b78, 
        0x1145d, 0x12a17, 0x13532, 0x149a6, 0x15683, 0x168c9, 0x177ec, 0x18ec4, 0x191e1, 0x1afab, 
        0x1b08e, 0x1cc1a, 0x1d33f, 0x1ed75, 0x1f250, 0x209d5, 0x216f0, 0x228ba, 0x2379f, 0x24b0b, 
        0x2542e, 0x26a64, 0x27541, 0x28c69
    };
    private static final r b[] = f();
    private final int c;
    private final int d[];
    private final t e[];
    private final int f;

    private transient r(int i, int ai[], t at[])
    {
        int j = 0;
        super();
        c = i;
        d = ai;
        e = at;
        int k = at[0].a();
        s as[] = at[0].b();
        int l = as.length;
        int i1 = 0;
        for (; j < l; j++)
        {
            s s1 = as[j];
            i1 += s1.a() * (k + s1.b());
        }

        f = i1;
    }

    public static r a(int i)
    {
        if (i % 4 != 1)
        {
            throw ps.hacking.zxing.f.a();
        }
        int j = i - 17 >> 2;
        r r1;
        try
        {
            r1 = b(j);
        }
        catch (IllegalArgumentException illegalargumentexception)
        {
            throw ps.hacking.zxing.f.a();
        }
        return r1;
    }

    public static r b(int i)
    {
        if (i < 1 || i > 40)
        {
            throw new IllegalArgumentException();
        } else
        {
            return b[i - 1];
        }
    }

    static r c(int i)
    {
        int j = 0;
        int k = 0x7fffffff;
        int l = 0;
        for (; j < a.length; j++)
        {
            int i1 = a[j];
            if (i1 == i)
            {
                return b(j + 7);
            }
            int j1 = p.a(i, i1);
            if (j1 < k)
            {
                l = j + 7;
                k = j1;
            }
        }

        if (k <= 3)
        {
            return b(l);
        } else
        {
            return null;
        }
    }

    private static r[] f()
    {
        r ar[] = new r[40];
        int ai[] = new int[0];
        t at[] = new t[4];
        s as[] = new s[1];
        as[0] = new s(1, 19);
        at[0] = new t(7, as);
        s as1[] = new s[1];
        as1[0] = new s(1, 16);
        at[1] = new t(10, as1);
        s as2[] = new s[1];
        as2[0] = new s(1, 13);
        at[2] = new t(13, as2);
        s as3[] = new s[1];
        as3[0] = new s(1, 9);
        at[3] = new t(17, as3);
        ar[0] = new r(1, ai, at);
        int ai1[] = {
            6, 18
        };
        t at1[] = new t[4];
        s as4[] = new s[1];
        as4[0] = new s(1, 34);
        at1[0] = new t(10, as4);
        s as5[] = new s[1];
        as5[0] = new s(1, 28);
        at1[1] = new t(16, as5);
        s as6[] = new s[1];
        as6[0] = new s(1, 22);
        at1[2] = new t(22, as6);
        s as7[] = new s[1];
        as7[0] = new s(1, 16);
        at1[3] = new t(28, as7);
        ar[1] = new r(2, ai1, at1);
        int ai2[] = {
            6, 22
        };
        t at2[] = new t[4];
        s as8[] = new s[1];
        as8[0] = new s(1, 55);
        at2[0] = new t(15, as8);
        s as9[] = new s[1];
        as9[0] = new s(1, 44);
        at2[1] = new t(26, as9);
        s as10[] = new s[1];
        as10[0] = new s(2, 17);
        at2[2] = new t(18, as10);
        s as11[] = new s[1];
        as11[0] = new s(2, 13);
        at2[3] = new t(22, as11);
        ar[2] = new r(3, ai2, at2);
        int ai3[] = {
            6, 26
        };
        t at3[] = new t[4];
        s as12[] = new s[1];
        as12[0] = new s(1, 80);
        at3[0] = new t(20, as12);
        s as13[] = new s[1];
        as13[0] = new s(2, 32);
        at3[1] = new t(18, as13);
        s as14[] = new s[1];
        as14[0] = new s(2, 24);
        at3[2] = new t(26, as14);
        s as15[] = new s[1];
        as15[0] = new s(4, 9);
        at3[3] = new t(16, as15);
        ar[3] = new r(4, ai3, at3);
        int ai4[] = {
            6, 30
        };
        t at4[] = new t[4];
        s as16[] = new s[1];
        as16[0] = new s(1, 108);
        at4[0] = new t(26, as16);
        s as17[] = new s[1];
        as17[0] = new s(2, 43);
        at4[1] = new t(24, as17);
        s as18[] = new s[2];
        as18[0] = new s(2, 15);
        as18[1] = new s(2, 16);
        at4[2] = new t(18, as18);
        s as19[] = new s[2];
        as19[0] = new s(2, 11);
        as19[1] = new s(2, 12);
        at4[3] = new t(22, as19);
        ar[4] = new r(5, ai4, at4);
        int ai5[] = {
            6, 34
        };
        t at5[] = new t[4];
        s as20[] = new s[1];
        as20[0] = new s(2, 68);
        at5[0] = new t(18, as20);
        s as21[] = new s[1];
        as21[0] = new s(4, 27);
        at5[1] = new t(16, as21);
        s as22[] = new s[1];
        as22[0] = new s(4, 19);
        at5[2] = new t(24, as22);
        s as23[] = new s[1];
        as23[0] = new s(4, 15);
        at5[3] = new t(28, as23);
        ar[5] = new r(6, ai5, at5);
        int ai6[] = {
            6, 22, 38
        };
        t at6[] = new t[4];
        s as24[] = new s[1];
        as24[0] = new s(2, 78);
        at6[0] = new t(20, as24);
        s as25[] = new s[1];
        as25[0] = new s(4, 31);
        at6[1] = new t(18, as25);
        s as26[] = new s[2];
        as26[0] = new s(2, 14);
        as26[1] = new s(4, 15);
        at6[2] = new t(18, as26);
        s as27[] = new s[2];
        as27[0] = new s(4, 13);
        as27[1] = new s(1, 14);
        at6[3] = new t(26, as27);
        ar[6] = new r(7, ai6, at6);
        int ai7[] = {
            6, 24, 42
        };
        t at7[] = new t[4];
        s as28[] = new s[1];
        as28[0] = new s(2, 97);
        at7[0] = new t(24, as28);
        s as29[] = new s[2];
        as29[0] = new s(2, 38);
        as29[1] = new s(2, 39);
        at7[1] = new t(22, as29);
        s as30[] = new s[2];
        as30[0] = new s(4, 18);
        as30[1] = new s(2, 19);
        at7[2] = new t(22, as30);
        s as31[] = new s[2];
        as31[0] = new s(4, 14);
        as31[1] = new s(2, 15);
        at7[3] = new t(26, as31);
        ar[7] = new r(8, ai7, at7);
        int ai8[] = {
            6, 26, 46
        };
        t at8[] = new t[4];
        s as32[] = new s[1];
        as32[0] = new s(2, 116);
        at8[0] = new t(30, as32);
        s as33[] = new s[2];
        as33[0] = new s(3, 36);
        as33[1] = new s(2, 37);
        at8[1] = new t(22, as33);
        s as34[] = new s[2];
        as34[0] = new s(4, 16);
        as34[1] = new s(4, 17);
        at8[2] = new t(20, as34);
        s as35[] = new s[2];
        as35[0] = new s(4, 12);
        as35[1] = new s(4, 13);
        at8[3] = new t(24, as35);
        ar[8] = new r(9, ai8, at8);
        int ai9[] = {
            6, 28, 50
        };
        t at9[] = new t[4];
        s as36[] = new s[2];
        as36[0] = new s(2, 68);
        as36[1] = new s(2, 69);
        at9[0] = new t(18, as36);
        s as37[] = new s[2];
        as37[0] = new s(4, 43);
        as37[1] = new s(1, 44);
        at9[1] = new t(26, as37);
        s as38[] = new s[2];
        as38[0] = new s(6, 19);
        as38[1] = new s(2, 20);
        at9[2] = new t(24, as38);
        s as39[] = new s[2];
        as39[0] = new s(6, 15);
        as39[1] = new s(2, 16);
        at9[3] = new t(28, as39);
        ar[9] = new r(10, ai9, at9);
        int ai10[] = {
            6, 30, 54
        };
        t at10[] = new t[4];
        s as40[] = new s[1];
        as40[0] = new s(4, 81);
        at10[0] = new t(20, as40);
        s as41[] = new s[2];
        as41[0] = new s(1, 50);
        as41[1] = new s(4, 51);
        at10[1] = new t(30, as41);
        s as42[] = new s[2];
        as42[0] = new s(4, 22);
        as42[1] = new s(4, 23);
        at10[2] = new t(28, as42);
        s as43[] = new s[2];
        as43[0] = new s(3, 12);
        as43[1] = new s(8, 13);
        at10[3] = new t(24, as43);
        ar[10] = new r(11, ai10, at10);
        int ai11[] = {
            6, 32, 58
        };
        t at11[] = new t[4];
        s as44[] = new s[2];
        as44[0] = new s(2, 92);
        as44[1] = new s(2, 93);
        at11[0] = new t(24, as44);
        s as45[] = new s[2];
        as45[0] = new s(6, 36);
        as45[1] = new s(2, 37);
        at11[1] = new t(22, as45);
        s as46[] = new s[2];
        as46[0] = new s(4, 20);
        as46[1] = new s(6, 21);
        at11[2] = new t(26, as46);
        s as47[] = new s[2];
        as47[0] = new s(7, 14);
        as47[1] = new s(4, 15);
        at11[3] = new t(28, as47);
        ar[11] = new r(12, ai11, at11);
        int ai12[] = {
            6, 34, 62
        };
        t at12[] = new t[4];
        s as48[] = new s[1];
        as48[0] = new s(4, 107);
        at12[0] = new t(26, as48);
        s as49[] = new s[2];
        as49[0] = new s(8, 37);
        as49[1] = new s(1, 38);
        at12[1] = new t(22, as49);
        s as50[] = new s[2];
        as50[0] = new s(8, 20);
        as50[1] = new s(4, 21);
        at12[2] = new t(24, as50);
        s as51[] = new s[2];
        as51[0] = new s(12, 11);
        as51[1] = new s(4, 12);
        at12[3] = new t(22, as51);
        ar[12] = new r(13, ai12, at12);
        int ai13[] = {
            6, 26, 46, 66
        };
        t at13[] = new t[4];
        s as52[] = new s[2];
        as52[0] = new s(3, 115);
        as52[1] = new s(1, 116);
        at13[0] = new t(30, as52);
        s as53[] = new s[2];
        as53[0] = new s(4, 40);
        as53[1] = new s(5, 41);
        at13[1] = new t(24, as53);
        s as54[] = new s[2];
        as54[0] = new s(11, 16);
        as54[1] = new s(5, 17);
        at13[2] = new t(20, as54);
        s as55[] = new s[2];
        as55[0] = new s(11, 12);
        as55[1] = new s(5, 13);
        at13[3] = new t(24, as55);
        ar[13] = new r(14, ai13, at13);
        int ai14[] = {
            6, 26, 48, 70
        };
        t at14[] = new t[4];
        s as56[] = new s[2];
        as56[0] = new s(5, 87);
        as56[1] = new s(1, 88);
        at14[0] = new t(22, as56);
        s as57[] = new s[2];
        as57[0] = new s(5, 41);
        as57[1] = new s(5, 42);
        at14[1] = new t(24, as57);
        s as58[] = new s[2];
        as58[0] = new s(5, 24);
        as58[1] = new s(7, 25);
        at14[2] = new t(30, as58);
        s as59[] = new s[2];
        as59[0] = new s(11, 12);
        as59[1] = new s(7, 13);
        at14[3] = new t(24, as59);
        ar[14] = new r(15, ai14, at14);
        int ai15[] = {
            6, 26, 50, 74
        };
        t at15[] = new t[4];
        s as60[] = new s[2];
        as60[0] = new s(5, 98);
        as60[1] = new s(1, 99);
        at15[0] = new t(24, as60);
        s as61[] = new s[2];
        as61[0] = new s(7, 45);
        as61[1] = new s(3, 46);
        at15[1] = new t(28, as61);
        s as62[] = new s[2];
        as62[0] = new s(15, 19);
        as62[1] = new s(2, 20);
        at15[2] = new t(24, as62);
        s as63[] = new s[2];
        as63[0] = new s(3, 15);
        as63[1] = new s(13, 16);
        at15[3] = new t(30, as63);
        ar[15] = new r(16, ai15, at15);
        int ai16[] = {
            6, 30, 54, 78
        };
        t at16[] = new t[4];
        s as64[] = new s[2];
        as64[0] = new s(1, 107);
        as64[1] = new s(5, 108);
        at16[0] = new t(28, as64);
        s as65[] = new s[2];
        as65[0] = new s(10, 46);
        as65[1] = new s(1, 47);
        at16[1] = new t(28, as65);
        s as66[] = new s[2];
        as66[0] = new s(1, 22);
        as66[1] = new s(15, 23);
        at16[2] = new t(28, as66);
        s as67[] = new s[2];
        as67[0] = new s(2, 14);
        as67[1] = new s(17, 15);
        at16[3] = new t(28, as67);
        ar[16] = new r(17, ai16, at16);
        int ai17[] = {
            6, 30, 56, 82
        };
        t at17[] = new t[4];
        s as68[] = new s[2];
        as68[0] = new s(5, 120);
        as68[1] = new s(1, 121);
        at17[0] = new t(30, as68);
        s as69[] = new s[2];
        as69[0] = new s(9, 43);
        as69[1] = new s(4, 44);
        at17[1] = new t(26, as69);
        s as70[] = new s[2];
        as70[0] = new s(17, 22);
        as70[1] = new s(1, 23);
        at17[2] = new t(28, as70);
        s as71[] = new s[2];
        as71[0] = new s(2, 14);
        as71[1] = new s(19, 15);
        at17[3] = new t(28, as71);
        ar[17] = new r(18, ai17, at17);
        int ai18[] = {
            6, 30, 58, 86
        };
        t at18[] = new t[4];
        s as72[] = new s[2];
        as72[0] = new s(3, 113);
        as72[1] = new s(4, 114);
        at18[0] = new t(28, as72);
        s as73[] = new s[2];
        as73[0] = new s(3, 44);
        as73[1] = new s(11, 45);
        at18[1] = new t(26, as73);
        s as74[] = new s[2];
        as74[0] = new s(17, 21);
        as74[1] = new s(4, 22);
        at18[2] = new t(26, as74);
        s as75[] = new s[2];
        as75[0] = new s(9, 13);
        as75[1] = new s(16, 14);
        at18[3] = new t(26, as75);
        ar[18] = new r(19, ai18, at18);
        int ai19[] = {
            6, 34, 62, 90
        };
        t at19[] = new t[4];
        s as76[] = new s[2];
        as76[0] = new s(3, 107);
        as76[1] = new s(5, 108);
        at19[0] = new t(28, as76);
        s as77[] = new s[2];
        as77[0] = new s(3, 41);
        as77[1] = new s(13, 42);
        at19[1] = new t(26, as77);
        s as78[] = new s[2];
        as78[0] = new s(15, 24);
        as78[1] = new s(5, 25);
        at19[2] = new t(30, as78);
        s as79[] = new s[2];
        as79[0] = new s(15, 15);
        as79[1] = new s(10, 16);
        at19[3] = new t(28, as79);
        ar[19] = new r(20, ai19, at19);
        int ai20[] = {
            6, 28, 50, 72, 94
        };
        t at20[] = new t[4];
        s as80[] = new s[2];
        as80[0] = new s(4, 116);
        as80[1] = new s(4, 117);
        at20[0] = new t(28, as80);
        s as81[] = new s[1];
        as81[0] = new s(17, 42);
        at20[1] = new t(26, as81);
        s as82[] = new s[2];
        as82[0] = new s(17, 22);
        as82[1] = new s(6, 23);
        at20[2] = new t(28, as82);
        s as83[] = new s[2];
        as83[0] = new s(19, 16);
        as83[1] = new s(6, 17);
        at20[3] = new t(30, as83);
        ar[20] = new r(21, ai20, at20);
        int ai21[] = {
            6, 26, 50, 74, 98
        };
        t at21[] = new t[4];
        s as84[] = new s[2];
        as84[0] = new s(2, 111);
        as84[1] = new s(7, 112);
        at21[0] = new t(28, as84);
        s as85[] = new s[1];
        as85[0] = new s(17, 46);
        at21[1] = new t(28, as85);
        s as86[] = new s[2];
        as86[0] = new s(7, 24);
        as86[1] = new s(16, 25);
        at21[2] = new t(30, as86);
        s as87[] = new s[1];
        as87[0] = new s(34, 13);
        at21[3] = new t(24, as87);
        ar[21] = new r(22, ai21, at21);
        int ai22[] = {
            6, 30, 54, 78, 102
        };
        t at22[] = new t[4];
        s as88[] = new s[2];
        as88[0] = new s(4, 121);
        as88[1] = new s(5, 122);
        at22[0] = new t(30, as88);
        s as89[] = new s[2];
        as89[0] = new s(4, 47);
        as89[1] = new s(14, 48);
        at22[1] = new t(28, as89);
        s as90[] = new s[2];
        as90[0] = new s(11, 24);
        as90[1] = new s(14, 25);
        at22[2] = new t(30, as90);
        s as91[] = new s[2];
        as91[0] = new s(16, 15);
        as91[1] = new s(14, 16);
        at22[3] = new t(30, as91);
        ar[22] = new r(23, ai22, at22);
        int ai23[] = {
            6, 28, 54, 80, 106
        };
        t at23[] = new t[4];
        s as92[] = new s[2];
        as92[0] = new s(6, 117);
        as92[1] = new s(4, 118);
        at23[0] = new t(30, as92);
        s as93[] = new s[2];
        as93[0] = new s(6, 45);
        as93[1] = new s(14, 46);
        at23[1] = new t(28, as93);
        s as94[] = new s[2];
        as94[0] = new s(11, 24);
        as94[1] = new s(16, 25);
        at23[2] = new t(30, as94);
        s as95[] = new s[2];
        as95[0] = new s(30, 16);
        as95[1] = new s(2, 17);
        at23[3] = new t(30, as95);
        ar[23] = new r(24, ai23, at23);
        int ai24[] = {
            6, 32, 58, 84, 110
        };
        t at24[] = new t[4];
        s as96[] = new s[2];
        as96[0] = new s(8, 106);
        as96[1] = new s(4, 107);
        at24[0] = new t(26, as96);
        s as97[] = new s[2];
        as97[0] = new s(8, 47);
        as97[1] = new s(13, 48);
        at24[1] = new t(28, as97);
        s as98[] = new s[2];
        as98[0] = new s(7, 24);
        as98[1] = new s(22, 25);
        at24[2] = new t(30, as98);
        s as99[] = new s[2];
        as99[0] = new s(22, 15);
        as99[1] = new s(13, 16);
        at24[3] = new t(30, as99);
        ar[24] = new r(25, ai24, at24);
        int ai25[] = {
            6, 30, 58, 86, 114
        };
        t at25[] = new t[4];
        s as100[] = new s[2];
        as100[0] = new s(10, 114);
        as100[1] = new s(2, 115);
        at25[0] = new t(28, as100);
        s as101[] = new s[2];
        as101[0] = new s(19, 46);
        as101[1] = new s(4, 47);
        at25[1] = new t(28, as101);
        s as102[] = new s[2];
        as102[0] = new s(28, 22);
        as102[1] = new s(6, 23);
        at25[2] = new t(28, as102);
        s as103[] = new s[2];
        as103[0] = new s(33, 16);
        as103[1] = new s(4, 17);
        at25[3] = new t(30, as103);
        ar[25] = new r(26, ai25, at25);
        int ai26[] = {
            6, 34, 62, 90, 118
        };
        t at26[] = new t[4];
        s as104[] = new s[2];
        as104[0] = new s(8, 122);
        as104[1] = new s(4, 123);
        at26[0] = new t(30, as104);
        s as105[] = new s[2];
        as105[0] = new s(22, 45);
        as105[1] = new s(3, 46);
        at26[1] = new t(28, as105);
        s as106[] = new s[2];
        as106[0] = new s(8, 23);
        as106[1] = new s(26, 24);
        at26[2] = new t(30, as106);
        s as107[] = new s[2];
        as107[0] = new s(12, 15);
        as107[1] = new s(28, 16);
        at26[3] = new t(30, as107);
        ar[26] = new r(27, ai26, at26);
        int ai27[] = {
            6, 26, 50, 74, 98, 122
        };
        t at27[] = new t[4];
        s as108[] = new s[2];
        as108[0] = new s(3, 117);
        as108[1] = new s(10, 118);
        at27[0] = new t(30, as108);
        s as109[] = new s[2];
        as109[0] = new s(3, 45);
        as109[1] = new s(23, 46);
        at27[1] = new t(28, as109);
        s as110[] = new s[2];
        as110[0] = new s(4, 24);
        as110[1] = new s(31, 25);
        at27[2] = new t(30, as110);
        s as111[] = new s[2];
        as111[0] = new s(11, 15);
        as111[1] = new s(31, 16);
        at27[3] = new t(30, as111);
        ar[27] = new r(28, ai27, at27);
        int ai28[] = {
            6, 30, 54, 78, 102, 126
        };
        t at28[] = new t[4];
        s as112[] = new s[2];
        as112[0] = new s(7, 116);
        as112[1] = new s(7, 117);
        at28[0] = new t(30, as112);
        s as113[] = new s[2];
        as113[0] = new s(21, 45);
        as113[1] = new s(7, 46);
        at28[1] = new t(28, as113);
        s as114[] = new s[2];
        as114[0] = new s(1, 23);
        as114[1] = new s(37, 24);
        at28[2] = new t(30, as114);
        s as115[] = new s[2];
        as115[0] = new s(19, 15);
        as115[1] = new s(26, 16);
        at28[3] = new t(30, as115);
        ar[28] = new r(29, ai28, at28);
        int ai29[] = {
            6, 26, 52, 78, 104, 130
        };
        t at29[] = new t[4];
        s as116[] = new s[2];
        as116[0] = new s(5, 115);
        as116[1] = new s(10, 116);
        at29[0] = new t(30, as116);
        s as117[] = new s[2];
        as117[0] = new s(19, 47);
        as117[1] = new s(10, 48);
        at29[1] = new t(28, as117);
        s as118[] = new s[2];
        as118[0] = new s(15, 24);
        as118[1] = new s(25, 25);
        at29[2] = new t(30, as118);
        s as119[] = new s[2];
        as119[0] = new s(23, 15);
        as119[1] = new s(25, 16);
        at29[3] = new t(30, as119);
        ar[29] = new r(30, ai29, at29);
        int ai30[] = {
            6, 30, 56, 82, 108, 134
        };
        t at30[] = new t[4];
        s as120[] = new s[2];
        as120[0] = new s(13, 115);
        as120[1] = new s(3, 116);
        at30[0] = new t(30, as120);
        s as121[] = new s[2];
        as121[0] = new s(2, 46);
        as121[1] = new s(29, 47);
        at30[1] = new t(28, as121);
        s as122[] = new s[2];
        as122[0] = new s(42, 24);
        as122[1] = new s(1, 25);
        at30[2] = new t(30, as122);
        s as123[] = new s[2];
        as123[0] = new s(23, 15);
        as123[1] = new s(28, 16);
        at30[3] = new t(30, as123);
        ar[30] = new r(31, ai30, at30);
        int ai31[] = {
            6, 34, 60, 86, 112, 138
        };
        t at31[] = new t[4];
        s as124[] = new s[1];
        as124[0] = new s(17, 115);
        at31[0] = new t(30, as124);
        s as125[] = new s[2];
        as125[0] = new s(10, 46);
        as125[1] = new s(23, 47);
        at31[1] = new t(28, as125);
        s as126[] = new s[2];
        as126[0] = new s(10, 24);
        as126[1] = new s(35, 25);
        at31[2] = new t(30, as126);
        s as127[] = new s[2];
        as127[0] = new s(19, 15);
        as127[1] = new s(35, 16);
        at31[3] = new t(30, as127);
        ar[31] = new r(32, ai31, at31);
        int ai32[] = {
            6, 30, 58, 86, 114, 142
        };
        t at32[] = new t[4];
        s as128[] = new s[2];
        as128[0] = new s(17, 115);
        as128[1] = new s(1, 116);
        at32[0] = new t(30, as128);
        s as129[] = new s[2];
        as129[0] = new s(14, 46);
        as129[1] = new s(21, 47);
        at32[1] = new t(28, as129);
        s as130[] = new s[2];
        as130[0] = new s(29, 24);
        as130[1] = new s(19, 25);
        at32[2] = new t(30, as130);
        s as131[] = new s[2];
        as131[0] = new s(11, 15);
        as131[1] = new s(46, 16);
        at32[3] = new t(30, as131);
        ar[32] = new r(33, ai32, at32);
        int ai33[] = {
            6, 34, 62, 90, 118, 146
        };
        t at33[] = new t[4];
        s as132[] = new s[2];
        as132[0] = new s(13, 115);
        as132[1] = new s(6, 116);
        at33[0] = new t(30, as132);
        s as133[] = new s[2];
        as133[0] = new s(14, 46);
        as133[1] = new s(23, 47);
        at33[1] = new t(28, as133);
        s as134[] = new s[2];
        as134[0] = new s(44, 24);
        as134[1] = new s(7, 25);
        at33[2] = new t(30, as134);
        s as135[] = new s[2];
        as135[0] = new s(59, 16);
        as135[1] = new s(1, 17);
        at33[3] = new t(30, as135);
        ar[33] = new r(34, ai33, at33);
        int ai34[] = {
            6, 30, 54, 78, 102, 126, 150
        };
        t at34[] = new t[4];
        s as136[] = new s[2];
        as136[0] = new s(12, 121);
        as136[1] = new s(7, 122);
        at34[0] = new t(30, as136);
        s as137[] = new s[2];
        as137[0] = new s(12, 47);
        as137[1] = new s(26, 48);
        at34[1] = new t(28, as137);
        s as138[] = new s[2];
        as138[0] = new s(39, 24);
        as138[1] = new s(14, 25);
        at34[2] = new t(30, as138);
        s as139[] = new s[2];
        as139[0] = new s(22, 15);
        as139[1] = new s(41, 16);
        at34[3] = new t(30, as139);
        ar[34] = new r(35, ai34, at34);
        int ai35[] = {
            6, 24, 50, 76, 102, 128, 154
        };
        t at35[] = new t[4];
        s as140[] = new s[2];
        as140[0] = new s(6, 121);
        as140[1] = new s(14, 122);
        at35[0] = new t(30, as140);
        s as141[] = new s[2];
        as141[0] = new s(6, 47);
        as141[1] = new s(34, 48);
        at35[1] = new t(28, as141);
        s as142[] = new s[2];
        as142[0] = new s(46, 24);
        as142[1] = new s(10, 25);
        at35[2] = new t(30, as142);
        s as143[] = new s[2];
        as143[0] = new s(2, 15);
        as143[1] = new s(64, 16);
        at35[3] = new t(30, as143);
        ar[35] = new r(36, ai35, at35);
        int ai36[] = {
            6, 28, 54, 80, 106, 132, 158
        };
        t at36[] = new t[4];
        s as144[] = new s[2];
        as144[0] = new s(17, 122);
        as144[1] = new s(4, 123);
        at36[0] = new t(30, as144);
        s as145[] = new s[2];
        as145[0] = new s(29, 46);
        as145[1] = new s(14, 47);
        at36[1] = new t(28, as145);
        s as146[] = new s[2];
        as146[0] = new s(49, 24);
        as146[1] = new s(10, 25);
        at36[2] = new t(30, as146);
        s as147[] = new s[2];
        as147[0] = new s(24, 15);
        as147[1] = new s(46, 16);
        at36[3] = new t(30, as147);
        ar[36] = new r(37, ai36, at36);
        int ai37[] = {
            6, 32, 58, 84, 110, 136, 162
        };
        t at37[] = new t[4];
        s as148[] = new s[2];
        as148[0] = new s(4, 122);
        as148[1] = new s(18, 123);
        at37[0] = new t(30, as148);
        s as149[] = new s[2];
        as149[0] = new s(13, 46);
        as149[1] = new s(32, 47);
        at37[1] = new t(28, as149);
        s as150[] = new s[2];
        as150[0] = new s(48, 24);
        as150[1] = new s(14, 25);
        at37[2] = new t(30, as150);
        s as151[] = new s[2];
        as151[0] = new s(42, 15);
        as151[1] = new s(32, 16);
        at37[3] = new t(30, as151);
        ar[37] = new r(38, ai37, at37);
        int ai38[] = {
            6, 26, 54, 82, 110, 138, 166
        };
        t at38[] = new t[4];
        s as152[] = new s[2];
        as152[0] = new s(20, 117);
        as152[1] = new s(4, 118);
        at38[0] = new t(30, as152);
        s as153[] = new s[2];
        as153[0] = new s(40, 47);
        as153[1] = new s(7, 48);
        at38[1] = new t(28, as153);
        s as154[] = new s[2];
        as154[0] = new s(43, 24);
        as154[1] = new s(22, 25);
        at38[2] = new t(30, as154);
        s as155[] = new s[2];
        as155[0] = new s(10, 15);
        as155[1] = new s(67, 16);
        at38[3] = new t(30, as155);
        ar[38] = new r(39, ai38, at38);
        int ai39[] = {
            6, 30, 58, 86, 114, 142, 170
        };
        t at39[] = new t[4];
        s as156[] = new s[2];
        as156[0] = new s(19, 118);
        as156[1] = new s(6, 119);
        at39[0] = new t(30, as156);
        s as157[] = new s[2];
        as157[0] = new s(18, 47);
        as157[1] = new s(31, 48);
        at39[1] = new t(28, as157);
        s as158[] = new s[2];
        as158[0] = new s(34, 24);
        as158[1] = new s(34, 25);
        at39[2] = new t(30, as158);
        s as159[] = new s[2];
        as159[0] = new s(20, 15);
        as159[1] = new s(61, 16);
        at39[3] = new t(30, as159);
        ar[39] = new r(40, ai39, at39);
        return ar;
    }

    public int a()
    {
        return c;
    }

    public t a(o o1)
    {
        return e[o1.ordinal()];
    }

    public int[] b()
    {
        return d;
    }

    public int c()
    {
        return f;
    }

    public int d()
    {
        return 17 + 4 * c;
    }

    b e()
    {
        int i = d();
        b b1 = new b(i);
        b1.a(0, 0, 9, 9);
        b1.a(i - 8, 0, 8, 9);
        b1.a(0, i - 8, 9, 8);
        int j = d.length;
        for (int k = 0; k < j; k++)
        {
            int l = -2 + d[k];
            int i1 = 0;
            while (i1 < j) 
            {
                if ((k != 0 || i1 != 0 && i1 != j - 1) && (k != j - 1 || i1 != 0))
                {
                    b1.a(-2 + d[i1], l, 5, 5);
                }
                i1++;
            }
        }

        b1.a(6, 9, 1, i - 17);
        b1.a(9, 6, i - 17, 1);
        if (c > 6)
        {
            b1.a(i - 11, 0, 3, 6);
            b1.a(0, i - 11, 6, 3);
        }
        return b1;
    }

    public String toString()
    {
        return String.valueOf(c);
    }

}
