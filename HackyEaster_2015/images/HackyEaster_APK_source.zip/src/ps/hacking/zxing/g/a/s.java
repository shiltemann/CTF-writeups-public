// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.g.a;


public final class s
{

    private final int a;
    private final int b;

    s(int i, int j)
    {
        a = i;
        b = j;
    }

    public int a()
    {
        return a;
    }

    public int b()
    {
        return b;
    }
}
