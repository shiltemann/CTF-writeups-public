// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.g.a;


// Referenced classes of package ps.hacking.zxing.g.a:
//            s

public final class t
{

    private final int a;
    private final s b[];

    transient t(int i, s as[])
    {
        a = i;
        b = as;
    }

    public int a()
    {
        return a;
    }

    public s[] b()
    {
        return b;
    }
}
