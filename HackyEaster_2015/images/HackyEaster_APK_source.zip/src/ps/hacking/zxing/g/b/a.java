// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.g.b;

import ps.hacking.zxing.o;

public final class a extends o
{

    private final float a;

    a(float f, float f1, float f2)
    {
        super(f, f1);
        a = f2;
    }

    boolean a(float f, float f1, float f2)
    {
        boolean flag;
label0:
        {
            int i = Math.abs(f1 - b()) != f;
            flag = false;
            if (i > 0)
            {
                break label0;
            }
            int j = Math.abs(f2 - a()) != f;
            flag = false;
            if (j > 0)
            {
                break label0;
            }
            float f3 = Math.abs(f - a);
            if (f3 > 1.0F)
            {
                int k = f3 != a;
                flag = false;
                if (k > 0)
                {
                    break label0;
                }
            }
            flag = true;
        }
        return flag;
    }

    a b(float f, float f1, float f2)
    {
        return new a((f1 + a()) / 2.0F, (f + b()) / 2.0F, (f2 + a) / 2.0F);
    }
}
