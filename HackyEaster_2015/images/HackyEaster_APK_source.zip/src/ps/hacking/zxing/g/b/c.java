// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.g.b;

import java.util.Map;
import ps.hacking.zxing.b.a.a;
import ps.hacking.zxing.b.b;
import ps.hacking.zxing.b.g;
import ps.hacking.zxing.b.k;
import ps.hacking.zxing.e;
import ps.hacking.zxing.g.a.r;
import ps.hacking.zxing.i;
import ps.hacking.zxing.o;
import ps.hacking.zxing.p;

// Referenced classes of package ps.hacking.zxing.g.b:
//            e, i, d, b, 
//            a

public class c
{

    private final b a;
    private p b;

    public c(b b1)
    {
        a = b1;
    }

    private float a(int j, int l, int i1, int j1)
    {
        int k1 = 0;
        float f = b(j, l, i1, j1);
        int l1 = j - (i1 - j);
        int i2;
        float f1;
        int j2;
        float f2;
        if (l1 < 0)
        {
            f1 = (float)j / (float)(j - l1);
            i2 = 0;
        } else
        if (l1 >= a.d())
        {
            float f3 = (float)((-1 + a.d()) - j) / (float)(l1 - j);
            int k2 = -1 + a.d();
            f1 = f3;
            i2 = k2;
        } else
        {
            i2 = l1;
            f1 = 1.0F;
        }
        j2 = (int)((float)l - f1 * (float)(j1 - l));
        if (j2 < 0)
        {
            f2 = (float)l / (float)(l - j2);
        } else
        if (j2 >= a.e())
        {
            f2 = (float)((-1 + a.e()) - l) / (float)(j2 - l);
            k1 = -1 + a.e();
        } else
        {
            k1 = j2;
            f2 = 1.0F;
        }
        return (f + b(j, l, (int)((float)j + f2 * (float)(i2 - j)), k1)) - 1.0F;
    }

    private float a(o o1, o o2)
    {
        float f = a((int)o1.a(), (int)o1.b(), (int)o2.a(), (int)o2.b());
        float f1 = a((int)o2.a(), (int)o2.b(), (int)o1.a(), (int)o1.b());
        if (Float.isNaN(f))
        {
            return f1 / 7F;
        }
        if (Float.isNaN(f1))
        {
            return f / 7F;
        } else
        {
            return (f + f1) / 14F;
        }
    }

    private static int a(o o1, o o2, o o3, float f)
    {
        int j = 7 + (ps.hacking.zxing.b.a.a.a(o.a(o1, o2) / f) + ps.hacking.zxing.b.a.a.a(o.a(o1, o3) / f) >> 1);
        switch (j & 3)
        {
        case 1: // '\001'
        default:
            return j;

        case 0: // '\0'
            return j + 1;

        case 2: // '\002'
            return j - 1;

        case 3: // '\003'
            throw i.a();
        }
    }

    private static b a(b b1, k k1, int j)
    {
        return ps.hacking.zxing.b.i.a().a(b1, j, j, k1);
    }

    private static k a(o o1, o o2, o o3, o o4, int j)
    {
        float f = (float)j - 3.5F;
        float f1;
        float f2;
        float f3;
        float f4;
        if (o4 != null)
        {
            f1 = o4.a();
            f2 = o4.b();
            f3 = f - 3F;
            f4 = f3;
        } else
        {
            f1 = (o2.a() - o1.a()) + o3.a();
            f2 = (o2.b() - o1.b()) + o3.b();
            f3 = f;
            f4 = f;
        }
        return k.a(3.5F, 3.5F, f, 3.5F, f4, f3, 3.5F, f, o1.a(), o1.b(), o2.a(), o2.b(), f1, f2, o3.a(), o3.b());
    }

    private float b(int j, int l, int i1, int j1)
    {
        boolean flag;
        int i2;
        int j2;
        int k2;
        int l2;
        byte byte0;
        int i3;
        int j3;
        int k3;
        int l3;
        int i4;
        int k4;
        int l4;
        boolean flag1;
        if (Math.abs(j1 - l) > Math.abs(i1 - j))
        {
            flag = true;
        } else
        {
            flag = false;
        }
        int j4;
        int i5;
        int j5;
        int k5;
        int l5;
        if (!flag)
        {
            int k1 = j1;
            j1 = i1;
            i1 = k1;
            int l1 = l;
            l = j;
            j = l1;
        }
        i2 = Math.abs(j1 - l);
        j2 = Math.abs(i1 - j);
        k2 = -i2 >> 1;
        if (l < j1)
        {
            l2 = 1;
        } else
        {
            l2 = -1;
        }
        if (j < i1)
        {
            byte0 = 1;
        } else
        {
            byte0 = -1;
        }
        i3 = 0;
        j3 = j1 + l2;
        k3 = l;
        l3 = k2;
        i4 = j;
        if (k3 == j3)
        {
            break MISSING_BLOCK_LABEL_292;
        }
        if (flag)
        {
            k4 = i4;
        } else
        {
            k4 = k3;
        }
        if (flag)
        {
            l4 = k3;
        } else
        {
            l4 = i4;
        }
        if (i3 == 1)
        {
            flag1 = true;
        } else
        {
            flag1 = false;
        }
        if (flag1 == a.a(k4, l4))
        {
            if (i3 == 2)
            {
                return ps.hacking.zxing.b.a.a.a(k3, i4, l, j);
            }
            i5 = i3 + 1;
        } else
        {
            i5 = i3;
        }
        j5 = l3 + j2;
        if (j5 <= 0) goto _L2; else goto _L1
_L1:
        if (i4 != i1) goto _L4; else goto _L3
_L3:
        j4 = i5;
_L8:
        if (j4 == 2)
        {
            return ps.hacking.zxing.b.a.a.a(j1 + l2, i1, l, j);
        } else
        {
            return (0.0F / 0.0F);
        }
_L4:
        k5 = i4 + byte0;
        l5 = j5 - i2;
_L6:
        k3 += l2;
        i3 = i5;
        l3 = l5;
        i4 = k5;
        break MISSING_BLOCK_LABEL_85;
_L2:
        k5 = i4;
        l5 = j5;
        if (true) goto _L6; else goto _L5
_L5:
        j4 = i3;
        if (true) goto _L8; else goto _L7
_L7:
    }

    protected final float a(o o1, o o2, o o3)
    {
        return (a(o1, o2) + a(o1, o3)) / 2.0F;
    }

    public final g a(Map map)
    {
        p p1;
        if (map == null)
        {
            p1 = null;
        } else
        {
            p1 = (p)map.get(e.h);
        }
        b = p1;
        return a((new ps.hacking.zxing.g.b.e(a, b)).a(map));
    }

    protected final g a(ps.hacking.zxing.g.b.i j)
    {
        d d1;
        d d2;
        d d3;
        float f;
        int l;
        int i1;
        int j1;
        ps.hacking.zxing.g.b.a a1;
        d1 = j.b();
        d2 = j.c();
        d3 = j.a();
        f = a(((o) (d1)), ((o) (d2)), ((o) (d3)));
        if (f < 1.0F)
        {
            throw i.a();
        }
        l = a(((o) (d1)), ((o) (d2)), ((o) (d3)), f);
        r r1 = r.a(l);
        i1 = -7 + r1.d();
        j1 = r1.b().length;
        a1 = null;
        if (j1 <= 0) goto _L2; else goto _L1
_L1:
        int l1;
        int i2;
        int j2;
        float f1 = (d2.a() - d1.a()) + d3.a();
        float f2 = (d2.b() - d1.b()) + d3.b();
        float f3 = 1.0F - 3F / (float)i1;
        l1 = (int)(d1.a() + f3 * (f1 - d1.a()));
        i2 = (int)(d1.b() + f3 * (f2 - d1.b()));
        j2 = 4;
_L5:
        a1 = null;
        if (j2 > 16) goto _L2; else goto _L3
_L3:
        float f4 = j2;
        ps.hacking.zxing.g.b.a a2 = a(f, l1, i2, f4);
        a1 = a2;
_L2:
        k k1 = a(((o) (d1)), ((o) (d2)), ((o) (d3)), ((o) (a1)), l);
        b b1 = a(a, k1, l);
        o ao[];
        i k2;
        if (a1 == null)
        {
            ao = (new o[] {
                d3, d1, d2
            });
        } else
        {
            ao = (new o[] {
                d3, d1, d2, a1
            });
        }
        return new g(b1, ao);
        k2;
        j2 <<= 1;
        if (true) goto _L5; else goto _L4
_L4:
    }

    protected final ps.hacking.zxing.g.b.a a(float f, int j, int l, float f1)
    {
        int i1 = (int)(f1 * f);
        int j1 = Math.max(0, j - i1);
        int k1 = Math.min(-1 + a.d(), j + i1);
        if ((float)(k1 - j1) < f * 3F)
        {
            throw i.a();
        }
        int l1 = Math.max(0, l - i1);
        int i2 = Math.min(-1 + a.e(), i1 + l);
        if ((float)(i2 - l1) < f * 3F)
        {
            throw i.a();
        } else
        {
            return (new ps.hacking.zxing.g.b.b(a, j1, l1, k1 - j1, i2 - l1, f, b)).a();
        }
    }
}
