// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.g.b;

import ps.hacking.zxing.o;

public final class d extends o
{

    private final float a;
    private int b;

    d(float f, float f1, float f2)
    {
        this(f, f1, f2, 1);
    }

    private d(float f, float f1, float f2, int i)
    {
        super(f, f1);
        a = f2;
        b = i;
    }

    boolean a(float f, float f1, float f2)
    {
        boolean flag;
label0:
        {
            int i = Math.abs(f1 - b()) != f;
            flag = false;
            if (i > 0)
            {
                break label0;
            }
            int j = Math.abs(f2 - a()) != f;
            flag = false;
            if (j > 0)
            {
                break label0;
            }
            float f3 = Math.abs(f - a);
            if (f3 > 1.0F)
            {
                int k = f3 != a;
                flag = false;
                if (k > 0)
                {
                    break label0;
                }
            }
            flag = true;
        }
        return flag;
    }

    d b(float f, float f1, float f2)
    {
        int i = 1 + b;
        return new d((f1 + (float)b * a()) / (float)i, (f + (float)b * b()) / (float)i, (f2 + (float)b * a) / (float)i, i);
    }

    public float c()
    {
        return a;
    }

    int d()
    {
        return b;
    }
}
