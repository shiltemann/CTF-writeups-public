// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.g.b;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import ps.hacking.zxing.b.b;
import ps.hacking.zxing.i;
import ps.hacking.zxing.o;
import ps.hacking.zxing.p;

// Referenced classes of package ps.hacking.zxing.g.b:
//            d, h, g, i

public class e
{

    private final b a;
    private final List b = new ArrayList();
    private boolean c;
    private final int d[] = new int[5];
    private final p e;

    public e(b b1, p p1)
    {
        a = b1;
        e = p1;
    }

    private float a(int j, int k, int l, int i1)
    {
        b b1 = a;
        int j1 = b1.e();
        int ai[] = a();
        int k1;
        for (k1 = j; k1 >= 0 && b1.a(k, k1); k1--)
        {
            ai[2] = 1 + ai[2];
        }

        if (k1 >= 0)
        {
            for (; k1 >= 0 && !b1.a(k, k1) && ai[1] <= l; k1--)
            {
                ai[1] = 1 + ai[1];
            }

            if (k1 >= 0 && ai[1] <= l)
            {
                for (; k1 >= 0 && b1.a(k, k1) && ai[0] <= l; k1--)
                {
                    ai[0] = 1 + ai[0];
                }

                if (ai[0] <= l)
                {
                    int l1;
                    for (l1 = j + 1; l1 < j1 && b1.a(k, l1); l1++)
                    {
                        ai[2] = 1 + ai[2];
                    }

                    if (l1 != j1)
                    {
                        for (; l1 < j1 && !b1.a(k, l1) && ai[3] < l; l1++)
                        {
                            ai[3] = 1 + ai[3];
                        }

                        if (l1 != j1 && ai[3] < l)
                        {
                            for (; l1 < j1 && b1.a(k, l1) && ai[4] < l; l1++)
                            {
                                ai[4] = 1 + ai[4];
                            }

                            if (ai[4] < l && 5 * Math.abs((ai[0] + ai[1] + ai[2] + ai[3] + ai[4]) - i1) < i1 * 2 && a(ai))
                            {
                                return a(ai, l1);
                            }
                        }
                    }
                }
            }
        }
        return (0.0F / 0.0F);
    }

    private static float a(int ai[], int j)
    {
        return (float)(j - ai[4] - ai[3]) - (float)ai[2] / 2.0F;
    }

    protected static boolean a(int ai[])
    {
        boolean flag;
        int j;
        int k;
        flag = true;
        j = 0;
        k = 0;
_L7:
        if (j >= 5) goto _L2; else goto _L1
_L1:
        int j1 = ai[j];
        if (j1 != 0) goto _L4; else goto _L3
_L3:
        return false;
_L4:
        k += j1;
        j++;
        continue; /* Loop/switch isn't completed */
_L2:
        if (k < 7) goto _L3; else goto _L5
_L5:
        int l = (k << 8) / 7;
        int i1 = l / 2;
        if (Math.abs(l - (ai[0] << 8)) >= i1 || Math.abs(l - (ai[flag] << 8)) >= i1 || Math.abs(l * 3 - (ai[2] << 8)) >= i1 * 3 || Math.abs(l - (ai[3] << 8)) >= i1 || Math.abs(l - (ai[4] << 8)) >= i1)
        {
            flag = false;
        }
        return flag;
        if (true) goto _L7; else goto _L6
_L6:
    }

    private int[] a()
    {
        d[0] = 0;
        d[1] = 0;
        d[2] = 0;
        d[3] = 0;
        d[4] = 0;
        return d;
    }

    private float b(int j, int k, int l, int i1)
    {
        b b1 = a;
        int j1 = b1.d();
        int ai[] = a();
        int k1;
        for (k1 = j; k1 >= 0 && b1.a(k1, k); k1--)
        {
            ai[2] = 1 + ai[2];
        }

        if (k1 >= 0)
        {
            for (; k1 >= 0 && !b1.a(k1, k) && ai[1] <= l; k1--)
            {
                ai[1] = 1 + ai[1];
            }

            if (k1 >= 0 && ai[1] <= l)
            {
                for (; k1 >= 0 && b1.a(k1, k) && ai[0] <= l; k1--)
                {
                    ai[0] = 1 + ai[0];
                }

                if (ai[0] <= l)
                {
                    int l1;
                    for (l1 = j + 1; l1 < j1 && b1.a(l1, k); l1++)
                    {
                        ai[2] = 1 + ai[2];
                    }

                    if (l1 != j1)
                    {
                        for (; l1 < j1 && !b1.a(l1, k) && ai[3] < l; l1++)
                        {
                            ai[3] = 1 + ai[3];
                        }

                        if (l1 != j1 && ai[3] < l)
                        {
                            for (; l1 < j1 && b1.a(l1, k) && ai[4] < l; l1++)
                            {
                                ai[4] = 1 + ai[4];
                            }

                            if (ai[4] < l && 5 * Math.abs((ai[0] + ai[1] + ai[2] + ai[3] + ai[4]) - i1) < i1 && a(ai))
                            {
                                return a(ai, l1);
                            }
                        }
                    }
                }
            }
        }
        return (0.0F / 0.0F);
    }

    private int b()
    {
        d d1;
        Iterator iterator;
        if (b.size() <= 1)
        {
            return 0;
        }
        d1 = null;
        iterator = b.iterator();
_L5:
        if (!iterator.hasNext()) goto _L2; else goto _L1
_L1:
        d d2;
        d2 = (d)iterator.next();
        if (d2.d() < 2)
        {
            break MISSING_BLOCK_LABEL_99;
        }
        if (d1 != null) goto _L4; else goto _L3
_L3:
        d1 = d2;
          goto _L5
_L4:
        c = true;
        return (int)(Math.abs(d1.a() - d2.a()) - Math.abs(d1.b() - d2.b())) / 2;
_L2:
        return 0;
        d2 = d1;
          goto _L3
    }

    private boolean c()
    {
        float f = 0.0F;
        int j = b.size();
        Iterator iterator = b.iterator();
        float f1 = 0.0F;
        int k = 0;
        while (iterator.hasNext()) 
        {
            d d1 = (d)iterator.next();
            float f2;
            Iterator iterator1;
            float f3;
            int l;
            if (d1.d() >= 2)
            {
                int i1 = k + 1;
                f3 = f1 + d1.c();
                l = i1;
            } else
            {
                f3 = f1;
                l = k;
            }
            k = l;
            f1 = f3;
        }
        if (k >= 3)
        {
            f2 = f1 / (float)j;
            for (iterator1 = b.iterator(); iterator1.hasNext();)
            {
                f += Math.abs(((d)iterator1.next()).c() - f2);
            }

            if (f <= 0.05F * f1)
            {
                return true;
            }
        }
        return false;
    }

    private d[] d()
    {
        float f = 0.0F;
        int j = b.size();
        if (j < 3)
        {
            throw i.a();
        }
        if (j > 3)
        {
            Iterator iterator1 = b.iterator();
            float f2 = 0.0F;
            float f3 = 0.0F;
            while (iterator1.hasNext()) 
            {
                float f7 = ((d)iterator1.next()).c();
                f3 += f7;
                f2 += f7 * f7;
            }
            float f4 = f3 / (float)j;
            float f5 = (float)Math.sqrt(f2 / (float)j - f4 * f4);
            Collections.sort(b, new h(f4, null));
            float f6 = Math.max(0.2F * f4, f5);
            for (int k = 0; k < b.size() && b.size() > 3; k++)
            {
                if (Math.abs(((d)b.get(k)).c() - f4) > f6)
                {
                    b.remove(k);
                    k--;
                }
            }

        }
        if (b.size() > 3)
        {
            for (Iterator iterator = b.iterator(); iterator.hasNext();)
            {
                f += ((d)iterator.next()).c();
            }

            float f1 = f / (float)b.size();
            Collections.sort(b, new g(f1, null));
            b.subList(3, b.size()).clear();
        }
        d ad[] = new d[3];
        ad[0] = (d)b.get(0);
        ad[1] = (d)b.get(1);
        ad[2] = (d)b.get(2);
        return ad;
    }

    final ps.hacking.zxing.g.b.i a(Map map)
    {
        boolean flag;
        int j;
        int k;
        int l;
        int i1;
        int ai[];
        int j1;
        boolean flag1;
        int k1;
        if (map != null && map.containsKey(ps.hacking.zxing.e.d))
        {
            flag = true;
        } else
        {
            flag = false;
        }
        j = a.e();
        k = a.d();
        l = (j * 3) / 228;
        if (l < 3 || flag)
        {
            i1 = 3;
        } else
        {
            i1 = l;
        }
        ai = new int[5];
        j1 = i1 - 1;
        flag1 = false;
        k1 = i1;
        while (j1 < j && !flag1) 
        {
            ai[0] = 0;
            ai[1] = 0;
            ai[2] = 0;
            ai[3] = 0;
            ai[4] = 0;
            int l1 = 0;
            int i2 = 0;
            while (l1 < k) 
            {
                if (a.a(l1, j1))
                {
                    if ((i2 & 1) == 1)
                    {
                        i2++;
                    }
                    ai[i2] = 1 + ai[i2];
                } else
                if ((i2 & 1) == 0)
                {
                    if (i2 == 4)
                    {
                        if (a(ai))
                        {
                            if (a(ai, j1, l1))
                            {
                                boolean flag2;
                                if (c)
                                {
                                    flag2 = c();
                                } else
                                {
                                    int j2 = b();
                                    d ad[];
                                    int k2;
                                    int l2;
                                    if (j2 > ai[2])
                                    {
                                        l2 = j1 + (j2 - ai[2] - 2);
                                        k2 = k - 1;
                                    } else
                                    {
                                        k2 = l1;
                                        l2 = j1;
                                    }
                                    j1 = l2;
                                    l1 = k2;
                                    flag2 = flag1;
                                }
                                ai[0] = 0;
                                ai[1] = 0;
                                ai[2] = 0;
                                ai[3] = 0;
                                ai[4] = 0;
                                flag1 = flag2;
                                k1 = 2;
                                i2 = 0;
                            } else
                            {
                                ai[0] = ai[2];
                                ai[1] = ai[3];
                                ai[2] = ai[4];
                                ai[3] = 1;
                                ai[4] = 0;
                                i2 = 3;
                            }
                        } else
                        {
                            ai[0] = ai[2];
                            ai[1] = ai[3];
                            ai[2] = ai[4];
                            ai[3] = 1;
                            ai[4] = 0;
                            i2 = 3;
                        }
                    } else
                    {
                        i2++;
                        ai[i2] = 1 + ai[i2];
                    }
                } else
                {
                    ai[i2] = 1 + ai[i2];
                }
                l1++;
            }
            if (!a(ai) || !a(ai, j1, k))
            {
                continue;
            }
            k1 = ai[0];
            if (c)
            {
                flag1 = c();
            }
            j1 += k1;
        }
        ad = d();
        o.a(ad);
        return new ps.hacking.zxing.g.b.i(ad);
    }

    protected final boolean a(int ai[], int j, int k)
    {
        int l;
        float f;
        float f1;
        boolean flag;
        boolean flag1;
        l = ai[0] + ai[1] + ai[2] + ai[3] + ai[4];
        f = a(ai, k);
        f1 = a(j, (int)f, ai[2], l);
        flag = Float.isNaN(f1);
        flag1 = false;
        if (flag) goto _L2; else goto _L1
_L1:
        float f2;
        boolean flag2;
        f2 = b((int)f, (int)f1, ai[2], l);
        flag2 = Float.isNaN(f2);
        flag1 = false;
        if (flag2) goto _L2; else goto _L3
_L3:
        float f3;
        int i1;
        f3 = (float)l / 7F;
        i1 = 0;
_L9:
        int j1;
        boolean flag3;
        j1 = b.size();
        flag3 = false;
        if (i1 >= j1) goto _L5; else goto _L4
_L4:
        d d2 = (d)b.get(i1);
        if (!d2.a(f3, f1, f2)) goto _L7; else goto _L6
_L6:
        b.set(i1, d2.b(f1, f2, f3));
        flag3 = true;
_L5:
        if (!flag3)
        {
            d d1 = new d(f2, f1, f3);
            b.add(d1);
            if (e != null)
            {
                e.a(d1);
            }
        }
        flag1 = true;
_L2:
        return flag1;
_L7:
        i1++;
        if (true) goto _L9; else goto _L8
_L8:
    }
}
