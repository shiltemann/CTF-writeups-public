// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing.g.b;


// Referenced classes of package ps.hacking.zxing.g.b:
//            d

public final class i
{

    private final d a;
    private final d b;
    private final d c;

    public i(d ad[])
    {
        a = ad[0];
        b = ad[1];
        c = ad[2];
    }

    public d a()
    {
        return a;
    }

    public d b()
    {
        return b;
    }

    public d c()
    {
        return c;
    }
}
