// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;
import ps.hacking.zxing.a.b;
import ps.hacking.zxing.e.i;
import ps.hacking.zxing.g.a;

// Referenced classes of package ps.hacking.zxing:
//            k, l, i, e, 
//            a, c, m

public final class h
    implements k
{

    private Map a;
    private k b[];

    public h()
    {
    }

    private m b(c c)
    {
        if (b == null) goto _L2; else goto _L1
_L1:
        k ak[];
        int j;
        int i1;
        ak = b;
        j = ak.length;
        i1 = 0;
_L3:
        k k1;
        if (i1 >= j)
        {
            break; /* Loop/switch isn't completed */
        }
        k1 = ak[i1];
        m m = k1.a(c, a);
        return m;
        l l1;
        l1;
        i1++;
        if (true) goto _L3; else goto _L2
_L2:
        throw ps.hacking.zxing.i.a();
    }

    public m a(c c)
    {
        if (b == null)
        {
            a(((Map) (null)));
        }
        return b(c);
    }

    public m a(c c, Map map)
    {
        a(map);
        return b(c);
    }

    public void a()
    {
        if (b != null)
        {
            k ak[] = b;
            int j = ak.length;
            for (int i1 = 0; i1 < j; i1++)
            {
                ak[i1].a();
            }

        }
    }

    public void a(Map map)
    {
label0:
        {
label1:
            {
                a = map;
                boolean flag;
                Collection collection;
                ArrayList arraylist;
                boolean flag1;
                if (map != null && map.containsKey(e.d))
                {
                    flag = true;
                } else
                {
                    flag = false;
                }
                if (map == null)
                {
                    collection = null;
                } else
                {
                    collection = (Collection)map.get(e.c);
                }
                arraylist = new ArrayList();
                if (collection == null)
                {
                    break label0;
                }
                if (!collection.contains(a.o) && !collection.contains(a.p) && !collection.contains(a.h) && !collection.contains(a.g) && !collection.contains(b) && !collection.contains(a.c) && !collection.contains(a.d) && !collection.contains(a.e) && !collection.contains(ps.hacking.zxing.a.i) && !collection.contains(a.m))
                {
                    boolean flag2 = collection.contains(a.n);
                    flag1 = false;
                    if (!flag2)
                    {
                        break label1;
                    }
                }
                flag1 = true;
            }
            if (flag1 && !flag)
            {
                arraylist.add(new i(map));
            }
            if (collection.contains(a.l))
            {
                arraylist.add(new a());
            }
            if (collection.contains(a.f))
            {
                arraylist.add(new ps.hacking.zxing.c.a());
            }
            if (collection.contains(ps.hacking.zxing.a.a))
            {
                arraylist.add(new b());
            }
            if (collection.contains(a.k))
            {
                arraylist.add(new ps.hacking.zxing.f.a());
            }
            if (collection.contains(a.j))
            {
                arraylist.add(new ps.hacking.zxing.d.a());
            }
            if (flag1 && flag)
            {
                arraylist.add(new i(map));
            }
        }
        if (arraylist.isEmpty())
        {
            if (!flag)
            {
                arraylist.add(new i(map));
            }
            arraylist.add(new a());
            arraylist.add(new ps.hacking.zxing.c.a());
            arraylist.add(new b());
            arraylist.add(new ps.hacking.zxing.f.a());
            arraylist.add(new ps.hacking.zxing.d.a());
            if (flag)
            {
                arraylist.add(new i(map));
            }
        }
        b = (k[])arraylist.toArray(new k[arraylist.size()]);
    }
}
