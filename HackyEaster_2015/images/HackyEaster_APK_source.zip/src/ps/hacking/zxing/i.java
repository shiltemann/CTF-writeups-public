// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing;


// Referenced classes of package ps.hacking.zxing:
//            l

public final class i extends l
{

    private static final i a = new i();

    private i()
    {
    }

    public static i a()
    {
        return a;
    }

}
