// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing;


// Referenced classes of package ps.hacking.zxing:
//            g

public final class j extends g
{

    private final byte a[];
    private final int b;
    private final int c;
    private final int d;
    private final int e;

    public j(byte abyte0[], int i, int k, int l, int i1, int j1, int k1, 
            boolean flag)
    {
        super(j1, k1);
        if (l + j1 > i || i1 + k1 > k)
        {
            throw new IllegalArgumentException("Crop rectangle does not fit within image data.");
        }
        a = abyte0;
        b = i;
        c = k;
        d = l;
        e = i1;
        if (flag)
        {
            a(j1, k1);
        }
    }

    private void a(int i, int k)
    {
        byte abyte0[] = a;
        int l = e * b + d;
        int i2;
        for (int i1 = 0; i1 < k; i1 = i2)
        {
            int j1 = l + i / 2;
            int k1 = -1 + (l + i);
            for (int l1 = l; l1 < j1;)
            {
                byte byte0 = abyte0[l1];
                abyte0[l1] = abyte0[k1];
                abyte0[k1] = byte0;
                l1++;
                k1--;
            }

            i2 = i1 + 1;
            l += b;
        }

    }

    public byte[] a()
    {
        int i = 0;
        int k = b();
        int l = c();
        byte abyte0[];
        if (k == b && l == c)
        {
            abyte0 = a;
        } else
        {
            int i1 = k * l;
            abyte0 = new byte[i1];
            int j1 = e * b + d;
            if (k == b)
            {
                System.arraycopy(a, j1, abyte0, 0, i1);
                return abyte0;
            }
            byte abyte1[] = a;
            while (i < l) 
            {
                System.arraycopy(abyte1, j1, abyte0, i * k, k);
                j1 += b;
                i++;
            }
        }
        return abyte0;
    }

    public byte[] a(int i, byte abyte0[])
    {
        if (i < 0 || i >= c())
        {
            throw new IllegalArgumentException((new StringBuilder()).append("Requested row is outside the image: ").append(i).toString());
        }
        int k = b();
        if (abyte0 == null || abyte0.length < k)
        {
            abyte0 = new byte[k];
        }
        int l = (i + e) * b + d;
        System.arraycopy(a, l, abyte0, 0, k);
        return abyte0;
    }

    public int[] f()
    {
        int i = b();
        int k = c();
        int ai[] = new int[i * k];
        byte abyte0[] = a;
        int l = e * b + d;
        int i1 = 0;
        int j1 = l;
        for (; i1 < k; i1++)
        {
            int k1 = i1 * i;
            for (int l1 = 0; l1 < i; l1++)
            {
                int i2 = 0xff & abyte0[j1 + l1];
                ai[k1 + l1] = 0xff000000 | i2 * 0x10101;
            }

            j1 += b;
        }

        return ai;
    }
}
