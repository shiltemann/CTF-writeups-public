// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing;


public final class n extends Enum
{

    public static final n a;
    public static final n b;
    public static final n c;
    public static final n d;
    public static final n e;
    public static final n f;
    public static final n g;
    public static final n h;
    private static final n i[];

    private n(String s, int j)
    {
        super(s, j);
    }

    public static n valueOf(String s)
    {
        return (n)Enum.valueOf(ps/hacking/zxing/n, s);
    }

    public static n[] values()
    {
        return (n[])i.clone();
    }

    static 
    {
        a = new n("OTHER", 0);
        b = new n("ORIENTATION", 1);
        c = new n("BYTE_SEGMENTS", 2);
        d = new n("ERROR_CORRECTION_LEVEL", 3);
        e = new n("ISSUE_NUMBER", 4);
        f = new n("SUGGESTED_PRICE", 5);
        g = new n("POSSIBLE_COUNTRY", 6);
        h = new n("UPC_EAN_EXTENSION", 7);
        n an[] = new n[8];
        an[0] = a;
        an[1] = b;
        an[2] = c;
        an[3] = d;
        an[4] = e;
        an[5] = f;
        an[6] = g;
        an[7] = h;
        i = an;
    }
}
