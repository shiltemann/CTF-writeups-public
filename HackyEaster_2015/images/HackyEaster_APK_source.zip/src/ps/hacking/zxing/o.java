// Decompiled by Jad v1.5.8e. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/kpdus/jad.html
// Decompiler options: braces fieldsfirst space lnc 

package ps.hacking.zxing;

import ps.hacking.zxing.b.a.a;

public class o
{

    private final float a;
    private final float b;

    public o(float f, float f1)
    {
        a = f;
        b = f1;
    }

    public static float a(o o1, o o2)
    {
        return ps.hacking.zxing.b.a.a.a(o1.a, o1.b, o2.a, o2.b);
    }

    private static float a(o o1, o o2, o o3)
    {
        float f = o2.a;
        float f1 = o2.b;
        return (o3.a - f) * (o1.b - f1) - (o3.b - f1) * (o1.a - f);
    }

    public static void a(o ao[])
    {
        float f = a(ao[0], ao[1]);
        float f1 = a(ao[1], ao[2]);
        float f2 = a(ao[0], ao[2]);
        o o1;
        o o2;
        o o3;
        if (f1 >= f && f1 >= f2)
        {
            o1 = ao[0];
            o2 = ao[1];
            o3 = ao[2];
        } else
        if (f2 >= f1 && f2 >= f)
        {
            o1 = ao[1];
            o2 = ao[0];
            o3 = ao[2];
        } else
        {
            o1 = ao[2];
            o2 = ao[0];
            o3 = ao[1];
        }
        if (a(o2, o1, o3) >= 0.0F)
        {
            o o4 = o3;
            o3 = o2;
            o2 = o4;
        }
        ao[0] = o3;
        ao[1] = o1;
        ao[2] = o2;
    }

    public final float a()
    {
        return a;
    }

    public final float b()
    {
        return b;
    }

    public final boolean equals(Object obj)
    {
        boolean flag = obj instanceof o;
        boolean flag1 = false;
        if (flag)
        {
            o o1 = (o)obj;
            int i = a != o1.a;
            flag1 = false;
            if (i == 0)
            {
                int j = b != o1.b;
                flag1 = false;
                if (j == 0)
                {
                    flag1 = true;
                }
            }
        }
        return flag1;
    }

    public final int hashCode()
    {
        return 31 * Float.floatToIntBits(a) + Float.floatToIntBits(b);
    }

    public final String toString()
    {
        StringBuilder stringbuilder = new StringBuilder(25);
        stringbuilder.append('(');
        stringbuilder.append(a);
        stringbuilder.append(',');
        stringbuilder.append(b);
        stringbuilder.append(')');
        return stringbuilder.toString();
    }
}
